#!/usr/bin/env node
/**
 * parar-todo-x.js  --  PARADA DE EMERGENCIA
 *
 * Detiene TODA publicacion automatica en X (Twitter):
 *   - Publicacion Diaria (acct-publisher)
 *   - X Autopilot (x-autopilot)
 *
 * No borra nada: solo pone "enabled: false" y marca las franjas/cola de hoy
 * como atendidas, para que no salga nada mas aunque reinicies el dashboard.
 *
 * Uso:
 *   node parar-todo-x.js                 (mira primero los archivos en esta carpeta)
 *   node parar-todo-x.js "C:\\ruta\\autosocial-studio"
 */

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(process.argv[2] || process.cwd());

function findFiles(names) {
  const found = [];
  const walk = (dir, depth) => {
    if (depth > 3) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry.name === "node_modules" || entry.name === ".git") continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full, depth + 1);
      else if (names.includes(entry.name)) found.push(full);
    }
  };
  walk(ROOT, 0);
  return found;
}

function loadJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

function backup(file) {
  const b = file + ".parada-backup";
  if (!fs.existsSync(b)) fs.copyFileSync(file, b);
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

let stops = 0;

// ---------------------------------------------------------------------------
// 1) Publicacion Diaria  ->  .runtime/acct-publisher.json
// ---------------------------------------------------------------------------
console.log("\n[1] Publicacion Diaria (acct-publisher)");
const pubFiles = findFiles(["acct-publisher.json"]);
if (!pubFiles.length) {
  console.log("  - No encontrado. (Nada activo por aqui.)");
}
for (const file of pubFiles) {
  const data = loadJson(file);
  if (!data || !data.profiles) {
    console.log(`  ! ${file}: formato no reconocido, se salta.`);
    continue;
  }
  const day = todayKey();
  let touched = 0;
  for (const [handle, profile] of Object.entries(data.profiles)) {
    const wasOn = profile?.config?.enabled === true;
    if (!profile.config) profile.config = {};
    profile.config.enabled = false;
    profile.slotDate = day;
    profile.firedSlots = [];
    const count = Math.max(1, Number(profile.config.postsPerDay) || 3);
    for (let i = 0; i < count; i += 1) profile.firedSlots.push(`${day}#${i}`);
    if (wasOn) {
      console.log(`  * @${handle}: DESACTIVADO (estaba activo)`);
      stops += 1;
    } else {
      console.log(`  * @${handle}: ya estaba desactivado`);
    }
    touched += 1;
  }
  if (touched) {
    backup(file);
    fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
    console.log(`  -> guardado: ${file}`);
  }
}

// ---------------------------------------------------------------------------
// 2) X Autopilot  ->  x-autopilot-state.json
// ---------------------------------------------------------------------------
console.log("\n[2] X Autopilot");
const autoFiles = findFiles(["x-autopilot-state.json"]);
if (!autoFiles.length) {
  console.log("  - No encontrado. (Nada activo por aqui.)");
}
for (const file of autoFiles) {
  const data = loadJson(file);
  if (!data || !data.accounts) {
    console.log(`  ! ${file}: formato no reconocido, se salta.`);
    continue;
  }
  let touched = 0;
  for (const [handle, item] of Object.entries(data.accounts)) {
    const wasOn = item?.config?.enabled === true;
    if (!item.config) item.config = {};
    item.config.enabled = false;
    if (Array.isArray(item.queue)) {
      const pending = item.queue.filter((p) => p.status === "scheduled").length;
      for (const post of item.queue) {
        if (post.status === "scheduled") post.status = "cancelled";
      }
      if (pending) console.log(`  * @${handle}: ${pending} tweet(s) programado(s) -> cancelados`);
    }
    if (wasOn) {
      console.log(`  * @${handle}: DESACTIVADO (estaba activo)`);
      stops += 1;
    } else {
      console.log(`  * @${handle}: ya estaba desactivado`);
    }
    touched += 1;
  }
  if (touched) {
    backup(file);
    fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
    console.log(`  -> guardado: ${file}`);
  }
}

// ---------------------------------------------------------------------------
// 3) Radar / programados de TikTok: solo informar
// ---------------------------------------------------------------------------
console.log("\n[3] Radar de noticias X");
console.log("  (El radar NO publica solo: solo escanea cuando pulsas tu. Nada que parar.)");

console.log("\n----------------------------------------");
if (stops) {
  console.log(`Parada aplicada. Se desactivaron ${stops} cuenta(s) que estaban activas.`);
} else {
  console.log("No habia ninguna cuenta con publicacion automatica activa.");
}
console.log("");
console.log("IMPORTANTE: reinicia el dashboard (Ctrl+C y luego `npm start`)");
console.log("para que los workers recarguen el estado desactivado. Mientras el");
console.log("dashboard viejo siga vivo, el worker en memoria puede seguir activo.");
console.log("");
console.log("Los tweets YA programados en X (dentro de X) no se borran desde aqui;");
console.log("se cancelan los de la cola local. Si ves alguno pendiente en X, borralo");
console.log("a mano en https://x.com/compose/post o en tu programador de X.");
console.log("");
