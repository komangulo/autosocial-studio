#!/usr/bin/env node
/**
 * instalar-tiktok-popup-restringido.js
 * ---------------------------------------------------------------------------
 * QUE ARREGLA
 *   Tras pulsar Publicar, TikTok a veces abre el modal
 *   "Content may be restricted / El contenido puede estar restringido".
 *   Ese modal tapa el boton de publicar y el automatismo se queda en bucle
 *   ("No publish confirmation yet; retrying the primary TikTok Post button."),
 *   sin cerrarlo nunca.
 *
 * QUE HACE
 *   1. Nueva funcion dismissRestrictedContentModal(page): detecta ese modal
 *      concreto y pulsa su "X" (common-modal-close), con varias estrategias de
 *      respaldo (icono SVG, alto del dialogo, texto del titulo).
 *   2. Se llama en el bucle de confirmacion JUSTO antes de reintentar publicar
 *      (el punto donde ahora dice "No publish confirmation yet...").
 *   3. Tambien se llama dentro de dismissInterferingOverlays para cubrir el
 *      caso de que aparezca antes del primer click.
 *
 * Idempotente. Uso:  node instalar-tiktok-popup-restringido.js
 */

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const ROOT = process.cwd();
const TARGET = path.join(ROOT, "src", "tiktok-uploader.js");
const MARK = "// MARKER: TIKTOK-RESTRICTED-MODAL-v1";
const MARK_V2 = "// MARKER: TIKTOK-RESTRICTED-MODAL-v2";
const LOOP_FIXED =
  'if (await dismissRestrictedContentModal(page)) {\n        await page.waitForTimeout(700);';

const results = [];
const ok = (m) => results.push(["OK", m]);
const skip = (m) => results.push(["SKIP", m]);
const fail = (m) => results.push(["FAIL", m]);

if (!fs.existsSync(path.join(ROOT, "package.json")) || !fs.existsSync(TARGET)) {
  console.error("ERROR: ejecuta este instalador desde la raiz de AutoSocial Studio.");
  process.exit(1);
}

let text = fs.readFileSync(TARGET, "utf8");

// La firma INEQUIVOCA del bug: la llamada dentro de dismissInterferingOverlays,
// que cierra el popup pero no vuelve a pulsar Publicar.
const overlaysBody = (() => {
  const start = text.indexOf("async function dismissInterferingOverlays(page) {");
  if (start === -1) return "";
  const end = text.indexOf("\n}\n", start);
  return end === -1 ? "" : text.slice(start, end);
})();
const hasOverlayBug = /await dismissRestrictedContentModal\(page\)/.test(overlaysBody);
const hasLoopFix =
  text.includes(MARK_V2) ||
  /if \(await dismissRestrictedContentModal\(page\)\)/.test(text);

if (hasLoopFix && !hasOverlayBug) {
  skip("tiktok-uploader.js ya cierra el popup Y repulsa Publicar (v2)");
} else if (text.includes(MARK) || hasLoopFix || hasOverlayBug) {
  // Instalacion anterior: cierra el popup pero NO repulsa Publicar, y/o esta
  // enganchada en un bloque que se agota (primaryRetryCount < 2).
  const oldCall = /await dismissRestrictedContentModal\(page\);\s*\n(\s*)const retried = await tryClickPublishButton\(page\);/;
  let patched = false;


  const LOOP_HEAD =
    `    for (let attempt = 0; attempt < 30; attempt += 1) {\n` +
    `      await dismissInterferingOverlays(page);`;
  const LOOP_HEAD_NEW =
    `    for (let attempt = 0; attempt < 30; attempt += 1) {\n` +
    `      await dismissInterferingOverlays(page);\n\n` +
    `      // MARKER: TIKTOK-RESTRICTED-MODAL-v2\n` +
    `      // El popup "Content may be restricted" aparece al pulsar Publicar y\n` +
    `      // tapa el boton. Hay que cerrarlo Y volver a pulsar Publicar, siempre\n` +
    `      // (no solo mientras queden reintentos).\n` +
    `      if (await dismissRestrictedContentModal(page)) {\n` +
    `        await page.waitForTimeout(700);\n` +
    `        const reclicked = await tryClickPublishButton(page);\n` +
    `        console.log(\n` +
    `          reclicked\n` +
    `            ? "Popup restringido cerrado y Publicar pulsado de nuevo."\n` +
    `            : "Popup restringido cerrado, pero no encontre el boton Publicar."\n` +
    `        );\n` +
    `        if (reclicked) {\n` +
    `          primaryRetryCount = 0;\n` +
    `          await page.waitForTimeout(1500);\n` +
    `          continue;\n` +
    `        }\n` +
    `      }`;

  if (text.includes(LOOP_HEAD)) {
    text = text.replace(LOOP_HEAD, LOOP_HEAD_NEW);
    patched = true;
    ok("bucle de confirmacion: cierra el popup y repulsa Publicar (siempre)");
  } else {
    fail("No encontre el inicio del bucle de confirmacion para reparar la v1.");
  }

  // Quitar la llamada vieja (la del bloque agotable) para no duplicar.
  if (oldCall.test(text)) {
    text = text.replace(oldCall, "const retried = await tryClickPublishButton(page);");
    ok("eliminada la llamada vieja del bloque de reintento");
  }

  // Quitar la llamada dentro de dismissInterferingOverlays: cierra el popup sin
  // repulsar Publicar, que es la causa de que el video no suba.
  {
    const s = text.indexOf("async function dismissInterferingOverlays(page) {");
    const e = s === -1 ? -1 : text.indexOf("\n}\n", s);
    if (s !== -1 && e !== -1) {
      const body = text.slice(s, e);
      const cleaned = body.replace(/\s*\n\s*(?:\/\/[^\n]*\n\s*)*await dismissRestrictedContentModal\(page\);?/g, "");
      if (cleaned !== body) {
        text = text.slice(0, s) + cleaned + text.slice(e);
        ok("eliminada la llamada en dismissInterferingOverlays (causaba el bug)");
      }
    }
  }

  if (patched && !results.some(([s]) => s === "FAIL")) {
    const backup = `${TARGET}.tiktok-popup-v2-backup`;
    if (!fs.existsSync(backup)) fs.copyFileSync(TARGET, backup);
    fs.writeFileSync(TARGET, text, "utf8");
    ok("src/tiktok-uploader.js actualizado a v2 (backup .tiktok-popup-v2-backup)");
  }
} else {
  // -------------------------------------------------------------------------
  // 1. Insertar la funcion nueva antes de dismissInterferingOverlays.
  // -------------------------------------------------------------------------
  const ANCHOR_FN = "async function dismissInterferingOverlays(page) {";

  const NEW_FN = `/**
 * ${MARK}
 * Cierra el modal "Content may be restricted" / "El contenido puede estar
 * restringido", que aparece tras pulsar Publicar y bloquea el boton.
 * El boton de cerrar es \`div.common-modal-close\` con un SVG: no tiene texto
 * ni aria-label, asi que hay que localizarlo por clase y por estructura.
 * Devuelve true si se cerro algun modal.
 */
async function dismissRestrictedContentModal(page) {
  const isRestrictedModalOpen = async () => {
    try {
      return await page.evaluate(() => {
        const titlePattern = /content may be restricted|el contenido puede estar restringido|puede estar restringido|contenido restringido/i;
        const reasons = [
          /unoriginal|low-quality|qr code|poco original|baja calidad|codigo qr/i,
          /violation reason|motivo de la infraccion/i,
        ];
        const dialogs = [
          ...document.querySelectorAll(
            '[role="dialog"], [class*="modal" i], [class*="Modal" i]'
          ),
        ].filter((el) => el.offsetParent !== null);

        for (const dialog of dialogs) {
          const body = (dialog.innerText || "").trim();
          if (!body) continue;
          if (titlePattern.test(body) || reasons.some((p) => p.test(body))) {
            const close = dialog.querySelector(
              ".common-modal-close, [class*='common-modal-close']"
            );
            if (close) return true;
          }
        }
        return false;
      });
    } catch {
      return false;
    }
  };

  let closedAny = false;
  for (let pass = 0; pass < 4; pass += 1) {
    if (!(await isRestrictedModalOpen())) break;

    let clicked = false;

    // Estrategia 1: el boton real que comparte el usuario.
    const closeByClass = page
      .locator(".common-modal-close, [class*='common-modal-close']")
      .first();
    if ((await closeByClass.count().catch(() => 0)) > 0) {
      await closeByClass.click({ timeout: 1500 }).catch(() => {});
      clicked = true;
    }

    // Estrategia 2: el icono interno (por si el contenedor cambia).
    if (!clicked) {
      const icon = page
        .locator(".common-modal-close-icon, [class*='common-modal-close-icon']")
        .first();
      if ((await icon.count().catch(() => 0)) > 0) {
        await icon.click({ timeout: 1500, force: true }).catch(() => {});
        clicked = true;
      }
    }

    // Estrategia 3: el SVG de la X (path con el trazo en aspa).
    if (!clicked) {
      const svgClose = page
        .locator(
          'svg path[d*="M38.7 12.12"], [role="dialog"] svg, [class*="modal" i] svg'
        )
        .first();
      if ((await svgClose.count().catch(() => 0)) > 0) {
        await svgClose
          .click({ timeout: 1500, force: true })
          .catch(() => {});
        clicked = true;
      }
    }

    // Estrategia 4: JS directo sobre el DOM (ultimo recurso).
    if (!clicked) {
      await page
        .evaluate(() => {
          const close = document.querySelector(
            ".common-modal-close, [class*='common-modal-close']"
          );
          if (close) close.click();
        })
        .catch(() => {});
    }

    if (!clicked) break;
    closedAny = true;
    await page.waitForTimeout(600);
  }

  if (closedAny) {
    console.log("TikTok: cerrado el popup de contenido restringido; reintentando publicar.");
  }
  return closedAny;
}

${ANCHOR_FN}`;

  if (text.includes(ANCHOR_FN) && !text.includes("async function dismissRestrictedContentModal")) {
    text = text.replace(ANCHOR_FN, NEW_FN);
    ok("dismissRestrictedContentModal anadida (cierra la X del popup)");
  } else {
    fail("No se encontro dismissInterferingOverlays para insertar la funcion.");
  }

  // -------------------------------------------------------------------------
  // 2. Manejar el popup AL PRINCIPIO de cada vuelta del bucle de confirmacion.
  //    Es el unico punto que se ejecuta siempre (el bloque de "retry" esta
  //    limitado por primaryRetryCount < 2 y se agota). Cerrar el popup NO
  //    publica: reaparece justo al pulsar Publicar, asi que tras cerrarlo hay
  //    que volver a pulsar el boton.
  // -------------------------------------------------------------------------
  const LOOP_HEAD =
    `    for (let attempt = 0; attempt < 30; attempt += 1) {\n` +
    `      await dismissInterferingOverlays(page);`;

  const LOOP_HEAD_NEW =
    `    for (let attempt = 0; attempt < 30; attempt += 1) {\n` +
    `      await dismissInterferingOverlays(page);\n\n` +
    `      // ${MARK}: si aparecio "Content may be restricted", cerrarlo y volver\n` +
    `      // a pulsar Publicar. Sin esto, el modal tapa el boton, el bucle se\n` +
    `      // queda esperando una confirmacion que nunca llega y el video no sube.\n` +
    `      if (await dismissRestrictedContentModal(page)) {\n` +
    `        await page.waitForTimeout(700);\n` +
    `        const reclicked = await tryClickPublishButton(page);\n` +
    `        console.log(\n` +
    `          reclicked\n` +
    `            ? "Popup restringido cerrado y Publicar pulsado de nuevo."\n` +
    `            : "Popup restringido cerrado, pero no encontre el boton Publicar."\n` +
    `        );\n` +
    `        if (reclicked) {\n` +
    `          primaryRetryCount = 0;\n` +
    `          await page.waitForTimeout(1500);\n` +
    `          continue;\n` +
    `        }\n` +
    `      }`;

  if (text.includes(LOOP_HEAD)) {
    text = text.replace(LOOP_HEAD, LOOP_HEAD_NEW);
    ok("el bucle de confirmacion cierra el popup y repulsa Publicar (siempre activo)");
  } else {
    fail(
      "No encontre el inicio del bucle waitForPublishConfirmation. " +
        "Manda las lineas alrededor de 'for (let attempt = 0; attempt < 30'."
    );
  }

  // -------------------------------------------------------------------------
  // 3. NO se cierra desde dismissInterferingOverlays a proposito: alli se
  //    cerraria el popup sin volver a pulsar Publicar, que es exactamente el
  //    bug que deja el video sin subir. El manejo vive solo en el bucle.
  // -------------------------------------------------------------------------
  skip("el popup se maneja en el bucle de confirmacion (no en overlays)");

  // -------------------------------------------------------------------------
  // 4. Exportarla en _private para poder probarla y depurarla.
  // -------------------------------------------------------------------------
  const OLD_EXPORT = `  _private: {`;
  if (text.includes(OLD_EXPORT) && !text.includes("dismissRestrictedContentModal,")) {
    text = text.replace(
      OLD_EXPORT,
      `  _private: {\n    dismissRestrictedContentModal,`
    );
    ok("dismissRestrictedContentModal exportada en _private");
  } else {
    skip("dismissRestrictedContentModal ya estaba exportada (o no hay bloque _private)");
  }

  const failuresSoFar = results.filter(([s]) => s === "FAIL").length;
  if (failuresSoFar === 0) {
    const backup = `${TARGET}.tiktok-popup-backup`;
    if (!fs.existsSync(backup)) fs.copyFileSync(TARGET, backup);
    fs.writeFileSync(TARGET, text, "utf8");
    ok("src/tiktok-uploader.js actualizado (backup en .tiktok-popup-backup)");
  }
}

// ---------------------------------------------------------------------------
// Verificar sintaxis (unica prueba fiable)
// ---------------------------------------------------------------------------
const check = spawnSync(process.execPath, ["--check", TARGET], { encoding: "utf8" });
if (check.status !== 0) {
  fail(
    "Sintaxis rota: " + (check.stderr || "").split("\n").filter(Boolean).slice(0, 3).join(" | ")
  );
}

console.log("\n=== AutoSocial Studio - TikTok: popup 'contenido restringido' ===");
for (const [status, message] of results) console.log(`  [${status}] ${message}`);
const failures = results.filter(([s]) => s === "FAIL");
console.log(
  `\n${results.filter(([s]) => s === "OK").length} cambios, ` +
    `${results.filter(([s]) => s === "SKIP").length} ya presentes, ${failures.length} errores.`
);
if (failures.length) {
  console.error(
    "\nNo se toco el archivo a medias. Tu tiktok-uploader.js esta intacto. " +
      "Mandame el error de arriba."
  );
  process.exitCode = 1;
} else {
  console.log("\nHecho. Reinicia el dashboard:  node src/dashboard-server.js");
  console.log("Veras en el log: 'cerrado el popup de contenido restringido'.");
}
