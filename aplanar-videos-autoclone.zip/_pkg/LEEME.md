# Aplanar videos de autoclone -> cola de TikTok

## Que problema resuelve
El autoclone guarda cada video en su propia subcarpeta:

  .runtime/autoclone/jobs/<job>/work/<subcarpeta>/video.mp4

Pero el programador de subidas espera los videos SUELTOS en:

  queue/<cuenta>/tiktok/pending/

Este script recoge todos los videos de las subcarpetas y los lleva a la cola
de la cuenta, con nombres unicos (no sobrescribe nada).

## Uso rapido (Git Bash, en la carpeta del proyecto)
1. Primero, MIRA lo que hara sin tocar nada:
   node aplanar-videos-autoclone.js --dry-run

2. Si te parece bien, ejecutalo (COPIA los videos, deja los originales):
   node aplanar-videos-autoclone.js

3. Si prefieres MOVERLOS (liberar espacio, borra los originales):
   node aplanar-videos-autoclone.js --mover

## Opciones
- `--dry-run`            solo muestra lo que haria, no toca nada
- `--mover`              mueve en vez de copiar
- `--cuenta <id>`        elige la cuenta destino (por defecto, la activa)
- `--origen "<ruta>"`    carpeta "work" concreta
- `--destino "<ruta>"`   carpeta destino concreta

## Ejemplo con tu ruta exacta
Copiar los videos de ese job a la cola de la cuenta activa:
   node aplanar-videos-autoclone.js "C:\Users\msi\Downloads\autosocial-studio\.runtime\autoclone\jobs\jayandrews69-1790708834467\work"

## Notas
- Es IDEMPOTENTE: si lo ejecutas dos veces, NO duplica los videos
  (detecta los que ya estan por tamano y contenido).
- Por defecto busca TODOS los jobs, no solo ese.
- Despues, abre el dashboard y programa la cola como siempre.
