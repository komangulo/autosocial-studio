#!/usr/bin/env node
/**
 * instalar-tiktok-popup-restringido.js
 * ---------------------------------------------------------------------------
 * QUE ARREGLA
 *   Tras pulsar Publicar, TikTok a veces abre el modal
 *   "Content may be restricted / El contenido puede estar restringido".
 *   Ese modal tapa el boton de publicar y el automatismo se queda en bucle
 *   ("No publish confirmation yet; retrying the primary TikTok Post button."),
 *   sin cerrarlo nunca.
 *
 * QUE HACE
 *   1. Nueva funcion dismissRestrictedContentModal(page): detecta ese modal
 *      concreto y pulsa su "X" (common-modal-close), con varias estrategias de
 *      respaldo (icono SVG, alto del dialogo, texto del titulo).
 *   2. Se llama en el bucle de confirmacion JUSTO antes de reintentar publicar
 *      (el punto donde ahora dice "No publish confirmation yet...").
 *   3. Tambien se llama dentro de dismissInterferingOverlays para cubrir el
 *      caso de que aparezca antes del primer click.
 *
 * Idempotente. Uso:  node instalar-tiktok-popup-restringido.js
 */

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const ROOT = process.cwd();
const TARGET = path.join(ROOT, "src", "tiktok-uploader.js");
const MARK = "// MARKER: TIKTOK-RESTRICTED-MODAL-v1";

const results = [];
const ok = (m) => results.push(["OK", m]);
const skip = (m) => results.push(["SKIP", m]);
const fail = (m) => results.push(["FAIL", m]);

if (!fs.existsSync(path.join(ROOT, "package.json")) || !fs.existsSync(TARGET)) {
  console.error("ERROR: ejecuta este instalador desde la raiz de AutoSocial Studio.");
  process.exit(1);
}

let text = fs.readFileSync(TARGET, "utf8");

if (text.includes(MARK)) {
  skip("tiktok-uploader.js ya cierra el popup de contenido restringido");
} else {
  // -------------------------------------------------------------------------
  // 1. Insertar la funcion nueva antes de dismissInterferingOverlays.
  // -------------------------------------------------------------------------
  const ANCHOR_FN = "async function dismissInterferingOverlays(page) {";

  const NEW_FN = `/**
 * ${MARK}
 * Cierra el modal "Content may be restricted" / "El contenido puede estar
 * restringido", que aparece tras pulsar Publicar y bloquea el boton.
 * El boton de cerrar es \`div.common-modal-close\` con un SVG: no tiene texto
 * ni aria-label, asi que hay que localizarlo por clase y por estructura.
 * Devuelve true si se cerro algun modal.
 */
async function dismissRestrictedContentModal(page) {
  const isRestrictedModalOpen = async () => {
    try {
      return await page.evaluate(() => {
        const titlePattern = /content may be restricted|el contenido puede estar restringido|puede estar restringido|contenido restringido/i;
        const reasons = [
          /unoriginal|low-quality|qr code|poco original|baja calidad|codigo qr/i,
          /violation reason|motivo de la infraccion/i,
        ];
        const dialogs = [
          ...document.querySelectorAll(
            '[role="dialog"], [class*="modal" i], [class*="Modal" i]'
          ),
        ].filter((el) => el.offsetParent !== null);

        for (const dialog of dialogs) {
          const body = (dialog.innerText || "").trim();
          if (!body) continue;
          if (titlePattern.test(body) || reasons.some((p) => p.test(body))) {
            const close = dialog.querySelector(
              ".common-modal-close, [class*='common-modal-close']"
            );
            if (close) return true;
          }
        }
        return false;
      });
    } catch {
      return false;
    }
  };

  let closedAny = false;
  for (let pass = 0; pass < 4; pass += 1) {
    if (!(await isRestrictedModalOpen())) break;

    let clicked = false;

    // Estrategia 1: el boton real que comparte el usuario.
    const closeByClass = page
      .locator(".common-modal-close, [class*='common-modal-close']")
      .first();
    if ((await closeByClass.count().catch(() => 0)) > 0) {
      await closeByClass.click({ timeout: 1500 }).catch(() => {});
      clicked = true;
    }

    // Estrategia 2: el icono interno (por si el contenedor cambia).
    if (!clicked) {
      const icon = page
        .locator(".common-modal-close-icon, [class*='common-modal-close-icon']")
        .first();
      if ((await icon.count().catch(() => 0)) > 0) {
        await icon.click({ timeout: 1500, force: true }).catch(() => {});
        clicked = true;
      }
    }

    // Estrategia 3: el SVG de la X (path con el trazo en aspa).
    if (!clicked) {
      const svgClose = page
        .locator(
          'svg path[d*="M38.7 12.12"], [role="dialog"] svg, [class*="modal" i] svg'
        )
        .first();
      if ((await svgClose.count().catch(() => 0)) > 0) {
        await svgClose
          .click({ timeout: 1500, force: true })
          .catch(() => {});
        clicked = true;
      }
    }

    // Estrategia 4: JS directo sobre el DOM (ultimo recurso).
    if (!clicked) {
      await page
        .evaluate(() => {
          const close = document.querySelector(
            ".common-modal-close, [class*='common-modal-close']"
          );
          if (close) close.click();
        })
        .catch(() => {});
    }

    if (!clicked) break;
    closedAny = true;
    await page.waitForTimeout(600);
  }

  if (closedAny) {
    console.log("TikTok: cerrado el popup de contenido restringido; reintentando publicar.");
  }
  return closedAny;
}

${ANCHOR_FN}`;

  if (text.includes(ANCHOR_FN) && !text.includes("async function dismissRestrictedContentModal")) {
    text = text.replace(ANCHOR_FN, NEW_FN);
    ok("dismissRestrictedContentModal anadida (cierra la X del popup)");
  } else {
    fail("No se encontro dismissInterferingOverlays para insertar la funcion.");
  }

  // -------------------------------------------------------------------------
  // 2. Llamarla justo antes de reintentar publicar en el bucle de confirmacion.
  // -------------------------------------------------------------------------
  const OLD_RETRY = `        console.log("No publish confirmation yet; retrying the primary TikTok Post button.");
        const retried = await tryClickPublishButton(page);`;

  const NEW_RETRY = `        console.log("No publish confirmation yet; retrying the primary TikTok Post button.");
        // ${MARK}: si TikTok abrio "Content may be restricted", cerrar su X
        // antes de reintentar; si no, el modal tapa el boton y se queda en bucle.
        await dismissRestrictedContentModal(page);
        const retried = await tryClickPublishButton(page);`;

  if (text.includes(OLD_RETRY)) {
    text = text.replace(OLD_RETRY, NEW_RETRY);
    ok("el reintento de publicar ahora cierra antes el popup restringido");
  } else {
    // Alternativa robusta: localizar el reintento por su estructura
    // (comprobacion + tryClickPublishButton) aunque el texto del log cambie.
    const RETRY_RE =
      /(\n(\s*)if \(\s*\n?\s*primaryRetryCount < 2[\s\S]*?\n\2\)\s*\{\s*\n\s*console\.log\([^\n]*\);\s*\n)(\s*const retried = await tryClickPublishButton\(page\);)/;
    const m = text.match(RETRY_RE);
    if (m) {
      text = text.replace(
        RETRY_RE,
        `${m[1]}${m[2]}// ${MARK}: cierra el modal de contenido restringido antes de reintentar.\n` +
          `${m[2]}await dismissRestrictedContentModal(page);\n${m[3]}`
      );
      ok("el reintento de publicar cierra el popup (detectado por estructura)");
    } else {
      fail(
        "No se encontro el bloque de reintento de publicar. " +
          "Mandame las lineas alrededor de 'primaryRetryCount' en tu tiktok-uploader.js."
      );
    }
  }

  // -------------------------------------------------------------------------
  // 3. Llamarla al final de dismissInterferingOverlays (cubre el caso previo).
  // -------------------------------------------------------------------------
  const OLD_OVERLAY_END = `    if (!clickedSomething) {
      break;
    }
  }
}`;

  const NEW_OVERLAY_END = `    if (!clickedSomething) {
      break;
    }
  }

  // Un modal de contenido restringido puede aparecer antes del primer click.
  await dismissRestrictedContentModal(page);
}`;

  const overlayStart = text.indexOf(ANCHOR_FN);
  if (overlayStart !== -1 && text.indexOf(OLD_OVERLAY_END, overlayStart) !== -1) {
    const idx = text.indexOf(OLD_OVERLAY_END, overlayStart);
    text = text.slice(0, idx) + NEW_OVERLAY_END + text.slice(idx + OLD_OVERLAY_END.length);
    ok("dismissInterferingOverlays tambien cierra el popup");
  } else {
    fail("No se encontro el cierre de dismissInterferingOverlays.");
  }

  // -------------------------------------------------------------------------
  // 4. Exportarla en _private para poder probarla y depurarla.
  // -------------------------------------------------------------------------
  const OLD_EXPORT = `  _private: {`;
  if (text.includes(OLD_EXPORT) && !text.includes("dismissRestrictedContentModal,")) {
    text = text.replace(
      OLD_EXPORT,
      `  _private: {\n    dismissRestrictedContentModal,`
    );
    ok("dismissRestrictedContentModal exportada en _private");
  } else {
    skip("dismissRestrictedContentModal ya estaba exportada (o no hay bloque _private)");
  }

  const failuresSoFar = results.filter(([s]) => s === "FAIL").length;
  if (failuresSoFar === 0) {
    const backup = `${TARGET}.tiktok-popup-backup`;
    if (!fs.existsSync(backup)) fs.copyFileSync(TARGET, backup);
    fs.writeFileSync(TARGET, text, "utf8");
    ok("src/tiktok-uploader.js actualizado (backup en .tiktok-popup-backup)");
  }
}

// ---------------------------------------------------------------------------
// Verificar sintaxis (unica prueba fiable)
// ---------------------------------------------------------------------------
const check = spawnSync(process.execPath, ["--check", TARGET], { encoding: "utf8" });
if (check.status !== 0) {
  fail(
    "Sintaxis rota: " + (check.stderr || "").split("\n").filter(Boolean).slice(0, 3).join(" | ")
  );
}

console.log("\n=== AutoSocial Studio - TikTok: popup 'contenido restringido' ===");
for (const [status, message] of results) console.log(`  [${status}] ${message}`);
const failures = results.filter(([s]) => s === "FAIL");
console.log(
  `\n${results.filter(([s]) => s === "OK").length} cambios, ` +
    `${results.filter(([s]) => s === "SKIP").length} ya presentes, ${failures.length} errores.`
);
if (failures.length) {
  console.error(
    "\nNo se toco el archivo a medias. Tu tiktok-uploader.js esta intacto. " +
      "Mandame el error de arriba."
  );
  process.exitCode = 1;
} else {
  console.log("\nHecho. Reinicia el dashboard:  node src/dashboard-server.js");
  console.log("Veras en el log: 'cerrado el popup de contenido restringido'.");
}
