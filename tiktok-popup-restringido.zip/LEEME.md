# TikTok: cerrar el popup "Content may be restricted"

## El problema

Tras pulsar Publicar, TikTok a veces abre el modal "Content may be restricted /
El contenido puede estar restringido". Tapa el botón de publicar y el automatismo
se queda en bucle:

    No publish confirmation yet; retrying the primary TikTok Post button.
    No publish confirmation yet; retrying the primary TikTok Post button.
    ...

La X de ese modal es un `<div class="common-modal-close">` con un SVG, **sin texto
ni aria-label**, por eso el código actual no la encontraba y nunca cerraba el modal.

## Qué hace ahora

1. Nueva función `dismissRestrictedContentModal(page)` que detecta ESE modal y
   pulsa su X, con 4 estrategias de respaldo (clase, icono interno, SVG, JS directo).
2. Se llama justo **antes** de reintentar publicar, en el punto exacto donde antes
   salía el bucle de "No publish confirmation yet...".
3. También se llama dentro de `dismissInterferingOverlays`, por si aparece antes
   del primer click.

## Instalación

1. Copia `instalar-tiktok-popup-restringido.js` a la raíz del proyecto.
2. Ejecuta:

       node instalar-tiktok-popup-restringido.js

3. Verás `5 cambios aplicados`. Reinicia el dashboard.

Es idempotente. Copia de seguridad: `src/tiktok-uploader.js.tiktok-popup-backup`.

## Cómo saber que funciona

En el log aparecerá:

    TikTok: cerrado el popup de contenido restringido; reintentando publicar.

Y la subida continúa en vez de quedarse atascada.
