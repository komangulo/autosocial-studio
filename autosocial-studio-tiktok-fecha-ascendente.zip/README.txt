ORDEN DE PUBLICACION DE TIKTOK POR FECHA

Este ZIP contiene los archivos modificados del repositorio actual. No es el
proyecto completo: copia su contenido sobre la raiz de autosocial-studio y
acepta reemplazar los archivos existentes.

COMO USARLO

1. Cierra AutoSocial Studio.
2. Extrae el contenido en:
   C:\Users\msi\Downloads\autosocial-studio
3. Inicia la herramienta de nuevo.
4. Abre la seccion Auto Post de TikTok.
5. Activa "Publicar TikTok de mas antiguo a mas reciente".

COMPORTAMIENTO

- Ordena primero por una fecha al principio del nombre del video.
- Acepta YYYY-MM-DD y YYYYMMDD.
- Los videos del mismo dia se ordenan por nombre.
- Los videos sin fecha quedan al final.
- La opcion solo afecta a TikTok.
- Si esta activa, tiene prioridad sobre el orden aleatorio global.
- El orden visible de la cola coincide con el siguiente video que se publica.
- La opcion queda guardada en .env como TIKTOK_QUEUE_DATE_ASC=true.

Ejemplos reconocidos:

2024-01-15_123456.mp4
20240116_123457.mp4
