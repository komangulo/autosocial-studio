#!/usr/bin/env node
/*
 * instalar-radar-scan.js
 * ---------------------------------------------------------------------------
 * Arregla que el RADAR "no escanee": al pulsar "Escanear sin publicar" / "Escanear
 * y publicar ahora" no encontraba nada y no decia por que.
 *
 * Causas que corrige:
 *   1. scanKeyword solo buscaba `article[data-testid="tweet"]`, esperaba 3,5 s y
 *      NO hacia scroll ni detectaba el muro de login -> 0 resultados en silencio.
 *   2. El endpoint /now devolvia el historial antiguo en vez del resultado del
 *      escaneo, asi que la UI nunca mostraba cuantos tweets se leyeron.
 *   3. Si la ventana de login estaba abierta pero SIN sesion, se reutilizaba y
 *      se buscaba como invitado. Ahora avisa claro.
 *
 * Uso:  node instalar-radar-scan.js    (desde la raiz del proyecto)
 * Idempotente. Hace copia .bak-scan de lo que reemplaza.
 * ---------------------------------------------------------------------------
 */
"use strict";

const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
let changes = 0, errors = 0, skipped = 0;
function ok(m) { changes++; console.log("  [OK]    " + m); }
function skip(m) { skipped++; console.log("  [SKIP]  " + m); }
function fail(m) { errors++; console.error("  [FALLO] " + m); }
function read(rel) { const p = path.join(ROOT, rel); return fs.existsSync(p) ? fs.readFileSync(p, "utf8") : null; }
function write(rel, c) { const p = path.join(ROOT, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, c, "utf8"); }
function backup(rel) {
  const p = path.join(ROOT, rel);
  const b = p + ".bak-scan";
  if (fs.existsSync(p) && !fs.existsSync(b)) fs.writeFileSync(b, fs.readFileSync(p, "utf8"));
}
function readAsset(name) {
  for (const c of [path.join(__dirname, "assets", name), path.join(ROOT, "assets", name)]) {
    if (fs.existsSync(c)) return fs.readFileSync(c, "utf8");
  }
  throw new Error("Falta el asset: " + name);
}

console.log("\n=== Instalador: arreglar el escaneo del radar ===\n");
if (!fs.existsSync(path.join(ROOT, "package.json"))) {
  console.error("No parece la raiz del proyecto (falta package.json).");
  process.exit(1);
}
if (!fs.existsSync(path.join(ROOT, "src", "acct-radar.js"))) {
  console.error("No encuentro src/acct-radar.js. Ejecuta primero el instalador del radar.");
  process.exit(1);
}

// --- 1. Motor del radar ----------------------------------------------------
(function motor() {
  console.log("1) src/acct-radar.js");
  const cur = read("src/acct-radar.js");
  if (cur && cur.includes("ACCT-RADAR-v3")) { skip("el motor ya escanea con informe"); return; }
  const asset = readAsset("acct-radar.js");
  if (!asset.includes("ACCT-RADAR-v3")) { fail("el asset no es la version v3"); return; }
  backup("src/acct-radar.js");
  write("src/acct-radar.js", asset);
  ok("motor reemplazado (espera resultados, scroll, informe del escaneo)");
})();

// --- 2. Sesion de X: no reutilizar una ventana sin login -------------------
(function xauth() {
  console.log("2) src/x-auth.js");
  const cur = read("src/x-auth.js");
  if (!cur) { fail("no existe src/x-auth.js"); return; }
  if (cur.includes("XAP-AUTH-v3")) { skip("x-auth ya comprueba la sesion reutilizada"); return; }
  const asset = readAsset("x-auth.js");
  if (!asset.includes("XAP-AUTH-v3")) { fail("el asset x-auth no es la version v3"); return; }
  backup("src/x-auth.js");
  write("src/x-auth.js", asset);
  ok("x-auth actualizado (avisa si la ventana de login no tiene sesion)");
})();

// --- 3. UI del radar -------------------------------------------------------
(function ui() {
  console.log("3) web/acct-radar-ui.js");
  const cur = read("web/acct-radar-ui.js");
  if (!cur) { fail("no existe web/acct-radar-ui.js"); return; }
  if (cur.includes("ACCT-RADAR-UI-v3")) { skip("la UI ya muestra el informe del escaneo"); return; }
  const asset = readAsset("acct-radar-ui.js");
  if (!asset.includes("ACCT-RADAR-UI-v3")) { fail("el asset de UI no es la version v3"); return; }
  backup("web/acct-radar-ui.js");
  write("web/acct-radar-ui.js", asset);
  ok("UI actualizada (dice cuantos tweets se leyeron y por que se descartaron)");
})();

// --- 4. Endpoint /now ------------------------------------------------------
(function route() {
  console.log("4) src/dashboard-server.js");
  const cur = read("src/dashboard-server.js");
  if (!cur) { fail("no existe src/dashboard-server.js"); return; }

  // Reparacion: una version anterior de este instalador podia dejar
  // "const profile" duplicado en la ruta /now y romper el arranque. Se reescribe
  // toda la ruta a la version buena de una sola pasada.
  if (cur.includes("run.published") && !/const profile = acctRadar\.getStatus\(req\.params\.handle\);\s*\n\s*const profile = acctRadar\.getStatus/.test(cur)) {
    skip("la ruta /now ya devuelve el resultado del escaneo");
    return;
  }
  const routeStart = cur.indexOf('  app.post("/api/acct-radar/:handle/now"');
  const routeEnd = cur.indexOf('  app.post("/api/acct-radar/:handle/stop"');
  if (routeStart === -1 || routeEnd === -1 || routeEnd < routeStart) {
    fail("no se encontro la ruta /api/acct-radar/:handle/now completa");
    return;
  }
  const routeNew = `  app.post("/api/acct-radar/:handle/now", async (req, res) => {
    try {
      const run = await acctRadar.runOnce(req.params.handle, { dryRun: req.body?.dryRun === true, force: true });
      const profile = acctRadar.getStatus(req.params.handle);
      res.json({ ok: true, result: { published: run.published || [], skipped: run.skipped || 0, scan: run.scan || null }, profile });
    } catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

`;
  backup("src/dashboard-server.js");
  write("src/dashboard-server.js", cur.slice(0, routeStart) + routeNew + cur.slice(routeEnd));
  if (/const profile = acctRadar\.getStatus\(req\.params\.handle\);\s*\n\s*const profile = acctRadar\.getStatus/.test(read("src/dashboard-server.js"))) {
    fail("quedo un 'const profile' duplicado; revisa src/dashboard-server.js");
    return;
  }
  ok("ruta /now reparada y devolviendo el informe del escaneo");
})();

console.log("\n=== Resumen ===");
console.log("  Cambios: " + changes + "   Omitidos: " + skipped + "   Errores: " + errors + "\n");
if (errors) {
  console.error("Hay errores. Revisa los [FALLO]. No reinicies aun.");
  process.exit(1);
}
console.log("Listo. Reinicia el dashboard y pulsa Ctrl+F5.");
console.log("Al escanear, el cuadro azul te dira exactamente cuantos tweets se leyeron.");
