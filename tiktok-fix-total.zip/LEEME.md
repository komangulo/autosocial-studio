# FIX TOTAL de subidas TikTok — un instalador

## Qué arregla

1. **No programaba la fecha/hora.** El código esperaba a que el vídeo procesara
   detectando el texto "uploading", que da falsos positivos, y se quedaba
   bloqueado. Ahora espera por **estado real** ("Uploaded") y, antes de
   programar, **comprueba que el radio "Schedule" está activo**; si el
   formulario estaba en "Now" (como en tu captura), lo activa.
2. **El navegador se cerraba sin dejar ver el error.** Si falla la programación,
   ahora **se queda abierto** con la captura `last-upload-error.png`.
3. **Un solo navegador para todo el lote** (no 10 Chrome sobre el mismo perfil).
4. **Cierra el popup "Content may be restricted"** pulsando su X, antes de
   reintentar publicar.

## Instalación

1. Copia `instalar-tiktok-fix-total.js` a la raíz del proyecto.
2. Ejecuta:

       node instalar-tiktok-fix-total.js

3. Verás `11 cambios aplicados, 0 errores`. Reinicia el dashboard.

## Seguridad

- Es **idempotente**: la 2ª vez dice `0 cambios, N ya presentes`.
- Copia de seguridad: `src/tiktok-uploader.js.tiktok-fix-total-backup`.
- Si un ancla no aparece, **aborta sin tocar nada** y te lo dice.
- Verifica la sintaxis del archivo final antes de dar "Hecho".

## Cómo saber que funciona

En el log verás:

    TikTok: video listo (Uploaded).
    TikTok schedule set to 2026-09-20 18:30.

Y si algo falla en la programación, la ventana **no se cierra**.
