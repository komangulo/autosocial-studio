# Arreglo de TikTok que no programa (cuenta nueva)

Dos scripts. Ejecuta primero el 1, y si quieres que no vuelva a pasar, el 2.

## 1) Limpiar el estado roto de la cuenta  (OBLIGATORIO)

Desde la carpeta del proyecto (donde está `package.json`), con el dashboard CERRADO:

```bat
node reparar-cola-tiktok.js kitty-miau --dry
```

Revisa que detecta los metadatos huérfanos. Si todo cuadra, aplícalo:

```bat
node reparar-cola-tiktok.js kitty-miau
```

Qué hace (con copia de seguridad en `.runtime/reparacion-...`):
- Mueve los `.meta.json` huérfanos de `pending` (sin vídeo) a la copia.
- Quita del store los jobs cancelados/fallidos de esa cuenta (desbloquea reintentos).
- Borra el flag de pausa `.runtime/autonomous-worker.paused`.

## 2) Parches de código  (RECOMENDADO)

```bat
node aplicar-parches-tiktok.js --dry
node aplicar-parches-tiktok.js
```

Corrige 4 cosas:
- P1: un job cancelado ya no bloquea volver a programar el mismo vídeo.
- P2: el resumen cuenta "publicado" de verdad, no lo meramente encolado.
- P3: cancelar no mancha la lista de fallidos.
- P4: el drenaje informa de cuántos jobs quedaron cancelados.

Deshacer en cualquier momento:

```bat
node aplicar-parches-tiktok.js --revert
```

## 3) Volver a programar

1. Reinicia el dashboard (`npm run dashboard`).
2. Entra en TikTok → comprueba que `scheduled/processing/posted/failed` están vacíos.
3. Confirma que la sesión de TikTok de la cuenta sigue válida.
4. Pulsa «Programar todo en TikTok ahora» y **no pulses «Parar»** a mitad.
5. Vigila la ventana de Chromium y `schedule-debug.log`.

## Requisitos
- Copia los dos `.js` a la raíz del proyecto (junto a `package.json`).
- Node 18+ (ya lo tienes).
