# Arreglo: "Idioma del titulo y descripcion: Original" no se respetaba

## Que pasaba
Con "Traducir texto en pantalla" desmarcado y "Idioma del titulo y descripcion"
en "Original", el .meta.json se seguia traduciendo al espanol.

## Causa exacta
El backend decide traducir asi (src/autoclone/controller.js):

    metadataLanguage: options.metadataLanguage === "original" ? "original" : "es"

Es decir: si NO le llega el idioma, TRADUCE (asume "es").

Pues bien: la descarga de perfil (boton "Descargar", endpoint
/api/autoclone/start-download) NO enviaba el campo metadataLanguage.
El otro boton (/api/autoclone/start) SI lo enviaba. Por eso a veces respetaba
"Original" y a veces no.

## Arreglo
Anadir metadataLanguage a la peticion de start-download, leyendo el mismo
desplegable. Una linea.

## Como usarlo (Windows / Git Bash)
1. Cierra el dashboard (Ctrl+C).
2. En la carpeta del proyecto:
   C:\Users\msi\Downloads\autosocial-studio
3. Copia `arreglar-idioma-original-autoclone.js` a esa carpeta.
4. Ejecuta:
   node arreglar-idioma-original-autoclone.js
5. Arranca:
   npm run dashboard
6. Recarga el navegador con Ctrl+F5.

## Deshacer
   node arreglar-idioma-original-autoclone.js --revert

## Importante
Los .meta.json que YA se generaron estan traducidos y no se reescriben solos.
Para que un video se regenere en ingles, borra su .meta.json (o el .info.json)
y vuelve a descargarlo. Nada mas.
