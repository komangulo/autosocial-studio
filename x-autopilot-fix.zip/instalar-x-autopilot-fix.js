#!/usr/bin/env node
/**
 * instalar-x-autopilot-fix.js
 * ---------------------------------------------------------------------------
 * Instalador idempotente para AutoSocial Studio que:
 *   1. Crea src/x-auth.js  (login/import de cookies + publicacion real en X).
 *   2. Reescribe src/x-autopilot.js (worker arrancable, timezone correcto,
 *      sin fallback basura, timeouts/reintentos, cadena de IA con fallback,
 *      reconciliacion de cola y publicacion via navegador).
 *   3. Parchea src/dashboard-server.js: arranca el worker y expone endpoints
 *      de login/cookies/estado de X.
 *   4. Parchea web/index.html y web/app.js: UI de sesion de X + botones.
 *   5. Anade x-autopilot-state.json a .gitignore.
 *
 * Uso:  node instalar-x-autopilot-fix.js
 * Es seguro ejecutarlo varias veces: cada bloque lleva un marcador unico.
 */

const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const MARK = {
  auth: "// MARKER: XAP-AUTH-v1",
  engine: "// MARKER: XAP-ENGINE-v2",
  serverStart: "// MARKER: XAP-WORKER-START-v1",
  serverRoutes: "// MARKER: XAP-ROUTES-v1",
  gitignore: "# MARKER: XAP-IGNORE-v1",
  html: "<!-- MARKER: XAP-UI-v1 -->",
  jsBind: "// MARKER: XAP-BIND-v1",
  jsRender: "// MARKER: XAP-RENDER-v1",
  jsHandlers: "// MARKER: XAP-HANDLERS-v1",
};

const results = [];
function ok(msg) { results.push(["OK", msg]); }
function skip(msg) { results.push(["SKIP", msg]); }
function fail(msg) { results.push(["FAIL", msg]); }

function read(rel) {
  const full = path.join(ROOT, rel);
  if (!fs.existsSync(full)) return null;
  return fs.readFileSync(full, "utf8");
}
function write(rel, text) {
  const full = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, "utf8");
}
function backup(rel) {
  const full = path.join(ROOT, rel);
  if (!fs.existsSync(full)) return;
  const bak = `${full}.xap-backup`;
  if (!fs.existsSync(bak)) fs.copyFileSync(full, bak);
}
function replaceOnce(text, needle, replacement, label) {
  const index = text.indexOf(needle);
  if (index === -1) throw new Error(`No se encontro el punto de insercion: ${label}`);
  if (text.indexOf(needle, index + needle.length) !== -1) {
    // Multiple matches: use last occurrence style replacement is risky, so fall back to first.
  }
  return text.slice(0, index) + replacement + text.slice(index + needle.length);
}

// ---------------------------------------------------------------------------
// 0. Sanity check
// ---------------------------------------------------------------------------
if (!fs.existsSync(path.join(ROOT, "package.json")) || !fs.existsSync(path.join(ROOT, "src", "x-autopilot.js"))) {
  console.error("ERROR: ejecuta este instalador desde la raiz de AutoSocial Studio.");
  process.exit(1);
}

// ---------------------------------------------------------------------------
// 1. src/x-auth.js
// ---------------------------------------------------------------------------
(function installAuth() {
  const content = read("src/x-auth.js");
  if (content && content.includes(MARK.auth)) { skip("src/x-auth.js ya estaba instalado"); return; }
  const payload = readAsset("x-auth.js");
  write("src/x-auth.js", payload);
  ok("src/x-auth.js creado");
})();

// ---------------------------------------------------------------------------
// 2. src/x-autopilot.js
// ---------------------------------------------------------------------------
(function installEngine() {
  const content = read("src/x-autopilot.js");
  if (content && content.includes(MARK.engine)) { skip("src/x-autopilot.js ya estaba parcheado"); return; }
  backup("src/x-autopilot.js");
  write("src/x-autopilot.js", readAsset("x-autopilot.js"));
  ok("src/x-autopilot.js reescrito (v2)");
})();

// ---------------------------------------------------------------------------
// 3. src/dashboard-server.js -- arrancar worker + rutas
// ---------------------------------------------------------------------------
(function installServer() {
  let text = read("src/dashboard-server.js");
  if (!text) { fail("src/dashboard-server.js no encontrado"); return; }

  if (!text.includes(MARK.serverStart)) {
    const match = text.match(/const xAutopilot\s*=\s*require\((["'])\.\/x-autopilot\1\);/);
    if (!match) {
      // The module might be required inline in route handlers; inject the require.
      const anchor = 'const googleFlow = require("./google-flow");';
      if (!text.includes(anchor)) { fail("dashboard-server.js: no se encontro require de google-flow"); return; }
      text = replaceOnce(text, anchor, `${anchor}\nconst xAutopilot = require("./x-autopilot");`, "googleFlow require");
    }
    const boot = `\n  ${MARK.serverStart}\n  try { xAutopilot.startWorker(); } catch (error) { console.error("[x-autopilot] no se pudo arrancar el worker:", error.message); }`;
    const listenAnchor = "  ensureDashboardBindAllowed();";
    text = replaceOnce(text, listenAnchor, `${boot}\n\n${listenAnchor}`, "arranque del worker");
    ok("dashboard-server.js: worker de X Autopilot arrancado al inicio");
  } else {
    skip("dashboard-server.js: worker ya arrancado");
  }

  if (!text.includes(MARK.serverRoutes)) {
    const routes = `
  ${MARK.serverRoutes}
  app.get("/api/x-autopilot/session", async (req, res) => {
    try { res.json(await xAutopilot.getStatus((await getActiveAccount()).id)); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/login", async (req, res) => {
    try { res.json(await require("./x-auth").startLoginSession()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/login/save", async (req, res) => {
    try { res.json(await require("./x-auth").saveLoginSession()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/login/close", async (req, res) => {
    try { res.json(await require("./x-auth").closeLoginSession()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/cookies", async (req, res) => {
    try {
      const result = await require("./x-auth").importCookies(req.body?.cookies);
      res.status(result.ok ? 200 : 400).json(result);
    } catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/retry", async (req, res) => {
    try { res.json(await xAutopilot.retryFailed((await getActiveAccount()).id)); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });
`;
    const anchor = `app.get("/api/google-flow/status"`;
    text = replaceOnce(text, anchor, `${routes}\n  ${anchor}`, "rutas google-flow");
    ok("dashboard-server.js: endpoints de sesion de X anadidos");
  } else {
    skip("dashboard-server.js: endpoints de X ya presentes");
  }

  write("src/dashboard-server.js", text);
})();

// ---------------------------------------------------------------------------
// 4. .gitignore
// ---------------------------------------------------------------------------
(function installGitignore() {
  const rel = ".gitignore";
  let text = read(rel) || "";
  if (text.includes(MARK.gitignore)) { skip(".gitignore ya parcheado"); return; }
  text += `\n${MARK.gitignore}\nx-autopilot-state.json\nx-autopilot-state.json.tmp\n.runtime/cookies\n`;
  write(rel, text.replace(/^\n+/, ""));
  ok(".gitignore: estado de X y cookies ignorados");
})();

// ---------------------------------------------------------------------------
// 5. web/index.html -- banner de sesion de X
// ---------------------------------------------------------------------------
(function installHtml() {
  let text = read("web/index.html");
  if (!text) { fail("web/index.html no encontrado"); return; }
  if (text.includes(MARK.html)) { skip("web/index.html ya tiene la UI de X"); write("web/index.html", text); return; }

  const block = `
        ${MARK.html}
        <div id="xLoginBanner" class="tt-login-banner card" style="margin-bottom:14px;">
          <div class="tt-login-row">
            <span class="tt-login-icon"><i class="ph ph-x-logo"></i></span>
            <div class="tt-login-text">
              <strong id="xLoginTitle">Sesion de X (Twitter)</strong>
              <span id="xLoginMessage">Inicia sesion en la ventana de X o pega tus cookies para publicar automaticamente.</span>
            </div>
            <span id="xLoginStateBadge" class="status-badge">Sin comprobar</span>
            <button id="xLoginBtn" class="control-btn-small primary"><i class="ph ph-browser"></i> Iniciar sesion</button>
            <button id="xLoginSaveBtn" class="control-btn-small success"><i class="ph ph-floppy-disk"></i> Guardar sesion</button>
            <button id="xLoginCloseBtn" class="control-btn-small danger"><i class="ph ph-x"></i> Cerrar</button>
            <button id="xRetryBtn" class="control-btn-small" title="Reprogramar los posts que fallaron"><i class="ph ph-arrows-clockwise"></i> Reintentar fallidos</button>
          </div>
          <div style="display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; align-items:flex-start;">
            <textarea id="xCookiesInput" rows="2" placeholder="O pega aqui tus cookies de X (formato header: auth_token=...; ct0=...  o JSON exportado)" style="flex:1; min-width:260px; font-family:monospace; font-size:11px; padding:8px; border-radius:8px; border:1px solid var(--border-color, #2a2a2a); background:var(--bg-input, #111); color:inherit; resize:vertical;"></textarea>
            <button id="xCookiesBtn" class="control-btn-small"><i class="ph ph-key"></i> Importar cookies</button>
          </div>
        </div>
`;
  // Insert right before the first dashboard-grid of the x-autopilot view.
  const viewAnchor = 'id="view-x-autopilot"';
  const viewIndex = text.indexOf(viewAnchor);
  if (viewIndex === -1) { fail("web/index.html: no se encontro la vista x-autopilot"); return; }
  const gridIndex = text.indexOf('<div class="x-grid">', viewIndex);
  if (gridIndex === -1) { fail("web/index.html: no se encontro el grid de x-autopilot"); return; }
  text = text.slice(0, gridIndex) + block + "\n" + text.slice(gridIndex);
  write("web/index.html", text);
  ok("web/index.html: banner de sesion de X anadido");
})();

// ---------------------------------------------------------------------------
// 6. web/app.js -- elementos, binding, render y handlers
// ---------------------------------------------------------------------------
(function installAppJs() {
  let text = read("web/app.js");
  if (!text) { fail("web/app.js no encontrado"); return; }

  if (!text.includes(MARK.jsBind)) {
    const anchor = "xReferencesList: document.getElementById(\"xReferencesList\")";
    if (!text.includes(anchor)) { fail("web/app.js: no se encontro xReferencesList en els"); write("web/app.js", text); return; }
    const addition = `${anchor},\n    xLoginBanner: document.getElementById("xLoginBanner"), xLoginTitle: document.getElementById("xLoginTitle"), xLoginMessage: document.getElementById("xLoginMessage"), xLoginStateBadge: document.getElementById("xLoginStateBadge"), xLoginBtn: document.getElementById("xLoginBtn"), xLoginSaveBtn: document.getElementById("xLoginSaveBtn"), xLoginCloseBtn: document.getElementById("xLoginCloseBtn"), xCookiesInput: document.getElementById("xCookiesInput"), xCookiesBtn: document.getElementById("xCookiesBtn"), xRetryBtn: document.getElementById("xRetryBtn"),\n    ${MARK.jsBind}`;
    text = replaceOnce(text, anchor, addition, "els de x login");
    ok("web/app.js: elementos de X registrados");
  } else {
    skip("web/app.js: elementos de X ya registrados");
  }

  if (!text.includes(MARK.jsHandlers)) {
    const bindAnchor = 'if (this.els.xReferenceBtn) this.els.xReferenceBtn.addEventListener("click", () => this.addXReference());';
    const binding = `${MARK.jsHandlers}\n    if (this.els.xLoginBtn) this.els.xLoginBtn.addEventListener("click", () => this.xLoginOpen());\n    if (this.els.xLoginSaveBtn) this.els.xLoginSaveBtn.addEventListener("click", () => this.xLoginSave());\n    if (this.els.xLoginCloseBtn) this.els.xLoginCloseBtn.addEventListener("click", () => this.xLoginClose());\n    if (this.els.xCookiesBtn) this.els.xCookiesBtn.addEventListener("click", () => this.xImportCookies());\n    if (this.els.xRetryBtn) this.els.xRetryBtn.addEventListener("click", () => this.xRetryFailed());\n    if (this.els.xReferenceBtn) this.els.xReferenceBtn.addEventListener("click", () => this.addXReference());`;
    text = replaceOnce(text, bindAnchor, binding, "bind de x login");
    ok("web/app.js: botones de sesion de X enlazados");
  } else {
    skip("web/app.js: botones de X ya enlazados");
  }

  if (!text.includes(MARK.jsRender)) {
    const renderAnchor = "  async refresh() {";
    const renderCall = `  ${MARK.jsRender}\n  async refreshXSession() {\n    try {\n      const data = await API.get("/api/x-autopilot/session");\n      this.renderXSession(data);\n    } catch (error) {\n      if (this.els.xLoginStateBadge) this.els.xLoginStateBadge.textContent = "Sin sesion";\n    }\n  },\n\n  renderXSession(data) {\n    if (!this.els.xLoginStateBadge) return;\n    const session = data?.session || {};\n    const ready = Boolean(session.saved);\n    this.els.xLoginStateBadge.textContent = ready ? "Sesion guardada" : (session.open ? "Ventana abierta" : "Sin sesion");\n    this.els.xLoginStateBadge.className = "status-badge" + (ready ? " success" : "");\n    if (this.els.xLoginMessage) {\n      this.els.xLoginMessage.textContent = ready\n        ? "Sesion de X lista. La publicacion automatica usara esta cuenta."\n        : "Aun no hay sesion guardada. Inicia sesion en la ventana de X o pega tus cookies.";\n    }\n    const worker = data?.worker ? "worker activo" : "worker detenido";\n    if (this.els.xLoginTitle) this.els.xLoginTitle.textContent = "Sesion de X (Twitter) - " + worker;\n  },\n\n  async xLoginOpen() { try { await API.post("/api/x-autopilot/login", {}); await this.refreshXSession(); } catch (error) { alert(error.message); } },\n  async xLoginSave() { try { const r = await API.post("/api/x-autopilot/login/save", {}); if (r && r.ok === false) throw new Error(r.error); await this.refreshXSession(); } catch (error) { alert(error.message); } },\n  async xLoginClose() { try { await API.post("/api/x-autopilot/login/close", {}); await this.refreshXSession(); } catch (error) { alert(error.message); } },\n  async xImportCookies() {\n    const value = this.els.xCookiesInput?.value || "";\n    if (!value.trim()) { alert("Pega tus cookies primero."); return; }\n    try {\n      const r = await API.post("/api/x-autopilot/cookies", { cookies: value });\n      if (r && r.ok === false) throw new Error(r.error);\n      if (this.els.xCookiesInput) this.els.xCookiesInput.value = "";\n      await this.refreshXSession();\n    } catch (error) { alert(error.message); }\n  },\n  async xRetryFailed() { try { await API.post("/api/x-autopilot/retry", {}); await this.refreshXAutopilot(); } catch (error) { alert(error.message); } },\n\n  async refreshXAutopilot() { try { const data = await API.get("/api/x-autopilot"); this.renderXAutopilot(data); } catch {} },\n\n${renderAnchor}`;
    text = replaceOnce(text, renderAnchor, renderCall, "refresh");
    ok("web/app.js: handlers de sesion de X anadidos");
  } else {
    skip("web/app.js: handlers de X ya presentes");
  }

  // Enlazar la llamada al refresco.
  if (!text.includes("this.refreshXSession()")) {
    const hook = 'API.get("/api/x-autopilot").then((data) => this.renderXAutopilot(data)).catch(() => { });';
    const withHook = `${hook}\n      this.refreshXSession();`;
    text = replaceOnce(text, hook, withHook, "hook de refresco de sesion");
    ok("web/app.js: refresco de sesion enlazado");
  }

  write("web/app.js", text);
})();

// ---------------------------------------------------------------------------
// Helper: leer assets embebidos
// ---------------------------------------------------------------------------
function readAsset(name) {
  const candidates = [
    path.join(__dirname, "assets", name),
    path.join(ROOT, "assets", name),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return fs.readFileSync(candidate, "utf8");
  }
  throw new Error(`No se encontro el asset ${name} (junto al instalador o en assets/).`);
}

// ---------------------------------------------------------------------------
// Resumen
// ---------------------------------------------------------------------------
console.log("\n=== AutoSocial Studio - X Autopilot Fix ===");
for (const [status, message] of results) {
  console.log(`  [${status}] ${message}`);
}
const failures = results.filter(([status]) => status === "FAIL");
console.log(`\n${results.length - failures.length - results.filter(([s]) => s === "SKIP").length} cambios aplicados, ${results.filter(([s]) => s === "SKIP").length} ya presentes, ${failures.length} errores.`);
if (failures.length) {
  console.error("\nRevisa los errores de arriba antes de arrancar el dashboard.");
  process.exitCode = 1;
} else {
  console.log("\nReinicia el dashboard (node src/dashboard-server.js) y abre la pestana X Autopilot.");
}
