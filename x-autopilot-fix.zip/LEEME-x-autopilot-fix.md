# AutoSocial Studio — X Autopilot Fix + Publicación automática en X

Este paquete arregla el módulo **X Autopilot** y añade **login real de X (Twitter)**
por usuario o por cookies, para que pueda publicar de forma automática.

## Qué se arregla

| # | Problema detectado | Estado |
|---|---|---|
| 1 | El worker del cron **nunca se arrancaba**: la casilla "generación diaria autónoma" no hacía nada | Arreglado: el worker se inicia con el dashboard |
| 2 | **Bug de zona horaria**: un horario `09:00` se guardaba como `09:00 UTC` (publicaba a las 11:00 en España) | Arreglado con `luxon` y la zona `Europe/Madrid` |
| 3 | Si no había API key de IA, generaba una **plantilla de relleno** y la encolaba como post real | Arreglado: ahora **bloquea** y avisa |
| 4 | Sin timeout, sin reintentos; un 429/500 abortaba todo el lote | Arreglado: timeout 45s + 3 reintentos con espera |
| 5 | La cola **duplicaba** el lote del día al pulsar dos veces "Generar ahora" | Arreglado: detecta pendientes y no duplica |
| 6 | No había reintento de posts fallidos; pendientes antiguos se publicaban en cadena | Añadido botón "Reintentar fallidos"; los pendientes de +3 días expiran |
| 7 | `maxCharacters` decía 4000 pero el corte real no avisaba | Arreglado: valida y avisa del límite real (280 free / 4000 premium) |
| 8 | `x-autopilot-state.json` (con claves) no estaba en `.gitignore` | Añadido al `.gitignore` |
| 9 | Una sola IA, sin respaldo | Cadena IA con **fallback** (p. ej. principal OpenAI → respaldo Gemini) |

## Qué se añade

- **Login de X por navegador**: botón "Iniciar sesión" abre Chromium con un perfil
  persistente (`.profiles/<cuenta>/x`). Inicias sesión una vez, pulsas "Guardar sesión"
  y ya puedes publicar automáticamente sin repetir el login.
- **Login de X por cookies**: pega tus cookies (`auth_token` y `ct0`) en formato
  `auth_token=...; ct0=...` o en JSON exportado. Se guardan en `.runtime/cookies/<cuenta>.txt`
  con permisos `0600`.
- **Publicación real en X** desde el navegador: los posts pasan de la cola al
  compositor de X y se publican solos (modo `live`).
- Nuevos endpoints: `/api/x-autopilot/session`, `/login`, `/login/save`, `/login/close`,
  `/cookies`, `/retry`.

## Instalación (Windows)

1. Copia **esta carpeta entera** (con `instalar-x-autopilot-fix.js` y la carpeta `assets`)
   dentro de la raíz del proyecto AutoSocial Studio, junto a `package.json`.
2. Abre una terminal en la raíz del proyecto y ejecuta:

   ```bat
   node instalar-x-autopilot-fix.js
   ```

3. Reinicia el dashboard:

   ```bat
   node src/dashboard-server.js
   ```

4. Abre la pestaña **X Autopilot**.

El instalador es **idempotente**: puedes ejecutarlo varias veces sin romper nada.
Hace copia de seguridad de los archivos que toca como `*.xap-backup`.

## Cómo dejarlo publicando solo

1. En **Sesión de X**, pulsa **Iniciar sesión**, entra en tu cuenta en la ventana que
   se abre y pulsa **Guardar sesión**. (Alternativa sin ventana: pega tus cookies y pulsa
   **Importar cookies**; quedan guardadas y verificadas.)
2. En **Modo de publicación**, elige **API oficial de X**. En esta versión el modo `live`
   publica **usando la sesión de X que acabas de guardar** (navegador o cookies), así que
   no necesitas ningún token de la API de X.
3. Rellena **Usuario X**, **Posts diarios** y **Horarios** (en tu hora local).
4. Elige el proveedor de IA, pega la **API key** y, opcionalmente, una clave de respaldo
   con su proveedor.
5. Marca **Activar generación diaria autónoma** y pulsa **Guardar**.
6. Verás el **Worker detenido/activo** en la cabecera y la sesión como
   **Sesión guardada**.

## Seguridad

- Las claves de IA y las cookies **no se devuelven** al frontend (se muestran como
  `configured`).
- Las cookies se guardan en código Netscape con permisos `0600`.
- `/tmp` y la carpeta `assets` de este paquete son auxiliares; el archivo que importa
  es `instalar-x-autopilot-fix.js` + `assets/`.
- Si pegaste claves en un chat, **revócalas y genera nuevas**; guárdalas solo en la app.
