# Arreglo de subida de TikTok — 3 parches

Ejecuta los 3 en este orden desde la raíz de AutoSocial Studio (donde está package.json):

    node instalar-subida-tiktok.js          # arregla "No se encontró el campo de subida"
    node instalar-programar-tiktok.js       # no confunde el aviso de "procesando" con un error
    node instalar-espera-procesado-tiktok.js # espera a que TikTok procese el vídeo antes de programar + arregla la ubicación duplicada

Luego reinicia el dashboard:

    node src/dashboard-server.js

Son idempotentes: puedes ejecutarlos varias veces sin problema. Cada uno hace copia de seguridad
del archivo antes de tocarlo (tiktok-uploader.js.tiktok-backup, .tiktok-schedule-backup,
.tiktok-processing-backup).

Orden recomendado: subida -> programar -> espera-procesado. Si ya tenías alguno instalado, el
instalador lo detectará y no repetirá el cambio.
