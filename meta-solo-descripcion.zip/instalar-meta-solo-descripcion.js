#!/usr/bin/env node
/**
 * instalar-meta-solo-descripcion.js
 *
 * Cambia los metadatos de los videos para que SOLO se use la "description".
 * En TikTok no hay titulo: el "title" que devuelve yt-dlp viene truncado con
 * "..." y la "description" ya contiene el texto completo y los hashtags.
 *
 * Resultado del sidecar <video>.meta.json:
 *   { "description": "...", "caption": "...", "downloadIndex": 0 }
 *
 * Se ELIMINAN los campos "title" y "hashtags" (ya viven dentro de la
 * description) y se MANTIENEN "caption" y "downloadIndex".
 *
 * - Idempotente: segunda pasada no cambia nada (0 cambios).
 * - Hace backup de cada archivo antes de tocarlo (*.desc-backup).
 * - Falla ruidosamente si un anclaje esperado no aparece.
 *
 * Uso:  node instalar-meta-solo-descripcion.js
 *       node instalar-meta-solo-descripcion.js "C:\\ruta\\autosocial-studio"
 */

const fs = require("fs");
const path = require("path");

const MARK = "META-DESC-ONLY-v1";
const normalizeIdxArg = process.argv.indexOf("--normalize");
const ONLY_NORMALIZE = normalizeIdxArg !== -1;
const ROOT = path.resolve((process.argv[2] && !process.argv[2].startsWith("--")) ? process.argv[2] : process.cwd());
const changes = [];

function log(msg) {
  console.log(msg);
}

function fail(msg) {
  console.error("\nERROR: " + msg);
  process.exit(1);
}

function read(rel) {
  const abs = path.join(ROOT, rel);
  if (!fs.existsSync(abs)) fail(`No encuentro ${rel}. ¿Estas en la carpeta del proyecto?`);
  return fs.readFileSync(abs, "utf8");
}

function write(rel, before, after) {
  if (before === after) return false;
  const abs = path.join(ROOT, rel);
  const backup = abs + ".desc-backup";
  if (!fs.existsSync(backup)) fs.copyFileSync(abs, backup);
  fs.writeFileSync(abs, after, "utf8");
  changes.push(rel);
  return true;
}

/** Reemplaza exactamente una vez; falla si hay 0 o >1 coincidencias. */
function replaceOnce(rel, src, oldStr, newStr, label) {
  const count = src.split(oldStr).length - 1;
  if (count === 0) {
    fail(`Anclaje no encontrado en ${rel} (${label}).\n---\n${oldStr}\n---`);
  }
  if (count > 1) {
    fail(`Anclaje ambiguo en ${rel} (${label}): ${count} coincidencias.`);
  }
  log(`  - ${label}`);
  return src.replace(oldStr, newStr);
}

// ---------------------------------------------------------------------------
// 1) src/queue.js  -> buildCaptionFromMeta usa SOLO la description
// ---------------------------------------------------------------------------
if (ONLY_NORMALIZE) {
  log("Modo --normalize: no se toca el codigo, solo los .meta.json.");
} else {
log("\n[1/5] src/queue.js -> caption solo con description");

let queue = read("src/queue.js");

if (queue.includes(MARK)) {
  log("  = ya aplicado, se salta");
} else {
  const OLD_CAPTION = `/** Merge title, description and hashtags into a single TikTok caption. */
function buildCaptionFromMeta({ title = "", description = "", hashtags = [] } = {}) {
  const parts = [];
  const cleanTitle = String(title || "").trim();
  const cleanDescription = String(description || "").trim();
  // Skip the title when TikTok's description already starts with it (very common).
  if (cleanTitle && !cleanDescription.toLowerCase().startsWith(cleanTitle.toLowerCase())) {
    parts.push(cleanTitle);
  }
  if (cleanDescription) parts.push(cleanDescription);

  let text = parts.join("\\n").trim();
  const existing = new Set((text.match(/#[\\p{L}\\p{N}_]+/gu) || []).map((t) => t.toLowerCase()));
  const missing = hashtags
    .map((t) => String(t || "").replace(/^#+/, "").trim())
    .filter(Boolean)
    .filter((tag) => !existing.has(\`#\${tag}\`.toLowerCase()));
  if (missing.length) {
    text = text ? \`\${text} \${missing.map((t) => \`#\${t}\`).join(" ")}\` : missing.map((t) => \`#\${t}\`).join(" ");
  }
  return text.trim();
}`;

  const NEW_CAPTION = `/**
 * ${MARK}
 * TikTok no tiene titulo: solo descripcion. El "title" de yt-dlp viene
 * truncado con "..." y la descripcion ya incluye el texto y los hashtags.
 * Por eso el caption es EXACTAMENTE la descripcion (sin duplicar ni anadir
 * hashtags por separado). Si no hay descripcion, cae al titulo como ultimo
 * recurso. Los parametros se aceptan por compatibilidad con las llamadas.
 */
function buildCaptionFromMeta({ title = "", description = "" } = {}) {
  const cleanDescription = String(description || "").trim();
  if (cleanDescription) return cleanDescription;
  return stripTruncation(String(title || ""));
}

/** Quita el sufijo de truncado que TikTok pone en los titulos ("..." / "…"). */
function stripTruncation(text) {
  return String(text || "").replace(/\\s*(?:\\.\\.\\.|…)\\s*$/, "").trim();
}`;

  queue = replaceOnce("src/queue.js", queue, OLD_CAPTION, NEW_CAPTION, "buildCaptionFromMeta -> solo description");

  // exports: anadir stripTruncation
  queue = replaceOnce(
    "src/queue.js",
    queue,
    "module.exports = {\n  readCaption,\n  readVideoMeta,\n  buildCaptionFromMeta,",
    "module.exports = {\n  readCaption,\n  readVideoMeta,\n  buildCaptionFromMeta,\n  stripTruncation,",
    "exportar stripTruncation"
  );

  write("src/queue.js", read("src/queue.js"), queue);
}

// ---------------------------------------------------------------------------
// 2) src/queue.js -> readVideoMeta devuelve description + caption + downloadIndex
// ---------------------------------------------------------------------------
log("\n[2/5] src/queue.js -> readVideoMeta sin title/hashtags");

queue = read("src/queue.js");
if (queue.includes("SIDECAR-DESC-ONLY")) {
  log("  = ya aplicado, se salta");
} else {
  const OLD_READ = `/**
 * Read the companion metadata for a video. Returns null when there is none.
 * Shape: { title, description, hashtags: string[], caption: string }
 */
async function readVideoMeta(videoPath) {
  try {
    const raw = await fs.readFile(getMetaPath(videoPath), "utf8");
    const data = JSON.parse(raw);
    const title = String(data.title || "").trim();
    const description = String(data.description || "").trim();
    const hashtags = Array.isArray(data.hashtags)
      ? data.hashtags.map((t) => String(t).replace(/^#+/, "").trim()).filter(Boolean)
      : extractHashtags(\`\${title} \${description}\`);
    const caption = buildCaptionFromMeta({ title, description, hashtags });
    const downloadIndex = Number.isInteger(data.downloadIndex) ? data.downloadIndex : null;
    return { title, description, hashtags, caption, downloadIndex };
  } catch {
    return null;
  }
}`;

  const NEW_READ = `/**
 * SIDECAR-DESC-ONLY
 * Read the companion metadata for a video. Returns null when there is none.
 * Shape: { description, caption, downloadIndex }
 *
 * Solo se conserva la descripcion (que ya incluye los hashtags). Los campos
 * "title" y "hashtags" de sidecars antiguos se ignoran a proposito: el titulo
 * de TikTok viene truncado y los hashtags duplicarian lo que ya hay.
 */
async function readVideoMeta(videoPath) {
  try {
    const raw = await fs.readFile(getMetaPath(videoPath), "utf8");
    const data = JSON.parse(raw);
    const description = String(data.description || "").trim();
    // El caption SIEMPRE se regenera desde la description: los sidecars
    // antiguos traen un caption con el titulo truncado duplicado.
    const caption = buildCaptionFromMeta({ description });
    const downloadIndex = Number.isInteger(data.downloadIndex) ? data.downloadIndex : null;
    return { description, caption, downloadIndex };
  } catch {
    return null;
  }
}`;

  queue = replaceOnce("src/queue.js", queue, OLD_READ, NEW_READ, "readVideoMeta -> description/caption/downloadIndex");
  write("src/queue.js", read("src/queue.js"), queue);
}

// ---------------------------------------------------------------------------
// 3) src/video-meta.js -> metaFromInfoJson solo description
// ---------------------------------------------------------------------------
log("\n[3/5] src/video-meta.js -> metaFromInfoJson solo description");

let vm = read("src/video-meta.js");
if (vm.includes(MARK)) {
  log("  = ya aplicado, se salta");
} else {
  const OLD_META = `/**
 * Build the companion metadata object from a yt-dlp info.json payload.
 * Prefers explicit fields, falls back to hashtags embedded in the text.
 */
function metaFromInfoJson(info = {}) {
  const title = String(info.title || info.fulltitle || "").trim();
  const description = String(info.description || "").trim();
  const explicitTags = normalizeTagList(info.tags || info.hashtags || []);
  const hashtags = explicitTags.length ? explicitTags : extractHashtags(\`\${title} \${description}\`);
  const caption = buildCaptionFromMeta({ title, description, hashtags });
  return { title, description, hashtags, caption };
}`;

  const NEW_META = `/**
 * ${MARK}
 * Build the companion metadata object from a yt-dlp info.json payload.
 * TikTok no tiene titulo: la descripcion trae el texto completo y los
 * hashtags. El "title" de yt-dlp viene truncado con "..." y los "tags"
 * repetirian lo que ya esta en la descripcion, asi que se descartan.
 * Shape: { description, caption }
 */
function metaFromInfoJson(info = {}) {
  const description = String(info.description || "").trim();
  return { description, caption: buildCaptionFromMeta({ description }) };
}`;

  vm = replaceOnce("src/video-meta.js", vm, OLD_META, NEW_META, "metaFromInfoJson -> description/caption");
  write("src/video-meta.js", read("src/video-meta.js"), vm);
}

// ---------------------------------------------------------------------------
// 4) src/video-meta.js -> translateMetaToSpanish solo description
// ---------------------------------------------------------------------------
log("\n[4/5] src/video-meta.js -> traduccion solo description");

vm = read("src/video-meta.js");
if (vm.includes("TRANS-DESC-ONLY")) {
  log("  = ya aplicado, se salta");
} else {
  const OLD_TR = `/** Translate title and description to Spanish while preserving hashtags. */
async function translateMetaToSpanish(meta, {
  apiKey = "",
  paidApiKey = "",
  paidModel = "gemini-3.6-flash",
  openRouterKey = "",
  logger = null,
} = {}) {
  const original = {
    title: String(meta.title || "").trim(),
    description: String(meta.description || "").trim(),
    hashtags: normalizeTagList(meta.hashtags || []),
  };
  const prompt = [
    "Traduce los campos title y description al espanol.",
    "Conserva los hashtags exactamente sin cambios, incluidos los que aparecen dentro del titulo y la descripcion.",
    "Devuelve exactamente este JSON: {\\"title\\":\\"\\",\\"description\\":\\"\\",\\"hashtags\\":[\\"\\"]}",
    JSON.stringify(original),
  ].join("\\n");`;

  const NEW_TR = `/**
 * TRANS-DESC-ONLY
 * Translate the description to Spanish while preserving hashtags.
 */
async function translateMetaToSpanish(meta, {
  apiKey = "",
  paidApiKey = "",
  paidModel = "gemini-3.6-flash",
  openRouterKey = "",
  logger = null,
} = {}) {
  const original = {
    description: String(meta.description || "").trim(),
  };
  const prompt = [
    "Traduce el campo description al espanol.",
    "Conserva los hashtags exactamente sin cambios.",
    "Devuelve exactamente este JSON: {\\"description\\":\\"\\"}",
    JSON.stringify(original),
  ].join("\\n");`;

  vm = replaceOnce("src/video-meta.js", vm, OLD_TR, NEW_TR, "translateMetaToSpanish -> solo description");

  const OLD_TR2 = `  let lastError = null;
  for (const request of providers) {
    try {
      const translated = parseTranslationJson(await request());
      const title = preserveTitleHashtags(translated.title || original.title, original.title);
      const description = preserveHashtagsInText(translated.description || original.description, original.description);
      const result = {
        title,
        description,
        hashtags: original.hashtags,
        caption: buildCaptionFromMeta({ title, description, hashtags: original.hashtags }),
      };
      logger?.("Metadatos traducidos al espanol para Auto Post.");`;

  const NEW_TR2 = `  let lastError = null;
  for (const request of providers) {
    try {
      const translated = parseTranslationJson(await request());
      const description = preserveHashtagsInText(translated.description || original.description, original.description);
      const result = {
        description,
        caption: buildCaptionFromMeta({ description }),
      };
      logger?.("Metadatos traducidos al espanol para Auto Post.");`;

  vm = replaceOnce("src/video-meta.js", vm, OLD_TR2, NEW_TR2, "resultado traducido -> description/caption");

  write("src/video-meta.js", read("src/video-meta.js"), vm);
}

// ---------------------------------------------------------------------------
// 5) src/video-meta.js -> log de escritura
// ---------------------------------------------------------------------------
log("\n[5/5] src/video-meta.js -> log sin hashtags");

vm = read("src/video-meta.js");
if (vm.includes("Wrote metadata: %s")) {
  log("  = ya aplicado, se salta");
} else {
  const OLD_LOG = 'logger?.(`Wrote metadata: ${path.basename(metaPath)} (title, description, ${meta.hashtags.length} hashtag(s))`);';
  const NEW_LOG = 'logger?.(`Wrote metadata: ${path.basename(metaPath)} (description)`);';
  if (vm.includes(OLD_LOG)) {
    vm = replaceOnce("src/video-meta.js", vm, OLD_LOG, NEW_LOG, "log de metadatos");
    write("src/video-meta.js", read("src/video-meta.js"), vm);
  } else {
    log("  ! no encontrado (se continua)");
  }
}

// ---------------------------------------------------------------------------
// 6) src/autoclone/index.js -> la lista usa description (ya no hay title)
// ---------------------------------------------------------------------------
log("\n[6/6] src/autoclone/index.js -> la lista muestra la description");

let acIndex = read("src/autoclone/index.js");
if (acIndex.includes("META-DESC-ONLY-LIST")) {
  log("  = ya aplicado, se salta");
} else {
  const OLD_LIST = `      items.push({
        name: path.basename(videoPath),
        hasMeta: Boolean(meta),
        title: meta?.title || "",
      });`;
  const NEW_LIST = `      items.push({
        name: path.basename(videoPath),
        hasMeta: Boolean(meta),
        // META-DESC-ONLY-LIST: TikTok no tiene titulo; mostramos la descripcion.
        title: meta?.description || "",
        description: meta?.description || "",
      });`;
  acIndex = replaceOnce("src/autoclone/index.js", acIndex, OLD_LIST, NEW_LIST, "lista -> description");
  write("src/autoclone/index.js", read("src/autoclone/index.js"), acIndex);
}

// ---------------------------------------------------------------------------
// Resumen
// ---------------------------------------------------------------------------
} // fin del bloque de codigo (se salta en modo --normalize)

if (!ONLY_NORMALIZE) {
log("\n----------------------------------------");
if (changes.length === 0) {
  log("Sin cambios: ya estaba instalado.");
} else {
  log(`Cambios aplicados en ${changes.length} archivo(s):`);
  for (const rel of changes) log(`  * ${rel}  (backup: ${rel}.desc-backup)`);
}
log("");
log("Siguiente paso: reinicia el dashboard (npm start) para que tome los cambios.");
log("Los videos ya descargados conservan su .meta.json antiguo; se puede");
log("normalizar la cola con: node instalar-meta-solo-descripcion.js --normalize <carpeta>");
log("");
}

// ---------------------------------------------------------------------------
// Modo extra: normalizar .meta.json existentes  (--normalize <carpeta>)
// ---------------------------------------------------------------------------
if (ONLY_NORMALIZE) {
  const targetDir = path.resolve(process.argv[normalizeIdxArg + 1] || ".");
  log(`\nNormalizando .meta.json en ${targetDir} ...`);
  let touched = 0;
  const walk = (dir) => {
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === "node_modules" || entry.name === ".git") continue;
        walk(full);
        continue;
      }
      if (!entry.name.endsWith(".meta.json")) continue;
      try {
        const data = JSON.parse(fs.readFileSync(full, "utf8"));
        const out = {
          description: String(data.description || "").trim(),
          caption: String(data.description || "").trim(),
        };
        if (Number.isInteger(data.downloadIndex)) out.downloadIndex = data.downloadIndex;
        const next = JSON.stringify(out, null, 2);
        if (next !== JSON.stringify(data, null, 2)) {
          fs.copyFileSync(full, full + ".desc-backup");
          fs.writeFileSync(full, next, "utf8");
          touched += 1;
        }
      } catch {
        // Ignora archivos corruptos.
      }
    }
  };
  walk(targetDir);
  log(`  ${touched} archivo(s) normalizado(s).`);
}
