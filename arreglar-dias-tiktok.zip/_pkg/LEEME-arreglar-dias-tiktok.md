# Arreglo: los dias/fecha no se aplicaban al programar en TikTok

## Que arregla
Marcas dias en el dashboard y al subir a TikTok el video NO se programaba en esos
dias (se quedaba en el dia de hoy, o daba error y no terminaba).

## Causa real (vista en tu HTML del calendario)
El calendario de TikTok NO tiene boton "mes siguiente". El mes y el anio se cambian
haciendo clic en el TITULO del calendario ("September / 2026").

El codigo buscaba un boton "next", pero en esa pantalla ese boton esta DESHABILITADO
(es de otra lista). Por eso hacia 15 intentos sin avanzar de mes y la fecha nunca
llegaba al mes que querias. Tambien buscaba las celdas de dia mal: las reales son
"div.day".

Hemos reescrito esa parte para que:
- Lea el mes/anio del titulo (.month-title / .year-title).
- Cambie de mes clicando ese titulo (el desplegable real de TikTok).
- Seleccione el dia en su celda correcta (.days-wrapper .day).

## Como usarlo (Windows / Git Bash)
1. Cierra el dashboard (Ctrl+C).
2. En la carpeta del proyecto:
   C:\Users\msi\Downloads\autosocial-studio
3. Copia `arreglar-dias-tiktok.js` a esa carpeta.
4. Ejecuta:
   node arreglar-dias-tiktok.js
5. Arranca de nuevo:
   npm run dashboard

Debe decir: "reemplazada setTikTokDate".

## Deshacer
   node arreglar-dias-tiktok.js --revert

## Seguridad
- Idempotente: si lo ejecutas dos veces, no pasa nada.
- Hace copia .bak antes de tocar nada.
- NO toca la interfaz ni ninguna otra parte del programa.
