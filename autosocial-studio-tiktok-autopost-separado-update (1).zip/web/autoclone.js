/* Auto Clone — one-button pipeline UI. Relies on the global `API` helper. */
(function initAutoClone() {
  const $ = (id) => document.getElementById(id);

  const els = {
    username: $("autocloneUsername"),
    videoUrl: $("autocloneVideoUrl"),
    videoBtn: $("autocloneVideoBtn"),
    videoHint: $("autocloneVideoHint"),
    startBtn: $("autocloneStartBtn"),
    renameByDateBtn: $("autocloneRenameByDateBtn"),
    downloadOnlyBtn: $("autocloneDownloadOnlyBtn"),
    orderByDateBtn: $("autocloneOrderByDateBtn"),
    maxVideos: $("autocloneMaxVideos"),
    downloadOrder: $("autocloneDownloadOrder"),
    downloadThumbnail: $("autocloneDownloadThumbnail"),
    startMode: $("autocloneStartMode"),
    resetHistoryBtn: $("autocloneResetHistoryBtn"),
    intensity: $("autocloneIntensity"),
    metadataLanguage: $("autocloneMetadataLanguage"),
    uniquify: $("autocloneUniquify"),
    translate: $("autocloneTranslate"),
    karaoke: $("autocloneKaraoke"),
    cancelBtn: $("autocloneCancelBtn"),
    keyBtn: $("autocloneKeyBtn"),
    keyPanel: $("autocloneKeyPanel"),
    apiKey: $("autocloneApiKey"),
    saveKeyBtn: $("autocloneSaveKeyBtn"),
    keyStatus: $("autocloneKeyStatus"),
    keyBadge: $("autocloneKeyBadge"),
    barFill: $("autocloneBarFill"),
    stage: $("autocloneStage"),
    modeloActivo: $("autocloneModeloActivo"), // XKI[indicador][els]
    modeloDetalle: $("autocloneModeloDetalle"),
    modeloHistorial: $("autocloneModeloHistorial"),
    videos: $("autocloneVideos"),
    analysis: $("autocloneAnalysis"),
    destination: $("autocloneDestination"),
    destHint: $("autocloneDestHint"),
    openFolderBtn: $("autocloneOpenFolderBtn"),
    deepSeekKey: $("autocloneDeepSeekKey"),
    saveDeepSeekKeyBtn: $("autocloneSaveDeepSeekKeyBtn"),
    deepSeekStatus: $("autocloneDeepSeekStatus"), // DS[ui-els]
    xKiroKey: $("autocloneXKiroKey"), // XKC[js][els]
    saveXKiroKeyBtn: $("autocloneSaveXKiroKeyBtn"),
    xKiroStatus: $("autocloneXKiroStatus"),
  };
  if (!els.startBtn) return;

  let events = null;
  let currentJobId = null;
  let renderedSignature = "";
  let lastJobId = null;

  const DEST_KEY = "autoclone.destination";
  const INTENSITY_KEY = "autoclone.intensity";
  const METADATA_LANGUAGE_KEY = "autoclone.metadataLanguage";
  const DOWNLOAD_ORDER_KEY = "autoclone.downloadOrder";
  const DOWNLOAD_THUMBNAIL_KEY = "autoclone.downloadThumbnail";
  const START_MODE_KEY = "autoclone.startMode";
  const KARAOKE_KEY = "autoclone.karaoke";

  function loadDestination() {
    try { return localStorage.getItem(DEST_KEY) || ""; } catch { return ""; }
  }
  function saveDestination(value) {
    try { localStorage.setItem(DEST_KEY, value); } catch { /* ignore */ }
  }
  function saveIntensity(value) {
    try { localStorage.setItem(INTENSITY_KEY, value); } catch { /* ignore */ }
  }
  function saveDownloadOrder(value) {
    try { localStorage.setItem(DOWNLOAD_ORDER_KEY, value); } catch { /* ignore */ }
  }
  function saveDownloadThumbnail(value) {
    try { localStorage.setItem(DOWNLOAD_THUMBNAIL_KEY, value ? "true" : "false"); } catch { /* ignore */ }
  }
  if (els.destination) els.destination.value = loadDestination();
  if (els.downloadOrder) {
    try {
      const saved = localStorage.getItem(DOWNLOAD_ORDER_KEY);
      if (saved === "oldest" || saved === "recent") els.downloadOrder.value = saved;
    } catch { /* ignore */ }
    els.downloadOrder.addEventListener("change", () => saveDownloadOrder(els.downloadOrder.value));
  }
  if (els.downloadThumbnail) {
    try { els.downloadThumbnail.checked = localStorage.getItem(DOWNLOAD_THUMBNAIL_KEY) === "true"; } catch { /* ignore */ }
    els.downloadThumbnail.addEventListener("change", () => saveDownloadThumbnail(els.downloadThumbnail.checked));
  }
  function saveStartMode(value) {
    try { localStorage.setItem(START_MODE_KEY, value); } catch { /* ignore */ }
  }
  if (els.karaoke) {
    try { els.karaoke.checked = localStorage.getItem(KARAOKE_KEY) === "true"; } catch { /* ignore */ }
    els.karaoke.addEventListener("change", () => {
      try { localStorage.setItem(KARAOKE_KEY, els.karaoke.checked ? "true" : "false"); } catch { /* ignore */ }
    });
  }
  if (els.startMode) {
    try {
      const saved = localStorage.getItem(START_MODE_KEY);
      if (saved === "continue" || saved === "restart") els.startMode.value = saved;
    } catch { /* ignore */ }
    els.startMode.addEventListener("change", () => saveStartMode(els.startMode.value));
  }
  if (els.intensity) {
    try {
      const saved = localStorage.getItem(INTENSITY_KEY);
      if (saved) els.intensity.value = saved;
    } catch { /* ignore */ }
    els.intensity.addEventListener("change", () => saveIntensity(els.intensity.value));
  }
  if (els.metadataLanguage) {
    try {
      const saved = localStorage.getItem(METADATA_LANGUAGE_KEY);
      if (saved) els.metadataLanguage.value = saved;
    } catch { /* ignore */ }
    els.metadataLanguage.addEventListener("change", () => {
      try { localStorage.setItem(METADATA_LANGUAGE_KEY, els.metadataLanguage.value); } catch { /* ignore */ }
    });
  }
  const esc = (value) => String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  function setBar(percent) {
    els.barFill.style.width = `${Math.max(0, Math.min(100, Number(percent) || 0))}%`;
  }

  // XKI[indicador][poll] inicio - preguntar al backend que modelo va
  let modeloPollTimer = null;
  async function refrescarModelo() {
    if (!els.modeloActivo) return;
    try {
      const d = await API.get("/api/autoclone/modelo");
      const prov = d.proveedor || "—";
      const corto = d.corto || "";
      const provEl = els.modeloActivo.querySelector(".autoclone-modelo-prov");
      const idEl = els.modeloActivo.querySelector(".autoclone-modelo-id");
      if (provEl) provEl.textContent = prov;
      if (idEl) idEl.textContent = corto || "Sin actividad";
      els.modeloActivo.classList.toggle("activo", Boolean(d.modelo));
      els.modeloActivo.classList.toggle("es-deepseek", prov === "DeepSeek");
      els.modeloActivo.classList.toggle("es-xkiro", prov === "xKiro");
      els.modeloActivo.classList.toggle("es-gemini", prov === "Gemini");
      if (els.modeloDetalle) {
        els.modeloDetalle.textContent = d.modelo
          ? `${d.detalle || prov} · hace ${d.segundos}s` + (d.totalLotes ? ` · lote ${d.lote}/${d.totalLotes}` : "")
          : "Sin actividad. Cuando empiece el trabajo, vera aqui el modelo en uso.";
      }
      if (els.modeloHistorial) {
        const h = (d.historial || []).slice(0, 6);
        els.modeloHistorial.innerHTML = h.length
          ? h.map(x => `<span class="autoclone-chip">${x.proveedor}: ${escapeHtmlJs(x.corto)}</span>`).join("")
          : "";
      }
    } catch { /* si falla, no molestamos */ }
  }
  function escapeHtmlJs(s) { return String(s == null ? "" : s).replace(/[&<>\"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "\"":"&quot;", "'":"&#39;" }[c])); }
  function iniciarIndicadorModelo() {
    if (modeloPollTimer) return;
    refrescarModelo();
    modeloPollTimer = setInterval(refrescarModelo, 1000);
  }
  function pararIndicadorModelo() {
    if (modeloPollTimer) { clearInterval(modeloPollTimer); modeloPollTimer = null; }
  }
  // XKI[indicador][poll] fin

  async function refreshKeyState() {
    try {
      const data = await API.get("/api/competitor/settings");
      const hasKey = Boolean(data.settings?.hasGeminiKey);
      els.keyBadge.textContent = hasKey ? "IA lista" : "Sin API de IA";
      els.keyBadge.classList.toggle("ok", hasKey);
      els.keyBadge.classList.toggle("warn", !hasKey);
      if (els.keyStatus) {
        els.keyStatus.textContent = hasKey
          ? `API key guardada (${data.settings?.geminiKeyMasked || "oculta"}). El texto en pantalla se traducirá automáticamente.`
          : "No hay API key. Sin ella no se puede traducir el texto en pantalla.";
      }
      if (els.deepSeekStatus) {
        els.deepSeekStatus.textContent = data.settings?.hasDeepSeekKey
          ? `DeepSeek configurado (${data.settings?.deepSeekKeyMasked || "oculta"}).`
          : "DeepSeek sin configurar.";
      } // DS[ui-state]

      if (els.xKiroStatus) { // XKC[js][render]
        els.xKiroStatus.textContent = data.settings?.hasXKiroKey
          ? `xKiro configurado (${data.settings?.xKiroKeyMasked || "oculta"}). Rotacion activa en AutoClone.`
          : "xKiro sin configurar. AutoClone usara Gemini directamente.";
      }
      return hasKey;
    } catch {
      els.keyBadge.textContent = "Sin API de IA";
      return false;
    }
  }

  async function saveKey() {
    const key = els.apiKey.value.trim();
    if (!key) { els.keyStatus.textContent = "Escribe una API key válida."; return; }
    els.saveKeyBtn.disabled = true;
    try {
      await API.post("/api/competitor/settings", { geminiApiKey: key });
      els.apiKey.value = "";
      els.keyStatus.textContent = "API key guardada.";
      await refreshKeyState();
    } catch (error) {
      els.keyStatus.textContent = error.message;
    } finally {
      els.saveKeyBtn.disabled = false;
    }
  }

  async function saveXKiroKey() { // XKC[js][func]
    const key = els.xKiroKey.value.trim();
    if (!key) { els.xKiroStatus.textContent = "Escribe la API key de xKiro."; return; }
    els.saveXKiroKeyBtn.disabled = true;
    try {
      await API.post("/api/competitor/settings", { xKiroApiKey: key });
      els.xKiroKey.value = "";
      els.xKiroStatus.textContent = "API key de xKiro guardada.";
    } catch (error) {
      els.xKiroStatus.textContent = error.message;
    } finally {
      els.saveXKiroKeyBtn.disabled = false;
    }
  }

  async function saveDeepSeekKey() {
    const key = els.deepSeekKey.value.trim();
    if (!key) { els.deepSeekStatus.textContent = "Escribe la API key de DeepSeek."; return; }
    els.saveDeepSeekKeyBtn.disabled = true;
    try {
      await API.post("/api/competitor/settings", { deepSeekApiKey: key });
      els.deepSeekKey.value = "";
      els.deepSeekStatus.textContent = "API key de DeepSeek guardada.";
      await refreshKeyState();
    } catch (error) {
      els.deepSeekStatus.textContent = error.message;
    } finally {
      els.saveDeepSeekKeyBtn.disabled = false;
    }
  }

  function renderJob(job) { // DS[ui-save]
    if (!job) return;
    if (job.analysis && (job.analysis.summary || job.analysis.error)) {
      els.analysis.hidden = false;
      if (job.analysis.error) {
        els.analysis.innerHTML = `<div class="card"><div class="card-title">Análisis del perfil</div>
          <p class="autoclone-empty">No se pudo completar el análisis: ${esc(job.analysis.error)}</p></div>`;
      } else {
        els.analysis.innerHTML = `<div class="card">
          <div class="card-title">Análisis del perfil ${esc(job.handle)}</div>
          <p>${esc(job.analysis.summary || "")}</p>
          <div class="autoclone-metrics">
            <span><strong>${esc(job.analysis.metrics?.avgViews ?? "—")}</strong> vistas medias</span>
            <span><strong>${esc(job.analysis.metrics?.videoCount ?? job.videos?.length ?? "—")}</strong> vídeos</span>
            <span><strong>${esc(job.analysis.metrics?.engagementRate ?? "—")}</strong> engagement</span>
          </div>
        </div>`;
      }
    }

    const videos = job.videos || [];
    const signature = videos.map((v) => `${v.id}:${v.status}:${v.publishStatus || ""}:${v.translated ? 1 : 0}:${v.textBoxes || 0}:${v.error || ""}:${v.publishError || ""}:${(v.notes || []).join(";")}`).join("|");
    if (signature !== renderedSignature) {
      renderedSignature = signature;
      els.videos.innerHTML = videos.map((video, index) => {
        const publishFailed = video.publishStatus === "failed";
        const label = publishFailed ? "Fallo al publicar" : video.publishStatus === "published" ? "Publicado" : video.status === "done" ? "Listo" : video.status === "error" ? "Error" : "Pendiente";
        const cls = publishFailed || video.status === "error" ? "err" : video.status === "done" ? "ok" : "wait";
        const tags = [];
        if (video.translated) tags.push(`texto traducido (${video.textBoxes})`);
        else if (video.status === "done") tags.push("sin texto traducible");
        if (video.karaoke) tags.push("karaoke");
        if (video.publishStatus === "published") tags.push("publicado en cuenta destino");
        if (publishFailed) tags.push("guardado en failed");
        const notes = [...(video.notes || []), video.error, video.publishError].filter(Boolean);
        // "No translatable text" is just information, not an error, so it stays
        // in a neutral tone; real failures are shown in red.
        const onlyInfo = (note) => /no se detecto texto|sin texto traducible|no se pudo traducir/i.test(note);
        return `<div class="autoclone-video">
          <span class="autoclone-video-idx">${index + 1}</span>
          <div class="autoclone-video-body">
            <span class="autoclone-video-id">${esc(video.id)}</span>
            <span class="autoclone-video-tags">${tags.map(esc).join(" · ") || "—"}</span>
            ${notes.map((n) => `<span class="${onlyInfo(n) ? "autoclone-video-note" : "autoclone-video-err"}">${esc(n)}</span>`).join("")}
          </div>
          <span class="autoclone-video-status ${cls}">${label}</span>
           ${video.status === "done" && !video.publishStatus ? `<a class="control-btn-small" href="/api/autoclone/jobs/${encodeURIComponent(job.id)}/download?video=${encodeURIComponent(video.id)}" download>Descargar</a>` : ""}
        </div>`;
      }).join("") || `<p class="autoclone-empty">Aún no hay vídeos en este lote.</p>`;
    }
  }

  async function pollJob() {
    if (!currentJobId) return;
    try {
      const data = await API.get(`/api/autoclone/jobs/${encodeURIComponent(currentJobId)}`);
      renderJob(data.job);
    } catch { /* job may not be flushed yet */ }
  }

  function connectEvents() {
    if (events) events.close();
    events = new EventSource("/api/autoclone/events");
    events.onmessage = (event) => {
      let progress;
      try { progress = JSON.parse(event.data); } catch { return; }
      if (progress.detail) els.stage.textContent = progress.detail;
      if (typeof progress.percent === "number") setBar(progress.percent);
      const running = !["idle", "done", "error", "cancelled"].includes(progress.stage);
      if (typeof iniciarIndicadorModelo === "function") {
        if (running) iniciarIndicadorModelo(); else pararIndicadorModelo();
      } // XKI[indicador][bind]
      els.cancelBtn.hidden = !running;
      els.startBtn.disabled = running;
      if (els.downloadOnlyBtn) els.downloadOnlyBtn.disabled = running;
      if (progress.stage === "done" || progress.stage === "error" || progress.stage === "cancelled") {
        els.startBtn.disabled = false;
        els.cancelBtn.hidden = true;
        pollJob();
      } else if (["download", "translate", "uniquify", "publish"].includes(progress.stage)) {
        pollJob();
      }
    };
    events.onerror = () => { /* EventSource auto-reconnects */ };
  }

  // Descargar es un paso independiente de AutoPost: solo deja los vídeos en
  // la carpeta elegida y nunca abre TikTok para publicarlos.
  async function startDownloadOnly() {
    const username = (els.username.value || "").trim();
    if (!username) {
      els.stage.textContent = "Escribe un @usuario de TikTok para descargar sus videos nuevos.";
      return;
    }
    const destinationRoot = els.destination?.value.trim() || "";
    els.downloadOnlyBtn.disabled = true;
    els.startBtn.disabled = true;
    renderedSignature = "";
    els.videos.innerHTML = `<p class="autoclone-empty">Descargando los videos nuevos...</p>`;
    els.analysis.hidden = true;
    setBar(1);
    try {
      const data = await API.post("/api/autoclone/start-download", {
        username,
        maxVideos: Number(els.maxVideos.value) || 0,
        downloadOrder: els.downloadOrder?.value || "oldest",
        downloadThumbnail: Boolean(els.downloadThumbnail?.checked),
        startMode: els.startMode?.value || "continue",
        destinationRoot,
      });
      currentJobId = data.id;
      lastJobId = data.id;
      saveDestination(destinationRoot);
      saveDownloadOrder(els.downloadOrder?.value || "oldest");
      saveDownloadThumbnail(Boolean(els.downloadThumbnail?.checked));
      saveStartMode(els.startMode?.value || "continue");
      updateDestHint(data.handle || username, destinationRoot);
       els.stage.textContent = data.folder
         ? `Descargando videos nuevos de ${data.handle}. Guardando en ${data.folder}`
         : `Descargando videos nuevos de ${data.handle}.`;
      connectEvents();
    } catch (error) {
      els.downloadOnlyBtn.disabled = false;
      els.startBtn.disabled = false;
      els.stage.textContent = error.message;
      setBar(0);
    }
  }

  async function start(override = {}) {
    const videoUrl = (override.videoUrl ?? els.videoUrl?.value ?? "").trim();
    const username = (override.username ?? els.username.value).trim();
    if (!videoUrl && !username) {
      els.stage.textContent = "Escribe un usuario de TikTok o pega la URL de un vídeo.";
      return;
    }
    const destinationRoot = els.destination?.value.trim() || "";
    els.startBtn.disabled = true;
    if (els.videoBtn) els.videoBtn.disabled = true;
    renderedSignature = "";
    els.videos.innerHTML = `<p class="autoclone-empty">Preparando el lote...</p>`;
    els.analysis.hidden = true;
    setBar(1);
    try {
      const data = await API.post("/api/autoclone/start", {
        username,
        videoUrl,
        maxVideos: Number(els.maxVideos.value) || 0,
         uniquify: els.uniquify.checked,
         translate: els.translate.checked,
         karaoke: Boolean(els.karaoke?.checked),
         uniquifyIntensity: els.intensity?.value || "media",
         metadataLanguage: els.metadataLanguage?.value || "es",
         downloadOrder: els.downloadOrder?.value || "oldest",
         downloadThumbnail: Boolean(els.downloadThumbnail?.checked),
         startMode: els.startMode?.value || "continue",
         destinationRoot,
      });
      currentJobId = data.id;
      lastJobId = data.id;
       saveDestination(destinationRoot);
       saveDownloadOrder(els.downloadOrder?.value || "oldest");
       saveDownloadThumbnail(Boolean(els.downloadThumbnail?.checked));
       saveStartMode(els.startMode?.value || "continue");
      saveIntensity(els.intensity?.value || "media");
      updateDestHint(data.handle || username, destinationRoot);
      els.stage.textContent = data.singleVideo
        ? `Clonando el vídeo indicado.${data.folder ? ` Guardando en ${data.folder}` : ""}`
        : (data.folder
          ? `Trabajo iniciado para ${data.handle}. Guardando en ${data.folder}`
          : `Trabajo iniciado para ${data.handle}.`);
      connectEvents();
    } catch (error) {
      els.startBtn.disabled = false;
      if (els.videoBtn) els.videoBtn.disabled = false;
      els.stage.textContent = error.message;
      setBar(0);
    }
  }

  function updateDestHint(username, destinationRoot) {
    if (!els.destHint) return;
    const clean = String(username || "").replace(/^@/, "").replace(/^https?:\/\/[^/]+\/?/, "").replace(/\/.*$/, "") || "usuario";
    if (destinationRoot) {
      const sep = destinationRoot.includes("\\") ? "\\" : "/";
      els.destHint.innerHTML = `Se guardarán en <b>${esc(destinationRoot.replace(/[\\/]+$/, ""))}${sep}${esc(clean)}</b>.`;
    } else {
      els.destHint.innerHTML = `Sin carpeta elegida, se guardarán en la carpeta interna <b>.runtime/autoclone</b>. Cada usuario tendrá su propia subcarpeta.`;
    }
  }

  async function openFolder() {
    try {
      const data = await API.post("/api/autoclone/open-folder", { jobId: lastJobId || currentJobId || "" });
      if (data.folder) els.stage.textContent = `Carpeta abierta: ${data.folder}`;
    } catch (error) {
      els.stage.textContent = error.message;
    }
  }

  // Show how many videos of this profile were already downloaded, so "where I
  // left off" is never a mystery.
  async function refreshHistory() {
    if (!els.resetHistoryBtn) return;
    const username = els.username.value.trim();
    if (!username) return;
    try {
      const data = await API.get(`/api/autoclone/history?username=${encodeURIComponent(username)}`);
      els.resetHistoryBtn.title = data.count
        ? `Ya descargados de este perfil: ${data.count}. Pulsa para empezar de cero.`
        : "Este perfil no tiene descargas anteriores.";
      els.resetHistoryBtn.innerHTML = `<i class="ph ph-arrow-counter-clockwise"></i> Reiniciar contador${data.count ? ` (${data.count})` : ""}`;
    } catch { /* ignore */ }
  }

  async function resetHistory() {
    const username = els.username.value.trim();
    if (!username) { els.stage.textContent = "Escribe un nombre de usuario de TikTok."; return; }
    if (!window.confirm(`¿Olvidar los vídeos ya descargados de ${username}? La próxima vez empezará desde el primero.`)) return;
    try {
      await API.post("/api/autoclone/history/reset", { username });
      els.stage.textContent = `Contador reiniciado para ${username}. La próxima descarga empezará desde el primero.`;
      await refreshHistory();
    } catch (error) {
      els.stage.textContent = error.message;
    }
  }

  // Pone la fecha delante del nombre de cada video ya descargado.
  async function renameByDate() {
    const folder = (els.destination?.value || "").trim();
    if (!folder) { els.stage.textContent = "Escribe la carpeta de los videos en 'Carpeta de destino'."; return; }
    if (!window.confirm("Renombrar los videos de " + folder + " con la fecha delante (ej. 2024-01-15_id.mp4)?")) return;
    els.renameByDateBtn.disabled = true;
    try {
      const data = await API.post("/api/autoclone/rename-by-date", { folder });
      els.stage.textContent = data.already
        ? "Todos los videos de esa carpeta ya tienen la fecha en el nombre."
        : "Renombrados " + data.renamed + " videos" + (data.withoutDate ? " (" + data.withoutDate + " sin fecha, sin cambios)." : ".");
      if (data.items?.length) {
        els.videos.innerHTML = data.items.slice(0, 300).map((item, i) =>
          `<div class="autoclone-video"><span class="autoclone-video-idx">${i + 1}</span>`
          + `<div class="autoclone-video-body"><span class="autoclone-video-id">${escapeHtmlJs(item.after)}</span>`
          + `<span class="autoclone-video-tags">${item.changed ? "renombrado" : "sin fecha"}</span></div></div>`
        ).join("");
      }
    } catch (error) {
      els.stage.textContent = error.message;
    } finally {
      els.renameByDateBtn.disabled = false;
    }
  }

  // Reordena la carpeta de destino por la fecha real de publicacion.
  async function orderByDate() {
    const folder = (els.destination?.value || "").trim();
    if (!folder) { els.stage.textContent = "Escribe la carpeta de los videos en 'Carpeta de destino'."; return; }
    if (!window.confirm("Reordenar los videos de " + folder + " de mas antiguo a mas nuevo?")) return;
    els.orderByDateBtn.disabled = true;
    try {
      const data = await API.post("/api/autoclone/order-by-date", { folder });
      els.stage.textContent = "Orden actualizado: " + data.withDate + " videos con fecha"
        + (data.withoutDate ? " y " + data.withoutDate + " sin fecha (al final)." : ".");
      if (data.order?.length) {
        els.videos.innerHTML = data.order.slice(0, 300).map((item, i) =>
          `<div class="autoclone-video"><span class="autoclone-video-idx">${i + 1}</span>`
          + `<div class="autoclone-video-body"><span class="autoclone-video-id">${escapeHtmlJs(item.name)}</span>`
          + `<span class="autoclone-video-tags">${item.uploadedAt ? "publicado " + escapeHtmlJs(item.uploadedAt.slice(0, 10)) : "sin fecha"}</span></div></div>`
        ).join("");
      }
    } catch (error) {
      els.stage.textContent = error.message;
    } finally {
      els.orderByDateBtn.disabled = false;
    }
  }

  async function cancel() {
    try { await API.post("/api/autoclone/cancel", {}); } catch { /* ignore */ }
  }

  els.startBtn.addEventListener("click", () => start());
  els.downloadOnlyBtn?.addEventListener("click", startDownloadOnly);
  els.videoBtn?.addEventListener("click", () => {
    const url = (els.videoUrl?.value || "").trim();
    if (!url) { els.stage.textContent = "Pega la URL del vídeo de TikTok que quieres clonar."; return; }
    start({ videoUrl: url });
  });
  els.videoUrl?.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      const url = els.videoUrl.value.trim();
      if (url) start({ videoUrl: url });
    }
  });
  els.cancelBtn.addEventListener("click", cancel);
  els.orderByDateBtn?.addEventListener("click", orderByDate);
  els.renameByDateBtn?.addEventListener("click", renameByDate);
  els.keyBtn.addEventListener("click", () => { els.keyPanel.hidden = !els.keyPanel.hidden; });
  els.saveKeyBtn.addEventListener("click", saveKey);
  els.saveDeepSeekKeyBtn?.addEventListener("click", saveDeepSeekKey); // DS[ui-bind]
  els.saveXKiroKeyBtn?.addEventListener("click", saveXKiroKey); // XKC[js][bind]
  els.username.addEventListener("keydown", (event) => { if (event.key === "Enter") start(); });
  els.openFolderBtn?.addEventListener("click", openFolder);
  els.resetHistoryBtn?.addEventListener("click", resetHistory);
  els.username?.addEventListener("blur", refreshHistory);
  els.username?.addEventListener("change", refreshHistory);
  els.destination?.addEventListener("change", () => {
    saveDestination(els.destination.value.trim());
    updateDestHint(els.username.value.trim(), els.destination.value.trim());
  });
  updateDestHint("", loadDestination());

  document.addEventListener("autosocial:viewchange", (event) => {
    if (event.detail?.viewName === "autoclone") {
      refreshKeyState();
      API.get("/api/autoclone/progress").then((data) => {
        if (data.progress?.detail) els.stage.textContent = data.progress.detail;
        if (typeof data.progress?.percent === "number") setBar(data.progress.percent);
        if (data.running) connectEvents();
      if (typeof iniciarIndicadorModelo === "function") iniciarIndicadorModelo(); // XKI[indicador][start]
      }).catch(() => {});
    }
  });

  refreshKeyState();
  refreshHistory();
})();
