#!/usr/bin/env node
/*
 * CALENTADOR TIKTOK (AutoSocial Studio)
 * ==================================================================
 * Anade a la pagina "TikTok / Auto Post" dos botones:
 *     [ Iniciar calentamiento ]   [ Parar ]
 *
 * Al pulsar "Iniciar calentamiento" sobre LA CUENTA SELECCIONADA, abre su
 * perfil de TikTok (.profiles/<cuenta>/tiktok) en Chromium INVISIBLE
 * (headless), entra a "Para ti" y baja de video automaticamente cada 4 s
 * (con un pelin de aleatorio para que no parezca un robot). Sigue hasta
 * que pulses "Parar".
 *
 * - Solo scroll pasivo: sin likes, sin comentarios, sin abrir perfiles.
 * - Cada cuenta es independiente: su perfil, su proceso, su estado.
 * - No usa extensiones ni mueve tu raton.
 *
 * Uso:
 *   node instalar-calentador-tiktok.js            (aplica; idempotente)
 *   node instalar-calentador-tiktok.js --revert   (revierte)
 *
 * Crea copias de seguridad *.bak-WARMER-TIKTOK-<fecha> de cada archivo.
 * Ejecutalo desde la carpeta del proyecto (donde esta package.json).
 */

const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const args = new Set(process.argv.slice(2));
const REVERT = args.has("--revert") || args.has("--undo");
const MARK = "WARMER-TIKTOK";

function log(msg) { console.log(`[${MARK}] ${msg}`); }

function read(rel) {
  const full = path.resolve(ROOT, rel);
  if (!fs.existsSync(full)) throw new Error(`No encuentro ${rel}. Ejecuta esto desde la carpeta del proyecto.`);
  return fs.readFileSync(full, "utf8");
}

function write(rel, text) {
  const full = path.resolve(ROOT, rel);
  const backup = `${full}.bak-${MARK}-${Date.now()}`;
  if (fs.existsSync(full)) fs.copyFileSync(full, backup);
  fs.writeFileSync(full, text, "utf8");
  log(`escrito ${rel} (backup: ${path.basename(backup)})`);
}

function mustReplace(src, needle, replacement, label) {
  if (!src.includes(needle)) {
    throw new Error(
      `No encontrado el punto de anclaje: ${label}. Puede que el proyecto haya cambiado; ` +
      `avisa a tu asistente con esta linea.`
    );
  }
  return src.replace(needle, replacement);
}

/* ==================================================================
 * MODULO NUEVO: src/tiktok-warmer.js
 * Se escribe tal cual desde este archivo (autocontenido).
 * ================================================================== */

function warmerModuleSource() {
  return String.raw`/**
 * CALENTADOR-TIKTOK: motor de calentamiento de cuentas de TikTok.
 *
 * Abre el MISMO perfil persistente que usa la app (.profiles/<cuenta>/tiktok),
 * entra al "Para ti" (For You) y hace auto-scroll cada pocos segundos, sin
 * raton y sin extensiones. Cada cuenta corre en su propio proceso Playwright,
 * totalmente aislada de las demas.
 *
 * Por defecto abre una VENTANA VISIBLE (headed) con la cuenta. Se puede pedir
 * headless:true para modo invisible.
 *
 * Solo scroll pasivo (sin likes, sin comentarios, sin abrir perfiles).
 * Arranca con "start", se detiene con "stop", y va guardando su estado.
 *
 * AUTOSUFICIENTE: no depende de que el servidor le inyecte la ruta del perfil.
 * Resuelve .profiles/<cuenta>/tiktok por su cuenta.
 */
"use strict";

const fs = require("fs");
const path = require("path");

const DEFAULT_SCROLL_MS = 4000;   // cada cuanto baja de video
const JITTER_MS = 1200;           // +/- aleatorio para no ser perfecto
const BOOT_TIMEOUT_MS = 60000;    // esperar a que cargue el For You

/** Estado en memoria por cuenta (una sola instancia por proceso). */
const sessions = new Map();

function log(msg) {
  const stamp = new Date().toISOString().slice(11, 19);
  console.log("[calentador " + stamp + "] " + msg);
}

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Quita los candados huerfanos de Chromium que dejo un cierre brusco.
 * Sin esto, launchPersistentContext falla con "profile in use".
 */
function clearStaleLocks(dir) {
  for (const lock of ["SingletonLock", "SingletonCookie", "SingletonSocket"]) {
    try { fs.rmSync(path.join(dir, lock), { force: true }); } catch {}
  }
}

async function resolveChromium() {
  try {
    return require("playwright").chromium;
  } catch (e) {
    throw new Error(
      "Playwright no esta instalado. Ejecuta: npx playwright install chromium"
    );
  }
}

/**
 * Resuelve la carpeta del perfil persistente de TikTok de una cuenta.
 * Intenta, en orden: account-manager del proyecto, deps inyectadas, y por
 * ultimo la convencion .profiles/<cuenta>/tiktok.
 */
function resolveProfileDir(accountId, deps) {
  // 1) Lo mas fiable: el propio account-manager del proyecto.
  try {
    const am = require("../src/account-manager");
    if (am && typeof am.getPlatformProfileDir === "function") {
      return am.getPlatformProfileDir("tiktok", accountId);
    }
  } catch { /* sigue */ }
  try {
    const am = require("./account-manager");
    if (am && typeof am.getPlatformProfileDir === "function") {
      return am.getPlatformProfileDir("tiktok", accountId);
    }
  } catch { /* sigue */ }

  // 2) Funcion inyectada por el llamador, si la hubiera.
  if (deps && typeof deps.getPlatformProfileDir === "function") {
    return deps.getPlatformProfileDir("tiktok", accountId);
  }

  // 3) Convencion del proyecto.
  return path.resolve(process.cwd(), ".profiles", accountId, "tiktok");
}

/**
 * Crea el modulo. Todas las dependencias son OPCIONALES: si no vienen, se
 * resuelven solas desde el proyecto.
 * @param {Object} [deps]
 * @param {(platform:string, accountId:string)=>string} [deps.getPlatformProfileDir]
 * @param {(accountId:string)=>Promise<Object>} [deps.requireAccount]
 */
function createTikTokWarmer(deps = {}) {
  const requireAccount = deps.requireAccount || (async (id) => ({ id, name: id }));

  /** Devuelve el estado publico de una cuenta. */
  function publicState(accountId) {
    const s = sessions.get(accountId);
    if (!s) return { accountId, running: false, startedAt: null, elapsedMs: 0, scrollCount: 0, lastError: "" };
    return {
      accountId,
      running: s.running,
      startedAt: s.startedAt,
      elapsedMs: s.startedAt ? Date.now() - s.startedAt : 0,
      scrollCount: s.scrollCount,
      lastError: s.lastError || "",
    };
  }

  /** Arranca el calentamiento de UNA cuenta. Si ya corre, no hace nada. */
  async function start(accountId, options = {}) {
    const account = await requireAccount(accountId);
    if (sessions.has(accountId) && sessions.get(accountId).running) {
      return { ok: true, alreadyRunning: true, ...publicState(accountId) };
    }

    const scrollMs = Number(options.scrollMs) > 0 ? Number(options.scrollMs) : DEFAULT_SCROLL_MS;
    // Por defecto VISIBLE (headed), como pidio el usuario.
    const headless = options.headless === true;
    const profileDir = resolveProfileDir(account.id, deps);

    const session = {
      accountId: account.id,
      running: true,
      startedAt: Date.now(),
      scrollCount: 0,
      lastError: "",
      stopRequested: false,
      context: null,
      page: null,
      loopPromise: null,
      wake: null,
    };
    sessions.set(account.id, session);

    // Espera interrumpible e inmune a carreras: si "stop" se pide mientras el
    // bucle esta ocupado (p.ej. evaluando en la pagina), no se duerme de mas.
    const WAKE_POLL_MS = 250;
    function interruptibleSleep(ms) {
      return new Promise((resolve) => {
        if (session.stopRequested) return resolve();
        const deadline = Date.now() + ms;
        let timer = null;
        const check = () => {
          if (session.stopRequested || Date.now() >= deadline) {
            if (timer) clearTimeout(timer);
            session.wake = null;
            return resolve();
          }
          timer = setTimeout(check, Math.min(WAKE_POLL_MS, Math.max(1, deadline - Date.now())));
        };
        check();
        session.wake = () => { if (timer) clearTimeout(timer); session.wake = null; resolve(); };
      });
    }

    session.loopPromise = (async () => {
      const chromium = await resolveChromium();
      clearStaleLocks(profileDir);
      log("iniciando @" + (account.name || account.id) + " -> " + profileDir + (headless ? " (invisible)" : " (ventana)"));

      const context = await chromium.launchPersistentContext(profileDir, {
        headless,
        viewport: { width: 1280, height: 900 },
        args: [
          "--disable-blink-features=AutomationControlled",
          "--autoplay-policy=no-user-gesture-required",
          "--mute-audio",
        ],
      });
      session.context = context;

      const page = context.pages()[0] || (await context.newPage());
      session.page = page;
      await page.goto("https://www.tiktok.com/foryou", {
        waitUntil: "domcontentloaded",
        timeout: BOOT_TIMEOUT_MS,
      }).catch(() => {});

      // Intentar que el video corra de verdad (una sola vez).
      await page.evaluate(() => {
        const v = document.querySelector("video");
        if (v) {
          v.muted = true;
          const p = v.play();
          if (p && p.catch) p.catch(() => {});
        }
      }).catch(() => {});

      while (!session.stopRequested && session.running) {
        try {
          const moved = await page.evaluate((px) => {
            window.scrollBy({ top: px, behavior: "smooth" });
            return true;
          }, rand(600, 820)).catch(() => false);

          if (moved) session.scrollCount += 1;

          // Deja el video nuevo corriendo.
          await page.evaluate(() => {
            const v = document.querySelector("video");
            if (v && typeof v.play === "function") { v.muted = true; const p = v.play(); if (p && p.catch) p.catch(() => {}); }
          }).catch(() => {});
        } catch (e) {
          session.lastError = String((e && e.message) || e);
        }
        // Intervalo humano: base + jitter, siempre positivo.
        await interruptibleSleep(Math.max(500, scrollMs + rand(-JITTER_MS, JITTER_MS)));
      }
    })()
      .catch((e) => {
        session.lastError = String((e && e.message) || e);
        log("error en @" + (account.name || account.id) + ": " + session.lastError);
      })
      .finally(async () => {
        session.running = false;
        try { if (session.context) await session.context.close(); } catch {}
        session.context = null;
        session.page = null;
        log("detenido @" + (account.name || account.id) + " (" + session.scrollCount + " bajadas)");
      });

    return { ok: true, ...publicState(account.id) };
  }

  /** Pide parar el calentamiento de UNA cuenta (cierre limpio e inmediato). */
  function stop(accountId) {
    const s = sessions.get(accountId);
    if (!s || !s.running) return { ok: true, running: false, ...publicState(accountId) };
    s.stopRequested = true;
    if (typeof s.wake === "function") { try { s.wake(); } catch { /* ignore */ } }
    return { ok: true, running: false, stopping: true, ...publicState(accountId) };
  }

  /** Para TODAS las cuentas en calentamiento (util al cerrar el dashboard). */
  function stopAll() {
    const ids = [...sessions.keys()];
    for (const id of ids) {
      const s = sessions.get(id);
      if (!s) continue;
      s.stopRequested = true;
      if (typeof s.wake === "function") { try { s.wake(); } catch { /* ignore */ } }
    }
    return { ok: true, stopped: ids };
  }

  function status(accountId) {
    return publicState(accountId);
  }

  function list() {
    return [...sessions.keys()].map((id) => publicState(id));
  }

  return { start, stop, stopAll, status, list };
}

module.exports = { createTikTokWarmer };
`;
}

/* ------------------------------------------------------------------ *
 * P A R C H E   1 : dashboard-server.js
 * Crea el warmer y expone start / stop / status.
 * ------------------------------------------------------------------ */

function patchServer(text) {
  // 1a) import del modulo, idempotente.
  if (!text.includes('require("./tiktok-warmer")')) {
    const firstRequire = 'const express = require("express");';
    if (text.includes(firstRequire)) {
      text = mustReplace(
        text,
        firstRequire,
        'const express = require("express");\n' +
          'const { createTikTokWarmer } = require("./tiktok-warmer"); // ' + MARK,
        "import libs"
      );
    } else {
      text = "const { createTikTokWarmer } = require(\"./tiktok-warmer\"); // " + MARK + "\n" + text;
    }
  }

  // 1b) instanciar el warmer. El calentador se autoabastece y no depende de
  //     imports concretos del server. Si ya habia una version anterior (que si
  //     dependia de getPlatformProfileDir), se REEMPLAZA por esta.
  const instance =
    "\n\n// " + MARK + ": motor de calentamiento (abre el perfil de TikTok y baja videos).\n" +
    "const tiktokWarmer = createTikTokWarmer_instance();\n" +
    "function createTikTokWarmer_instance() {\n" +
    "  try {\n" +
    "    // El calentador se autoabastece: solo le pasamos lo que EXISTA aqui,\n" +
    "    // asi no depende de nombres internos que puedan variar en el proyecto.\n" +
    "    const deps = {};\n" +
    "    if (typeof getPlatformProfileDir === \"function\") deps.getPlatformProfileDir = getPlatformProfileDir;\n" +
    "    if (typeof requireAccount === \"function\") deps.requireAccount = requireAccount;\n" +
    "    return createTikTokWarmer(deps);\n" +
    "  } catch (error) {\n" +
    "    console.error(\"[WARMER-TIKTOK] no se pudo crear el calentador:\", error.message);\n" +
    "    return { start: async () => ({ ok: false, error: error.message }), stop: async () => ({ ok: false }), status: () => ({ running: false }), list: () => [], stopAll: () => ({ ok: true }) };\n" +
    "  }\n" +
    "}";

  // Reemplazar un bloque anterior COMPLETO. Se considera bloque todo lo que va
  // desde el comentario MARK (o, si no esta, desde la linea 'const tiktokWarmer'
  // o el propio 'function createTikTokWarmer_instance') hasta el cierre de esa
  // funcion. Asi una version vieja con dependencias (getPlatformProfileDir)
  // queda sustituida por la nueva autosuficiente, sin dejar restos duplicados.
  const blockRe = new RegExp(
    "(?:\\n\\/\\/ " + MARK.replace(/[-]/g, "\\-") + ": motor de calentamiento[\\s\\S]*?)?" +
    "(?:\\nconst tiktokWarmer = createTikTokWarmer_instance\\(\\);)?" +
    "\\nfunction createTikTokWarmer_instance\\(\\) \\{[\\s\\S]*?\\n\\}",
    "m"
  );
  if (blockRe.test(text)) {
    text = text.replace(blockRe, instance.trimStart());
  } else {
    const accountImportAnchor = "} = require(\"./account-manager\");";
    const idx = text.lastIndexOf(accountImportAnchor);
    if (idx < 0) throw new Error("No encuentro el import de account-manager para enganchar el warmer.");
    const insertAt = idx + accountImportAnchor.length;
    text = text.slice(0, insertAt) + instance + text.slice(insertAt);
  }

  // 1c) endpoints, justo antes del bloque de login de TikTok. Idempotente:
  //     solo se insertan si no estan ya.
  const anchorRe = /^([ \t]*)\/\/ Login endpoints \(TikTok\)/m;
  if (!anchorRe.test(text)) {
    throw new Error(
      "No encontrado el punto de anclaje: bloque '// Login endpoints (TikTok)'. " +
      "Avisa a tu asistente con esta linea."
    );
  }
  const anchorMatch = text.match(anchorRe);
  const indent = anchorMatch ? anchorMatch[1] : "  ";
  const anchor = anchorMatch[0];
  const endpointsAlready = text.includes('"/api/tiktok/warm/start"');
  const bodyLines = [
    `// ${MARK}: resuelve la cuenta a calentar sin depender de imports concretos.`,
    `const resolveWarmAccount = async (id) => {`,
    `  if (id && typeof requireAccount === "function") return await requireAccount(id);`,
    `  if (id) return { id, name: id };`,
    `  if (typeof getActiveAccount === "function") return await getActiveAccount();`,
    `  throw new Error("Elige una cuenta de TikTok en el desplegable.");`,
    `};`,
    ``,
    `// ${MARK}: arranca el auto-scroll (calentamiento) de UNA cuenta.`,
    `app.post("/api/tiktok/warm/start", async (req, res) => {`,
    `  try {`,
    `    const account = await resolveWarmAccount(req.body?.accountId || req.query?.accountId);`,
    `    const result = await tiktokWarmer.start(account.id, {`,
    `      scrollMs: Number(req.body?.scrollMs) || undefined,`,
    `      headless: req.body?.headless === true,`,
    `    });`,
    `    res.json(result);`,
    `  } catch (error) {`,
    `    res.status(400).json({ ok: false, error: error.message });`,
    `  }`,
    `});`,
    ``,
    `// ${MARK}: para el auto-scroll de UNA cuenta.`,
    `app.post("/api/tiktok/warm/stop", async (req, res) => {`,
    `  try {`,
    `    const accountId = req.body?.accountId || req.query?.accountId;`,
    `    res.json(tiktokWarmer.stop(accountId));`,
    `  } catch (error) {`,
    `    res.status(400).json({ ok: false, error: error.message });`,
    `  }`,
    `});`,
    ``,
    `// ${MARK}: estado del auto-scroll (cuenta concreta o todas).`,
    `app.get("/api/tiktok/warm/status", async (req, res) => {`,
    `  try {`,
    `    const accountId = req.query?.accountId || req.body?.accountId;`,
    `    res.json(accountId ? tiktokWarmer.status(accountId) : { running: tiktokWarmer.list() });`,
    `  } catch (error) {`,
    `    res.status(400).json({ ok: false, error: error.message });`,
    `  }`,
    `});`,
    ``,
  ];
  if (!endpointsAlready) {
    const endpoints = bodyLines.map((l) => (l ? indent + l : "")).join("\n") + anchor;
    text = mustReplace(text, anchor, endpoints, "endpoints warm");
  }

  // 1d) parar todo al cerrar el servidor (para no dejar Chromium huerfano).
  const closeAnchor = "  server.listen(";
  if (text.includes(closeAnchor) && !text.includes("tiktokWarmer.stopAll()")) {
    text = text.replace(
      closeAnchor,
      "  const shutdownWarmer = () => { try { tiktokWarmer.stopAll(); } catch { /* ignore */ } };\n" +
      "  process.once(\"SIGINT\", shutdownWarmer);\n" +
      "  process.once(\"SIGTERM\", shutdownWarmer);\n\n" +
      closeAnchor
    );
  }

  return text;
}

/* ------------------------------------------------------------------ *
 * P A R C H E   2 : web/autopost.js
 * Anade los botones y su logica. Se engancha al final del modulo para
 * no depender de la estructura interna.
 * ------------------------------------------------------------------ */

function patchAutopost(text) {
  if (text.includes("warmerToolbar")) return text;

  const injected = `

/* ==================================================================
 * ${MARK}: calentamiento automatico (auto-scroll del "Para ti").
 * Solo aparece en la pestana de TikTok. Usa la cuenta seleccionada.
 * ================================================================== */
(function initTikTokWarmer() {
  const WARMER_HTML =
    '<div class="warmer-info">' +
      '<span class="warmer-title">Calentamiento automatico</span>' +
      '<span id="warmerStatus" class="warmer-status">Parado</span>' +
    '</div>' +
    '<div class="warmer-actions">' +
      '<button id="warmerStart" class="btn btn-primary" type="button">Iniciar calentamiento</button>' +
      '<button id="warmerStop" class="btn btn-danger" type="button" disabled>Parar</button>' +
    '</div>';

  // Barra FIJA en la esquina inferior: no depende del HTML del dashboard,
  // asi funciona aunque la vista de TikTok cambie de estructura.
  const WARMER_CSS =
    '#warmerToolbar{position:fixed;right:20px;bottom:20px;z-index:99999;display:none;' +
    'align-items:center;gap:14px;padding:12px 16px;border-radius:14px;' +
    'border:1px solid rgba(255,255,255,.14);background:#111827;color:#f3f4f6;' +
    'box-shadow:0 10px 30px rgba(0,0,0,.45);font:13px/1.4 system-ui,Segoe UI,Arial,sans-serif;' +
    'flex-wrap:wrap;max-width:min(92vw,520px)}' +
    '#warmerToolbar.show{display:flex}' +
    '#warmerToolbar .warmer-info{display:flex;align-items:center;gap:10px;flex-wrap:wrap}' +
    '#warmerToolbar .warmer-title{font-weight:600}' +
    '#warmerToolbar .warmer-status{font-size:.85em;padding:3px 10px;border-radius:999px;' +
    'background:rgba(255,255,255,.10);opacity:.85;white-space:nowrap}' +
    '#warmerToolbar .warmer-status.on{background:rgba(0,200,120,.20);color:#41d18c;opacity:1}' +
    '#warmerToolbar .warmer-actions{display:flex;gap:8px}' +
    '#warmerToolbar .btn{cursor:pointer;border-radius:9px;border:1px solid rgba(255,255,255,.18);' +
    'padding:7px 12px;font:inherit;font-weight:600;background:#1f2937;color:#f3f4f6}' +
    '#warmerToolbar .btn-primary{background:#2563eb;border-color:#2563eb}' +
    '#warmerToolbar .btn-danger{background:#dc2626;border-color:#dc2626}' +
    '#warmerToolbar .btn[disabled]{opacity:.4;cursor:not-allowed}';

  function warmerAccountId() {
    try {
      return (typeof currentAccountId === "function" && currentAccountId()) ||
             localStorage.getItem("autosocial.selectedAccountId") || "";
    } catch { return ""; }
  }

  async function warmerApi(action, payload) {
    const res = await fetch("/api/tiktok/warm/" + action, {
      method: action === "status" ? "GET" : "POST",
      headers: { "Content-Type": "application/json" },
      body: action === "status" ? undefined : JSON.stringify(payload || {}),
    });
    return res.json();
  }

  function renderWarmer(state) {
    const toolbar = document.getElementById("warmerToolbar");
    const statusEl = document.getElementById("warmerStatus");
    const startBtn = document.getElementById("warmerStart");
    const stopBtn = document.getElementById("warmerStop");
    if (!toolbar || !statusEl) return;
    if (state && state.running) {
      const segs = Math.round((state.elapsedMs || 0) / 1000);
      const mm = String(Math.floor(segs / 60)).padStart(2, "0");
      const ss = String(segs % 60).padStart(2, "0");
      statusEl.textContent = "Calentando \\u00b7 " + (state.scrollCount || 0) + " videos \\u00b7 " + mm + ":" + ss;
      statusEl.classList.add("on");
      startBtn.disabled = true;
      stopBtn.disabled = false;
    } else {
      statusEl.textContent = state && state.lastError ? ("Parado (" + state.lastError + ")") : "Parado";
      statusEl.classList.remove("on");
      startBtn.disabled = false;
      stopBtn.disabled = true;
    }
  }

  // Detecta si el usuario esta en la pestana de TikTok, de forma tolerante:
  // por hash, por el texto de la pestana activa o por el titulo visible.
  function enVistaTikTok() {
    try {
      if (/tiktok|auto-?post/i.test(location.hash || "")) return true;
      const active = document.querySelector(
        "nav .active, .nav .active, .tab.active, .nav-item.active, [aria-selected='true']"
      );
      if (active && /tiktok|auto-?post/i.test(active.textContent || "")) return true;
      const heads = document.querySelectorAll("h1, h2");
      for (const h of heads) {
        if (h.offsetParent !== null && /tiktok|auto\\s*post/i.test(h.textContent || "")) return true;
      }
    } catch { /* ignore */ }
    return false;
  }

  function ensureToolbar() {
    if (document.getElementById("warmerToolbar")) return true;
    if (!document.getElementById("warmerCss")) {
      const style = document.createElement("style");
      style.id = "warmerCss";
      style.textContent = WARMER_CSS;
      document.head.appendChild(style);
    }
    const toolbar = document.createElement("div");
    toolbar.id = "warmerToolbar";
    toolbar.innerHTML = WARMER_HTML;
    document.body.appendChild(toolbar);

    document.getElementById("warmerStart").addEventListener("click", async () => {
      const accountId = warmerAccountId();
      if (!accountId) { alert("Elige una cuenta en el desplegable de la cabecera."); return; }
      try {
        const r = await warmerApi("start", { accountId });
        if (r && r.ok === false) alert(r.error || "No se pudo iniciar.");
      } catch (e) { alert("No se pudo iniciar: " + e.message); }
      refreshWarmer();
    });
    document.getElementById("warmerStop").addEventListener("click", async () => {
      const accountId = warmerAccountId();
      try { await warmerApi("stop", { accountId }); } catch { /* ignore */ }
      refreshWarmer();
    });
    return true;
  }

  async function refreshWarmer() {
    const toolbar = document.getElementById("warmerToolbar");
    if (!toolbar) return;
    const accountId = warmerAccountId();
    if (!accountId) { renderWarmer(null); return; }
    try {
      const st = await warmerApi("status?accountId=" + encodeURIComponent(accountId));
      renderWarmer(st);
    } catch { /* ignore */ }
  }

  function tick() {
    const toolbar = document.getElementById("warmerToolbar");
    if (enVistaTikTok()) {
      ensureToolbar();
      toolbar && toolbar.classList.add("show");
      refreshWarmer();
    } else if (toolbar) {
      toolbar.classList.remove("show");
    }
  }

  document.addEventListener("DOMContentLoaded", () => setTimeout(tick, 300));
  window.addEventListener("hashchange", tick);
  document.addEventListener("click", () => setTimeout(tick, 50), true);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) tick(); });
  setInterval(tick, 2000);
  setTimeout(tick, 800);
})();
`;

  return text + injected;
}

/* ==================================================================
 * Instalacion
 * ================================================================== */

const FILES = [
  { rel: "web/autopost.js", fn: patchAutopost },
  { rel: "src/dashboard-server.js", fn: patchServer },
];

function install() {
  log(`Proyecto: ${ROOT}`);

  // 1) Copiar el modulo motor.
  const modulePath = path.resolve(ROOT, "src/tiktok-warmer.js");
  if (fs.existsSync(modulePath)) {
    log("src/tiktok-warmer.js ya existe; lo actualizo con copia previa.");
    fs.copyFileSync(modulePath, `${modulePath}.bak-${MARK}-${Date.now()}`);
  }
  fs.writeFileSync(modulePath, warmerModuleSource(), "utf8");
  log("escrito src/tiktok-warmer.js");

  // 2) Parchear archivos.
  for (const { rel, fn } of FILES) {
    const before = read(rel);
    const after = fn(before);
    if (after === before) { log(`${rel}: ya estaba aplicado.`); continue; }
    write(rel, after);
  }

  log("");
  log("LISTO. Ahora:");
  log("  1) Cierra el dashboard si estaba abierto y arrancalo: npm run dashboard");
  log("  2) Recarga el navegador con Ctrl+Shift+R.");
  log("  3) Ve a TikTok / Auto Post: vera 'Calentamiento automatico'.");
  log("     Elige la cuenta en el desplegable y pulsa 'Iniciar calentamiento'.");
  log("     Para cuando quieras con 'Parar'.");
  log("");
  log("Revisa que tengas Playwright: npm ls playwright  (si falta: npx playwright install chromium)");
}

function revert() {
  log(`Revirtiendo en ${ROOT}`);

  // Borrar el modulo motor y sus backups mas recientes.
  const modulePath = path.resolve(ROOT, "src/tiktok-warmer.js");
  if (fs.existsSync(modulePath)) { fs.rmSync(modulePath, { force: true }); log("eliminado src/tiktok-warmer.js"); }

  for (const { rel } of FILES) {
    const full = path.resolve(ROOT, rel);
    const dir = path.dirname(full);
    const base = path.basename(full);
    const backups = fs.existsSync(dir)
      ? fs.readdirSync(dir).filter((f) => f.startsWith(`${base}.bak-${MARK}-`)).sort()
      : [];
    if (!backups.length) { log(`${rel}: no hay copia de seguridad; no toco nada.`); continue; }
    const latest = path.join(dir, backups[backups.length - 1]);
    fs.copyFileSync(latest, full);
    log(`restaurado ${rel} desde ${path.basename(latest)}`);
  }

  log("");
  log("REVERTIDO. Reinicia el dashboard para aplicar los cambios.");
}

try {
  if (REVERT) revert(); else install();
} catch (e) {
  console.error(`[${MARK}] ERROR: ${e.message}`);
  process.exitCode = 1;
}
