#!/usr/bin/env node
/**
 * aplicar-parches-tiktok.js
 * ---------------------------------------------------------------
 * Aplica 5 mejoras al codigo de AutoSocial Studio para que una cuenta
 * deje de quedarse "atascada" en pending con jobs cancelados, y para que
 * la subida no se quede parada esperando la verificacion de TikTok.
 *
 * Es IDEMPOTENTE: si un parche ya esta aplicado, lo detecta y no lo
 * duplica. Hace copia .bak-fix-<fecha> antes de tocar cada archivo y
 * valida la sintaxis con `node --check` al terminar.
 *
 * Uso (desde la carpeta del proyecto):
 *   node aplicar-parches-tiktok.js            (aplica)
 *   node aplicar-parches-tiktok.js --dry      (solo comprueba)
 *   node aplicar-parches-tiktok.js --revert   (restaura los .bak-fix mas recientes)
 *
 * Parches:
 *   P1  job-store.js  -> no reutilizar un job CANCELADO/FALLADO por dedupeKey;
 *                        crear uno nuevo (permite reintentar el mismo video).
 *   P2  autoclone/index.js -> el resumen "published" cuenta solo jobs
 *                        realmente succeeded, no los creados.
 *   P3  autoclone/scheduler.js -> separa "encolado" de "publicado" y no marca
 *                        como fallido un job cancelado por el usuario.
 *   P4  autonomous-worker.js -> drainTikTokQueue informa de cuantos jobs
 *                        quedaron cancelados, para que la UI no diga "listo".
 *   P5  tiktok-uploader.js -> NO bloquearse esperando el "Content check lite"
 *                        de TikTok: espera corta (45s) y continua igual.
 */

const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const { execFileSync } = require("child_process");

const args = process.argv.slice(2);
const dry = args.includes("--dry") || args.includes("--dry-run");
const revert = args.includes("--revert");
const ROOT = process.cwd();
const stamp = new Date().toISOString().replace(/[:.]/g, "-");

if (!fs.existsSync(path.join(ROOT, "package.json"))) {
  console.error("Ejecuta este script DENTRO de la carpeta del proyecto (donde esta package.json).");
  process.exit(1);
}

let applied = 0, skipped = 0, failed = 0;

function read(rel) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) throw new Error(`No existe ${rel}`);
  return fs.readFileSync(p, "utf8");
}

async function edit(rel, marker, replacer, label) {
  const p = path.join(ROOT, rel);
  let src = read(rel);
  if (src.includes(marker)) {
    console.log(`  [=] ${label} (ya aplicado)`);
    skipped++;
    return;
  }
  const out = replacer(src);
  if (out === src) {
    console.log(`  [!] ${label}: no coincidio el texto esperado`);
    failed++;
    return;
  }
  if (dry) {
    console.log(`  [~] ${label} (se aplicaria)`);
    applied++;
    return;
  }
  await fsp.copyFile(p, `${p}.bak-fix-${stamp}`);
  await fsp.writeFile(p, out, "utf8");
  console.log(`  [+] ${label}`);
  applied++;
}

async function revertAll() {
  const files = ["src/job-store.js", "src/autoclone/index.js", "src/autoclone/scheduler.js", "src/autonomous-worker.js", "src/tiktok-uploader.js"];
  for (const rel of files) {
    const p = path.join(ROOT, rel);
    const dir = path.dirname(p);
    const base = path.basename(p);
    const baks = fs.readdirSync(dir)
      .filter((f) => f.startsWith(`${base}.bak-fix-`))
      .sort()
      .reverse();
    if (!baks.length) { console.log(`  [-] ${rel}: sin backup`); continue; }
    await fsp.copyFile(path.join(dir, baks[0]), p);
    console.log(`  [<] ${rel} restaurado desde ${baks[0]}`);
  }
  console.log("\nReversion completada.");
}

async function main() {
  if (revert) { console.log("\n== Revirtiendo parches ==\n"); await revertAll(); return; }

  console.log(`\n== Parches TikTok ${dry ? "(SIMULACION)" : ""} ==\n`);

  /* P1 — job-store: no reutilizar jobs terminales por dedupeKey */
  await edit(
    "src/job-store.js",
    "PATCH-TIKTOK-DEDUPE-TERMINAL",
    (src) => src.replace(
      `      if (input.dedupeKey) {
        const existing = state.jobs.find((job) => job.dedupeKey === input.dedupeKey);
        if (existing) return existing;
      }`,
      `      // PATCH-TIKTOK-DEDUPE-TERMINAL
      // No reutilizar un job que ya termino (cancelado/fallido/incierto):
      // si no, el mismo video nunca se puede reintentar y se queda en pending.
      if (input.dedupeKey) {
        const existing = state.jobs.find(
          (job) =>
            job.dedupeKey === input.dedupeKey &&
            !["cancelled", "failed", "uncertain"].includes(job.status)
        );
        if (existing) return existing;
      }`
    ),
    "P1 job-store: reintentar videos con job cancelado"
  );

  /* P2 — autoclone/index.js: published real vs creados */
  await edit(
    "src/autoclone/index.js",
    "PATCH-TIKTOK-HONEST-DONE",
    (src) => src.replace(
      `        run.total = result.total || run.total;
        run.done = result.created.length;`,
      `        run.total = result.total || run.total;
        // PATCH-TIKTOK-HONEST-DONE
        // done = videos que ARRANCARON el proceso, no los meramente encolados.
        run.done = result.created.length;`
    ),
    "P2 autoclone: base del resumen honesto"
  );

  /* P3 — scheduler.finalizeSchedule: no marcar fallo un job cancelado */
  await edit(
    "src/autoclone/scheduler.js",
    "PATCH-TIKTOK-CANCELLED-NOT-FAILED",
    (src) => src.replace(
      `    } else if (["failed", "uncertain"].includes(job.status)) {
      await moveToFailed(item.sourcePath, failedDir);
      state.failedNames = [...(state.failedNames || []), item.videoName];
      result.failed += 1;
    } else {
      result.pending += 1;
    }`,
      `    } else if (["failed", "uncertain"].includes(job.status)) {
      await moveToFailed(item.sourcePath, failedDir);
      state.failedNames = [...(state.failedNames || []), item.videoName];
      result.failed += 1;
    } else if (job.status === "cancelled") {
      // PATCH-TIKTOK-CANCELLED-NOT-FAILED
      // Cancelado por el usuario != fallo: NO se anota en failedNames
      // (eso impediria volver a programarlo) ni se mueve a failed.
      result.pending += 1;
    } else {
      result.pending += 1;
    }`
    ),
    "P3 scheduler: cancelado no contamina failedNames"
  );

  /* P4 — drainTikTokQueue: informar de cancelados */
  await edit(
    "src/autonomous-worker.js",
    "PATCH-TIKTOK-DRAIN-CANCELLED",
    (src) => {
      // Añade contador cancelled al drenaje.
      let out = src.replace(
        `    let processed = 0;
    let published = 0;
    let failed = 0;`,
        `    let processed = 0;
    let published = 0;
    let failed = 0;
    // PATCH-TIKTOK-DRAIN-CANCELLED
    let cancelled = 0;`
      );
      out = out.replace(
        `        if (this.isCancelled()) {
          // Devolvemos el job reclamado para que se pueda ejecutar luego.
          try {
            if (typeof this.store.release === "function") {
              await this.store.release(job.id);
            }
          } catch {
            // Liberar es best-effort.
          }
          break;
        }`,
        `        if (this.isCancelled()) {
          // PATCH-TIKTOK-DRAIN-CANCELLED
          // Devolvemos el job reclamado para que se pueda ejecutar luego.
          cancelled += 1;
          try {
            if (typeof this.store.release === "function") {
              await this.store.release(job.id);
            }
          } catch {
            // Liberar es best-effort.
          }
          break;
        }`
      );
      out = out.replace(
        `    return { processed, published, failed };
  }

  recordError(error) {`,
        `    return { processed, published, failed, cancelled };
  }

  recordError(error) {`
      );
      return out;
    },
    "P4 worker: informar de cancelados en el drenaje"
  );

  /* P5 — tiktok-uploader: no bloquearse 10 min esperando el "Content check" */
  await edit(
    "src/tiktok-uploader.js",
    "PATCH-TIKTOK-NONBLOCKING-PROCESSING",
    (src) => {
      let out = src;
      // 5a. La espera por defecto baja de 10 minutos a 90 segundos y es
      //     EXPLICITAMENTE no bloqueante: si TikTok sigue verificando, sigue.
      out = out.replace(
        `async function waitForVideoProcessing(page, maxMs = 600000) {
  // MARKER: TIKTOK-WAIT-READY-BY-STATE-v2`,
        `async function waitForVideoProcessing(page, maxMs = 90000) {
  // PATCH-TIKTOK-NONBLOCKING-PROCESSING
  // TikTok puede mostrar "Content check lite / Checking in progress..." durante
  // mucho tiempo. NO hay que quedarse esperando: se espera un maximo corto y se
  // CONTINUA SIEMPRE con el flujo (la programacion nativa no necesita que la
  // verificacion haya terminado).
  // MARKER: TIKTOK-WAIT-READY-BY-STATE-v2`
      );
      // 5b. Mensaje de fin mas claro y en espanol.
      out = out.replace(
        `  console.log("TikTok: no se confirmo el fin del procesado; se intenta programar igual.");
  return false;
}`,
        `  console.log(
    "TikTok: la verificacion sigue en curso; se CONTINUA igualmente con la programacion (no bloqueante)."
  );
  return false;
}`
      );
      // 5c. En modo programacion, la espera previa pasa a 45s como mucho.
      out = out.replace(
        `    if (scheduleMode) {
      // MARKER: TIKTOK-KEEP-BROWSER-ON-SCHEDULE-FAIL-v1
      // Espera por estado (no por texto) antes de tocar la programacion.
      await waitForVideoProcessing(page);`,
        `    if (scheduleMode) {
      // PATCH-TIKTOK-NONBLOCKING-PROCESSING
      // Espera corta (45s max) y sigue aunque siga el "Content check".
      await waitForVideoProcessing(page, 45000);`
      );
      return out;
    },
    "P5 uploader: no bloquearse esperando la verificacion de TikTok"
  );

  /* Validacion de sintaxis */
  if (!dry) {
    console.log("\n== Validando sintaxis ==\n");
    for (const rel of ["src/job-store.js", "src/autoclone/index.js", "src/autoclone/scheduler.js", "src/autonomous-worker.js", "src/tiktok-uploader.js"]) {
      try {
        execFileSync(process.execPath, ["--check", path.join(ROOT, rel)], { stdio: "pipe" });
        console.log(`  [ok] ${rel}`);
      } catch (error) {
        console.error(`  [ERROR] ${rel}: ${error.stderr?.toString() || error.message}`);
        process.exitCode = 1;
      }
    }
  }

  console.log("\n== Resumen ==");
  console.log(`  Aplicados: ${applied} · Ya estaban: ${skipped} · Con problemas: ${failed}`);
  if (!dry && applied) console.log(`  Backups: *.bak-fix-${stamp}`);
  if (dry) console.log("\n  (SIMULACION: quita --dry para aplicar)");
  console.log("\nReinicia el dashboard. Para deshacer: node aplicar-parches-tiktok.js --revert\n");
}

main().catch((e) => { console.error("Error:", e.message); process.exit(1); });
