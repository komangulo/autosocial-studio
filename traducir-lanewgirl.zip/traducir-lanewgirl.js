#!/usr/bin/env node
/**
 * Traduce a español el texto (antes de los hashtags) de los .meta.json de una carpeta,
 * deja los hashtags EXACTAMENTE igual (mismo orden y espaciado),
 * y cambia #Lanewgirl por #MadridNuevaModelo.
 *
 * - No requiere instalar nada. Usa Node 18+ (fetch incluido).
 * - Recorre la carpeta de forma recursiva buscando .meta.json
 *
 * USO:
 *   node traducir-lanewgirl.js          (aplica los cambios)
 *   node traducir-lanewgirl.js --dry    (solo muestra, no escribe)
 */

const fs = require("fs");
const path = require("path");

// Carpeta fija donde debe actuar el script:
const CARPETA = "F:\\Herramientas  - Aplicaciones\\jobs\\katamogz\\lanewgirl1";

// Reemplazo exacto de hashtag pedido:
const HASH_DE = "#Lanewgirl";
const HASH_A  = "#MadridNuevaModelo";

const dry = process.argv.includes("--dry");

if (!fs.existsSync(CARPETA)) {
  console.error("La carpeta no existe:", CARPETA);
  process.exit(1);
}

/* ---------- Traducción (Google, sin librerías) ---------- */
async function traducir(texto) {
  if (!texto.trim()) return texto;
  const hosts = [
    "https://translate.googleapis.com/translate_a/single",
    "https://clients5.google.com/translate_a/t",
  ];
  for (const host of hosts) {
    for (let i = 0; i < 4; i++) {
      try {
        const url = host.includes("clients5")
          ? host + "?client=dict-chrome-ex&sl=en&tl=es&q=" + encodeURIComponent(texto)
          : host + "?client=gtx&sl=en&tl=es&dt=t&q=" + encodeURIComponent(texto);
        const r = await fetch(url, {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
        });
        if (r.status === 429) { await new Promise((x) => setTimeout(x, 1500)); continue; }
        if (!r.ok) continue;
        const j = await r.json();
        const t = host.includes("clients5")
          ? (Array.isArray(j) ? j[0] : (j[0] || "").join(""))
          : j[0].map((p) => p[0]).join("");
        if (t) return t;
      } catch (e) {
        await new Promise((x) => setTimeout(x, 800));
      }
    }
  }
  throw new Error("traduccion no disponible");
}

/* ---------- Procesa una descripción/caption ---------- */
// Separa: texto inicial (antes del primer '#') + bloque de hashtags (resto tal cual).
function dividir(valor) {
  const idx = valor.indexOf("#");
  if (idx === -1) return { texto: valor, hashtags: "" };
  return { texto: valor.slice(0, idx), hashtags: valor.slice(idx) };
}

async function procesarCampo(valor) {
  const { texto, hashtags } = dividir(valor);
  // 1) Traducir el texto, preservando el espaciado exacto tras la traducción.
  //    Guardamos y restauramos los espacios/saltos del original para no alterar formato.
  const lead = (texto.match(/^\s*/) || [""])[0];       // espacios iniciales
  const trail = (texto.match(/\s*$/) || [""])[0];      // espacios antes del '#'
  const nucleo = texto.slice(lead.length, texto.length - trail.length);
  const nucleoTrad = await traducir(nucleo);
  const textoFinal = lead + nucleoTrad + trail;
  // 2) Devolver texto traducido + hashtags intactos (con el reemplazo pedido)
  return textoFinal + hashtags.split(HASH_DE).join(HASH_A);
}

/* ---------- Recorrido de la carpeta ---------- */
let revisados = 0, cambiados = 0;
const lista = [];

async function recorre(dir) {
  for (const nombre of fs.readdirSync(dir)) {
    const full = path.join(dir, nombre);
    const st = fs.statSync(full);
    if (st.isDirectory()) { await recorre(full); continue; }
    if (!nombre.toLowerCase().endsWith(".meta.json")) continue;

    revisados++;
    const txt = fs.readFileSync(full, "utf8");
    let data;
    try { data = JSON.parse(txt); }
    catch (e) { console.warn("  JSON invalido, se omite:", full); continue; }

    let tocado = false;
    for (const campo of ["description", "caption"]) {
      if (typeof data[campo] !== "string" || !data[campo].trim()) continue;
      const nuevo = await procesarCampo(data[campo]);
      if (nuevo !== data[campo]) { data[campo] = nuevo; tocado = true; }
    }

    if (tocado) {
      cambiados++;
      lista.push(full);
      if (!dry) fs.writeFileSync(full, JSON.stringify(data, null, 2), "utf8");
      console.log((dry ? "[DRY] " : "") + "cambiado:", path.basename(path.dirname(full)) + "/" + nombre);
    }
  }
}

(async () => {
  console.log("Carpeta:", CARPETA);
  await recorre(CARPETA);
  console.log("\n.meta.json revisados:", revisados);
  console.log("Archivos modificados:", cambiados);
  console.log(dry ? "MODO PRUEBA (--dry): no se escribio nada." : "Hecho.");
})().catch((e) => { console.error("Error:", e.message); process.exit(1); });
