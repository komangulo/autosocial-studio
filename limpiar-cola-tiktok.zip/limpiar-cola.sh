#!/usr/bin/env bash
# ============================================================
# limpiar-cola.sh
# Borra los trabajos de TikTok (pendientes, procesando, reservados)
# SOLO de las cuentas: capybluh y madrid-nueva-modelo
# y cancela sus jobs en .runtime/autonomous-state.json
#
# NO toca ninguna otra cuenta.
# ============================================================
set -u

PROJ="$(cd "$(dirname "$0")/.." && pwd)"
echo "Proyecto: $PROJ"
cd "$PROJ" || { echo "No encuentro el proyecto"; exit 1; }

CUENTAS=(capybluh madrid-nueva-modelo)

echo
echo "=== ANTES ==="
for c in "${CUENTAS[@]}"; do
  for sub in pending scheduled processing posted failed; do
    n=$(ls "queue/$c/tiktok/$sub" 2>/dev/null | wc -l)
    echo "  queue/$c/tiktok/$sub = $n"
  done
done

echo
read -r -p "Esto BORRA pendientes/procesando/reservados de capybluh y madrid-nueva-modelo. Escribe SI para continuar: " ok
if [ "$ok" != "SI" ]; then echo "Cancelado."; exit 0; fi

# --- 1) Copia de seguridad del estado ---
if [ -f .runtime/autonomous-state.json ]; then
  cp .runtime/autonomous-state.json ".runtime/autonomous-state.json.bak-$(date +%Y%m%d-%H%M%S)"
  echo "Backup del estado creado en .runtime/"
fi

# --- 2) Asegurala app parada: aviso ---
echo
echo "AVISO: si la app esta abierta, CIERRALA ahora. Pulsa Enter cuando este cerrada."
read -r _

# --- 3) Borrar carpetas de cola (pending, scheduled, processing) ---
for c in "${CUENTAS[@]}"; do
  for sub in pending scheduled processing; do
    dir="queue/$c/tiktok/$sub"
    if [ -d "$dir" ]; then
      echo "Borrando $dir ..."
      # borra contenido, conserva la carpeta
      find "$dir" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null
    fi
  done
done

# --- 4) Cancelar jobs en el estado ---
# Usamos node (viene con la app) para editar el JSON con seguridad.
if command -v node >/dev/null 2>&1 && [ -f .runtime/autonomous-state.json ]; then
  node - "$PROJ" <<'NODE'
const fs = require("fs");
const path = require("path");
const proj = process.argv[2];
const statePath = path.join(proj, ".runtime", "autonomous-state.json");
const CUENTAS = new Set(["capybluh", "madrid-nueva-modelo"]);

let raw = fs.readFileSync(statePath, "utf8");
let data;
try { data = JSON.parse(raw); } catch (e) { console.error("JSON ilegible:", e.message); process.exit(1); }

const TERMINAL = new Set(["completed", "failed", "cancelled"]);
let cambiados = 0;

function walk(obj) {
  if (!obj || typeof obj !== "object") return;
  if (Array.isArray(obj)) { obj.forEach(walk); return; }
  if (CUENTAS.has(obj.accountId) && typeof obj.status === "string" && !TERMINAL.has(obj.status)) {
    obj.status = "cancelled";
    cambiados++;
  }
  for (const k of Object.keys(obj)) walk(obj[k]);
}

walk(data);

// Guardar conservando backup del archivo tal cual
fs.copyFileSync(statePath, statePath + ".pre-cancel");
fs.writeFileSync(statePath, JSON.stringify(data, null, 2), "utf8");
console.log(`Jobs de capybluh/madrid marcados como cancelled: ${cambiados}`);
NODE
else
  echo "No encontre node o el fichero de estado; los jobs de estado NO se cancelaron (la cola si se limpio)."
fi

echo
echo "=== DESPUES ==="
for c in "${CUENTAS[@]}"; do
  for sub in pending scheduled processing; do
    n=$(ls "queue/$c/tiktok/$sub" 2>/dev/null | wc -l)
    echo "  queue/$c/tiktok/$sub = $n"
  done
done

echo
echo "Limpieza terminada. Reinicia la app."
