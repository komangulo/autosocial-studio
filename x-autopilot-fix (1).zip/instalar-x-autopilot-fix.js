#!/usr/bin/env node
/**
 * instalar-x-autopilot-fix.js
 * ---------------------------------------------------------------------------
 * Instalador idempotente para AutoSocial Studio que:
 *   1. Crea src/x-auth.js  (login/import de cookies + publicacion real en X).
 *   2. Reescribe src/x-autopilot.js (worker arrancable, timezone correcto,
 *      sin fallback basura, timeouts/reintentos, cadena de IA con fallback,
 *      reconciliacion de cola y publicacion via navegador).
 *   3. Parchea src/dashboard-server.js: arranca el worker y expone endpoints
 *      de login/cookies/estado de X.
 *   4. Parchea web/index.html y web/app.js: UI de sesion de X + botones.
 *   5. Anade x-autopilot-state.json a .gitignore.
 *
 * Uso:  node instalar-x-autopilot-fix.js
 * Es seguro ejecutarlo varias veces: cada bloque lleva un marcador unico.
 */

const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const MARK = {
  auth: "// MARKER: XAP-AUTH-v1",
  aiConfig: "// MARKER: AICFG-v1",
  engine: "// MARKER: XAP-ENGINE-v2",
  serverStart: "// MARKER: XAP-WORKER-START-v1",
  serverRoutes: "// MARKER: XAP-ROUTES-v1",
  serverAi: "// MARKER: AICFG-ROUTES-v1",
  gitignore: "# MARKER: XAP-IGNORE-v1",
  html: "<!-- MARKER: XAP-UI-v1 -->",
  htmlAi: "<!-- MARKER: AICFG-UI-v1 -->",
  navAi: "<!-- MARKER: AICFG-NAV-v1 -->",
  jsBind: "// MARKER: XAP-BIND-v1",
  jsRender: "// MARKER: XAP-RENDER-v1",
  jsHandlers: "// MARKER: XAP-HANDLERS-v1",
  jsAiBind: "// MARKER: AICFG-BIND-v1",
  jsAiLogic: "// MARKER: AICFG-LOGIC-v1",
  cssAi: "/* MARKER: AICFG-CSS-v1 */",
  autoclone: "// MARKER: AICFG-BRIDGE-v1",
};

const results = [];
function ok(msg) { results.push(["OK", msg]); }
function skip(msg) { results.push(["SKIP", msg]); }
function fail(msg) { results.push(["FAIL", msg]); }

function read(rel) {
  const full = path.join(ROOT, rel);
  if (!fs.existsSync(full)) return null;
  return fs.readFileSync(full, "utf8");
}
function write(rel, text) {
  const full = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, "utf8");
}
function backup(rel) {
  const full = path.join(ROOT, rel);
  if (!fs.existsSync(full)) return;
  const bak = `${full}.xap-backup`;
  if (!fs.existsSync(bak)) fs.copyFileSync(full, bak);
}
function replaceOnce(text, needle, replacement, label) {
  const index = text.indexOf(needle);
  if (index === -1) throw new Error(`No se encontro el punto de insercion: ${label}`);
  if (text.indexOf(needle, index + needle.length) !== -1) {
    // Multiple matches: use last occurrence style replacement is risky, so fall back to first.
  }
  return text.slice(0, index) + replacement + text.slice(index + needle.length);
}

// ---------------------------------------------------------------------------
// 0. Sanity check
// ---------------------------------------------------------------------------
if (!fs.existsSync(path.join(ROOT, "package.json")) || !fs.existsSync(path.join(ROOT, "src", "x-autopilot.js"))) {
  console.error("ERROR: ejecuta este instalador desde la raiz de AutoSocial Studio.");
  process.exit(1);
}

// ---------------------------------------------------------------------------
// 1. src/x-auth.js
// ---------------------------------------------------------------------------
(function installAuth() {
  const content = read("src/x-auth.js");
  if (content && content.includes(MARK.auth)) { skip("src/x-auth.js ya estaba instalado"); return; }
  const payload = readAsset("x-auth.js");
  write("src/x-auth.js", payload);
  ok("src/x-auth.js creado");
})();

// ---------------------------------------------------------------------------
// 1b. src/ai-config.js  (configuracion global de IA)
// ---------------------------------------------------------------------------
(function installAiConfig() {
  const content = read("src/ai-config.js");
  if (content && content.includes(MARK.aiConfig)) { skip("src/ai-config.js ya estaba instalado"); return; }
  write("src/ai-config.js", readAsset("ai-config.js"));
  ok("src/ai-config.js creado (configuracion global de IA)");
})();

// ---------------------------------------------------------------------------
// 2. src/x-autopilot.js
// ---------------------------------------------------------------------------
(function installEngine() {
  const content = read("src/x-autopilot.js");
  if (content && content.includes(MARK.engine)) { skip("src/x-autopilot.js ya estaba parcheado"); return; }
  backup("src/x-autopilot.js");
  write("src/x-autopilot.js", readAsset("x-autopilot.js"));
  ok("src/x-autopilot.js reescrito (v2)");
})();

// ---------------------------------------------------------------------------
// 3. src/dashboard-server.js -- arrancar worker + rutas
// ---------------------------------------------------------------------------
(function installServer() {
  let text = read("src/dashboard-server.js");
  if (!text) { fail("src/dashboard-server.js no encontrado"); return; }

  if (!text.includes(MARK.serverStart)) {
    const match = text.match(/const xAutopilot\s*=\s*require\((["'])\.\/x-autopilot\1\);/);
    if (!match) {
      // The module might be required inline in route handlers; inject the require.
      const anchor = 'const googleFlow = require("./google-flow");';
      if (!text.includes(anchor)) { fail("dashboard-server.js: no se encontro require de google-flow"); return; }
      text = replaceOnce(text, anchor, `${anchor}\nconst xAutopilot = require("./x-autopilot");`, "googleFlow require");
    }
    const boot = `\n  ${MARK.serverStart}\n  try { xAutopilot.startWorker(); } catch (error) { console.error("[x-autopilot] no se pudo arrancar el worker:", error.message); }`;
    const listenAnchor = "  ensureDashboardBindAllowed();";
    text = replaceOnce(text, listenAnchor, `${boot}\n\n${listenAnchor}`, "arranque del worker");
    ok("dashboard-server.js: worker de X Autopilot arrancado al inicio");
  } else {
    skip("dashboard-server.js: worker ya arrancado");
  }

  if (!text.includes(MARK.serverRoutes)) {
    const routes = `
  ${MARK.serverRoutes}
  app.get("/api/x-autopilot/session", async (req, res) => {
    try { res.json(await xAutopilot.getStatus((await getActiveAccount()).id)); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/login", async (req, res) => {
    try { res.json(await require("./x-auth").startLoginSession()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/login/save", async (req, res) => {
    try { res.json(await require("./x-auth").saveLoginSession()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/login/close", async (req, res) => {
    try { res.json(await require("./x-auth").closeLoginSession()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/cookies", async (req, res) => {
    try {
      const result = await require("./x-auth").importCookies(req.body?.cookies);
      res.status(result.ok ? 200 : 400).json(result);
    } catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/x-autopilot/retry", async (req, res) => {
    try { res.json(await xAutopilot.retryFailed((await getActiveAccount()).id)); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });
`;
    const anchor = `app.get("/api/google-flow/status"`;
    text = replaceOnce(text, anchor, `${routes}\n  ${anchor}`, "rutas google-flow");
    ok("dashboard-server.js: endpoints de sesion de X anadidos");
  } else {
    skip("dashboard-server.js: endpoints de X ya presentes");
  }

  if (!text.includes(MARK.serverAi)) {
    const aiRoutes = `
  ${MARK.serverAi}
  const aiConfig = require("./ai-config");
  app.get("/api/ai-config", async (req, res) => {
    try { await aiConfig.load(); res.json(aiConfig.publicConfig()); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/ai-config", async (req, res) => {
    try { res.json(await aiConfig.save(req.body || {})); }
    catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });

  app.post("/api/ai-config/test", async (req, res) => {
    try {
      const result = await aiConfig.testProvider(String(req.body?.provider || ""));
      res.json(await aiConfig.rememberTest(result));
    } catch (error) { res.status(400).json({ ok: false, error: error.message }); }
  });
`;
    const anchor = `app.get("/api/google-flow/status"`;
    text = replaceOnce(text, anchor, `${aiRoutes}\n  ${anchor}`, "rutas config IA");
    ok("dashboard-server.js: endpoints de configuracion global de IA anadidos");
  } else {
    skip("dashboard-server.js: endpoints de config IA ya presentes");
  }

  write("src/dashboard-server.js", text);
})();

// ---------------------------------------------------------------------------
// 4. .gitignore
// ---------------------------------------------------------------------------
(function installGitignore() {
  const rel = ".gitignore";
  let text = read(rel) || "";
  if (text.includes(MARK.gitignore)) { skip(".gitignore ya parcheado"); return; }
  text += `\n${MARK.gitignore}\nx-autopilot-state.json\nx-autopilot-state.json.tmp\n.runtime/cookies\n`;
  write(rel, text.replace(/^\n+/, ""));
  ok(".gitignore: estado de X y cookies ignorados");
})();

// ---------------------------------------------------------------------------
// 5. web/index.html -- banner de sesion de X
// ---------------------------------------------------------------------------
(function installHtml() {
  let text = read("web/index.html");
  if (!text) { fail("web/index.html no encontrado"); return; }
  if (text.includes(MARK.html)) { skip("web/index.html ya tiene la UI de X"); write("web/index.html", text); return; }

  const block = `
        ${MARK.html}
        <div id="xLoginBanner" class="tt-login-banner card" style="margin-bottom:14px;">
          <div class="tt-login-row">
            <span class="tt-login-icon"><i class="ph ph-x-logo"></i></span>
            <div class="tt-login-text">
              <strong id="xLoginTitle">Sesion de X (Twitter)</strong>
              <span id="xLoginMessage">Inicia sesion en la ventana de X o pega tus cookies para publicar automaticamente.</span>
            </div>
            <span id="xLoginStateBadge" class="status-badge">Sin comprobar</span>
            <button id="xLoginBtn" class="control-btn-small primary"><i class="ph ph-browser"></i> Iniciar sesion</button>
            <button id="xLoginSaveBtn" class="control-btn-small success"><i class="ph ph-floppy-disk"></i> Guardar sesion</button>
            <button id="xLoginCloseBtn" class="control-btn-small danger"><i class="ph ph-x"></i> Cerrar</button>
            <button id="xRetryBtn" class="control-btn-small" title="Reprogramar los posts que fallaron"><i class="ph ph-arrows-clockwise"></i> Reintentar fallidos</button>
          </div>
          <div style="display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; align-items:flex-start;">
            <textarea id="xCookiesInput" rows="2" placeholder="O pega aqui tus cookies de X (formato header: auth_token=...; ct0=...  o JSON exportado)" style="flex:1; min-width:260px; font-family:monospace; font-size:11px; padding:8px; border-radius:8px; border:1px solid var(--border-color, #2a2a2a); background:var(--bg-input, #111); color:inherit; resize:vertical;"></textarea>
            <button id="xCookiesBtn" class="control-btn-small"><i class="ph ph-key"></i> Importar cookies</button>
          </div>
        </div>
`;
  // Insert right before the first dashboard-grid of the x-autopilot view.
  const viewAnchor = 'id="view-x-autopilot"';
  const viewIndex = text.indexOf(viewAnchor);
  if (viewIndex === -1) { fail("web/index.html: no se encontro la vista x-autopilot"); return; }
  const gridIndex = text.indexOf('<div class="x-grid">', viewIndex);
  if (gridIndex === -1) { fail("web/index.html: no se encontro el grid de x-autopilot"); return; }
  text = text.slice(0, gridIndex) + block + "\n" + text.slice(gridIndex);
  write("web/index.html", text);
  ok("web/index.html: banner de sesion de X anadido");
})();

// ---------------------------------------------------------------------------
// 5b. web/index.html -- pestana de configuracion global de IA
// ---------------------------------------------------------------------------
(function installAiSettingsUi() {
  let text = read("web/index.html");
  if (!text) { fail("web/index.html no encontrado (config IA)"); return; }

  if (!text.includes(MARK.navAi)) {
    const navAnchor = `<button class="nav-item" data-view="settings">`;
    if (!text.includes(navAnchor)) { fail("web/index.html: no se encontro el nav de settings"); return; }
    const navButton = `        ${MARK.navAi}
        <button class="nav-item" data-view="ai-config">
          <i class="ph ph-brain"></i>
          <span>Configuracion IA</span>
        </button>
`;
    text = replaceOnce(text, navAnchor, `${navButton}${navAnchor}`, "nav config IA");
    ok("web/index.html: pestana Configuracion IA anadida al menu");
  } else {
    skip("web/index.html: pestana Configuracion IA ya presente");
  }

  if (!text.includes(MARK.htmlAi)) {
    const view = `
      ${MARK.htmlAi}
      <section id="view-ai-config" class="view-section">
        <header class="view-header">
          <div>
            <h2>Configuracion de IA</h2>
            <span class="view-subtitle">Guarda aqui tus claves una sola vez. Toda la app las usa en este orden automatico: xKiro (gratis) &rarr; Gemini gratis &rarr; DeepSeek (pago) &rarr; Gemini pago &rarr; OpenRouter.</span>
          </div>
          <span id="aiChainBadge" class="status-badge">Sin proveedores</span>
        </header>

        <div class="card" style="margin-bottom:16px;">
          <div class="card-title">Como funciona</div>
          <p class="form-hint">La app intenta primero xKiro con sus modelos gratuitos. Si falla o se agota, pasa solo al siguiente proveedor. No tienes que hacer nada mas.</p>
          <div id="aiChainList" class="ai-chain-list"></div>
          <label class="toggle-line" style="margin-top:14px;">
            <input id="aiChainEnabled" type="checkbox" checked>
            <span>Usar la cadena automatica en toda la app</span>
          </label>
        </div>

        <div class="settings-grid" id="aiProviderGrid"></div>

        <div class="card" style="margin-top:16px;">
          <div class="card-title">Probar una clave</div>
          <p class="form-hint">Hace una llamada real y corta para confirmar que la clave funciona.</p>
          <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
            <select id="aiTestProvider" class="control-input" style="max-width:240px;"></select>
            <button id="aiTestBtn" class="control-btn-small primary"><i class="ph ph-plug"></i> Probar</button>
            <span id="aiTestResult" class="form-hint"></span>
          </div>
          <p class="form-hint" id="aiLastTest" style="margin-top:8px;"></p>
        </div>
      </section>

`;
    const anchor = `      <!-- View: Auto Download -->`;
    if (!text.includes(anchor)) { fail("web/index.html: no se encontro el ancla para la vista IA"); return; }
    text = replaceOnce(text, anchor, `${view}${anchor}`, "vista config IA");
    ok("web/index.html: vista de configuracion de IA anadida");
  } else {
    skip("web/index.html: vista de configuracion IA ya presente");
  }

  write("web/index.html", text);
})();

// ---------------------------------------------------------------------------
// 6. web/app.js -- elementos, binding, render y handlers
// ---------------------------------------------------------------------------
(function installAppJs() {
  let text = read("web/app.js");
  if (!text) { fail("web/app.js no encontrado"); return; }

  if (!text.includes(MARK.jsBind)) {
    const anchor = "xReferencesList: document.getElementById(\"xReferencesList\")";
    if (!text.includes(anchor)) { fail("web/app.js: no se encontro xReferencesList en els"); write("web/app.js", text); return; }
    const addition = `${anchor},\n    xLoginBanner: document.getElementById("xLoginBanner"), xLoginTitle: document.getElementById("xLoginTitle"), xLoginMessage: document.getElementById("xLoginMessage"), xLoginStateBadge: document.getElementById("xLoginStateBadge"), xLoginBtn: document.getElementById("xLoginBtn"), xLoginSaveBtn: document.getElementById("xLoginSaveBtn"), xLoginCloseBtn: document.getElementById("xLoginCloseBtn"), xCookiesInput: document.getElementById("xCookiesInput"), xCookiesBtn: document.getElementById("xCookiesBtn"), xRetryBtn: document.getElementById("xRetryBtn"),\n    ${MARK.jsBind}`;
    text = replaceOnce(text, anchor, addition, "els de x login");
    ok("web/app.js: elementos de X registrados");
  } else {
    skip("web/app.js: elementos de X ya registrados");
  }

  if (!text.includes(MARK.jsHandlers)) {
    const bindAnchor = 'if (this.els.xReferenceBtn) this.els.xReferenceBtn.addEventListener("click", () => this.addXReference());';
    const binding = `${MARK.jsHandlers}\n    if (this.els.xLoginBtn) this.els.xLoginBtn.addEventListener("click", () => this.xLoginOpen());\n    if (this.els.xLoginSaveBtn) this.els.xLoginSaveBtn.addEventListener("click", () => this.xLoginSave());\n    if (this.els.xLoginCloseBtn) this.els.xLoginCloseBtn.addEventListener("click", () => this.xLoginClose());\n    if (this.els.xCookiesBtn) this.els.xCookiesBtn.addEventListener("click", () => this.xImportCookies());\n    if (this.els.xRetryBtn) this.els.xRetryBtn.addEventListener("click", () => this.xRetryFailed());\n    if (this.els.xReferenceBtn) this.els.xReferenceBtn.addEventListener("click", () => this.addXReference());`;
    text = replaceOnce(text, bindAnchor, binding, "bind de x login");
    ok("web/app.js: botones de sesion de X enlazados");
  } else {
    skip("web/app.js: botones de X ya enlazados");
  }

  if (!text.includes(MARK.jsRender)) {
    const renderAnchor = "  async refresh() {";
    const renderCall = `  ${MARK.jsRender}\n  async refreshXSession() {\n    try {\n      const data = await API.get("/api/x-autopilot/session");\n      this.renderXSession(data);\n    } catch (error) {\n      if (this.els.xLoginStateBadge) this.els.xLoginStateBadge.textContent = "Sin sesion";\n    }\n  },\n\n  renderXSession(data) {\n    if (!this.els.xLoginStateBadge) return;\n    const session = data?.session || {};\n    const ready = Boolean(session.saved);\n    this.els.xLoginStateBadge.textContent = ready ? "Sesion guardada" : (session.open ? "Ventana abierta" : "Sin sesion");\n    this.els.xLoginStateBadge.className = "status-badge" + (ready ? " success" : "");\n    if (this.els.xLoginMessage) {\n      this.els.xLoginMessage.textContent = ready\n        ? "Sesion de X lista. La publicacion automatica usara esta cuenta."\n        : "Aun no hay sesion guardada. Inicia sesion en la ventana de X o pega tus cookies.";\n    }\n    const worker = data?.worker ? "worker activo" : "worker detenido";\n    if (this.els.xLoginTitle) this.els.xLoginTitle.textContent = "Sesion de X (Twitter) - " + worker;\n  },\n\n  async xLoginOpen() { try { await API.post("/api/x-autopilot/login", {}); await this.refreshXSession(); } catch (error) { alert(error.message); } },\n  async xLoginSave() { try { const r = await API.post("/api/x-autopilot/login/save", {}); if (r && r.ok === false) throw new Error(r.error); await this.refreshXSession(); } catch (error) { alert(error.message); } },\n  async xLoginClose() { try { await API.post("/api/x-autopilot/login/close", {}); await this.refreshXSession(); } catch (error) { alert(error.message); } },\n  async xImportCookies() {\n    const value = this.els.xCookiesInput?.value || "";\n    if (!value.trim()) { alert("Pega tus cookies primero."); return; }\n    try {\n      const r = await API.post("/api/x-autopilot/cookies", { cookies: value });\n      if (r && r.ok === false) throw new Error(r.error);\n      if (this.els.xCookiesInput) this.els.xCookiesInput.value = "";\n      await this.refreshXSession();\n    } catch (error) { alert(error.message); }\n  },\n  async xRetryFailed() { try { await API.post("/api/x-autopilot/retry", {}); await this.refreshXAutopilot(); } catch (error) { alert(error.message); } },\n\n  async refreshXAutopilot() { try { const data = await API.get("/api/x-autopilot"); this.renderXAutopilot(data); } catch {} },\n\n${renderAnchor}`;
    text = replaceOnce(text, renderAnchor, renderCall, "refresh");
    ok("web/app.js: handlers de sesion de X anadidos");
  } else {
    skip("web/app.js: handlers de X ya presentes");
  }

  // Enlazar la llamada al refresco.
  if (!text.includes("this.refreshXSession()")) {
    const hook = 'API.get("/api/x-autopilot").then((data) => this.renderXAutopilot(data)).catch(() => { });';
    const withHook = `${hook}\n      this.refreshXSession();`;
    text = replaceOnce(text, hook, withHook, "hook de refresco de sesion");
    ok("web/app.js: refresco de sesion enlazado");
  }

  write("web/app.js", text);
})();

// ---------------------------------------------------------------------------
// 7. web/app.js -- logica de la configuracion global de IA
// ---------------------------------------------------------------------------
(function installAiConfigJs() {
  let text = read("web/app.js");
  if (!text) { fail("web/app.js no encontrado (config IA)"); return; }

  if (text.includes(MARK.jsAiLogic)) { skip("web/app.js: logica de config IA ya presente"); return; }

  const logic = `  ${MARK.jsAiLogic}
  aiConfig: null,

  async loadAiConfig() {
    try {
      this.aiConfig = await API.get("/api/ai-config");
      this.renderAiConfig(this.aiConfig);
      return this.aiConfig;
    } catch (error) {
      if (this.els.aiChainBadge) this.els.aiChainBadge.textContent = "Error: " + error.message;
      return null;
    }
  },

  renderAiConfig(data) {
    if (!data) return;
    const chain = data.chain || [];
    if (this.els.aiChainBadge) {
      this.els.aiChainBadge.textContent = chain.length
        ? chain.length + " modelos listos"
        : "Sin proveedores";
      this.els.aiChainBadge.className = "status-badge" + (chain.length ? " success" : "");
    }
    if (this.els.aiChainEnabled) this.els.aiChainEnabled.checked = data.enabled !== false;

    if (this.els.aiChainList) {
      const steps = [];
      const seen = new Set();
      for (const item of chain) {
        if (seen.has(item.provider)) continue;
        seen.add(item.provider);
        steps.push(\`<span class="ai-chain-step \${item.free ? "free" : ""}">\${escapeHtml(item.label)}\${item.free ? " · gratis" : ""}</span>\`);
      }
      this.els.aiChainList.innerHTML = steps.length
        ? steps.join('<span class="ai-chain-arrow">→</span>')
        : '<span class="form-hint">Aun no hay ninguna clave guardada. Empieza por xKiro, que es gratis.</span>';
    }

    if (this.els.aiProviderGrid) {
      this.els.aiProviderGrid.innerHTML = (data.providers || []).map((provider) => {
        const status = data.providerKeys?.[provider.id] || {};
        const modelList = (provider.models || []).map((m) => \`<option value="\${escapeHtml(m.id)}">\${escapeHtml(m.label || m.id)}</option>\`).join("");
        return \`
          <div class="card">
            <div class="card-title" style="display:flex; align-items:center; gap:8px;">
              \${escapeHtml(provider.label)}
              \${provider.free ? '<span class="tag-free">gratis</span>' : ""}
              \${status.configured ? '<span class="tag-ok">lista</span>' : ""}
            </div>
            <p class="form-hint">\${escapeHtml(provider.keyHint || "")}</p>
            <div class="helios-key-row">
              <input id="aiKey_\${provider.id}" class="control-input" type="password"
                placeholder="\${status.configured ? escapeHtml(status.masked) : "Pega tu clave"}" />
              <button class="control-btn-small primary" data-ai-save="\${provider.id}">Guardar</button>
              <button class="control-btn-small danger" data-ai-remove="\${provider.id}">Quitar</button>
            </div>
            <div class="helios-key-row" style="margin-top:8px;">
              <select class="control-input" id="aiModel_\${provider.id}">\${modelList}</select>
            </div>
          </div>\`;
      }).join("");

      this.els.aiProviderGrid.querySelectorAll("[data-ai-save]").forEach((button) => {
        button.addEventListener("click", () => this.saveAiKey(button.dataset.aiSave));
      });
      this.els.aiProviderGrid.querySelectorAll("[data-ai-remove]").forEach((button) => {
        button.addEventListener("click", () => this.removeAiKey(button.dataset.aiRemove));
      });
    }

    if (this.els.aiTestProvider) {
      this.els.aiTestProvider.innerHTML = (data.providers || [])
        .map((p) => \`<option value="\${escapeHtml(p.id)}">\${escapeHtml(p.label)}</option>\`)
        .join("");
    }
    if (this.els.aiLastTest) {
      const last = data.lastTest;
      this.els.aiLastTest.textContent = last
        ? \`Ultima prueba: \${last.provider}/\${last.model} · \${last.ms}ms · "\${String(last.sample || "").slice(0, 40)}"\`
        : "Aun no has probado ninguna clave.";
    }
  },

  async saveAiKey(providerId) {
    const input = document.getElementById("aiKey_" + providerId);
    const value = input?.value.trim() || "";
    if (!value) { alert("Pega la clave primero."); return; }
    try {
      await API.post("/api/ai-config", { providerKeys: { [providerId]: value } });
      input.value = "";
      await this.loadAiConfig();
    } catch (error) { alert(error.message); }
  },

  async removeAiKey(providerId) {
    try {
      await API.post("/api/ai-config", { removeProviders: [providerId] });
      await this.loadAiConfig();
    } catch (error) { alert(error.message); }
  },

  async testAiProvider() {
    const provider = this.els.aiTestProvider?.value;
    if (!provider) return;
    if (this.els.aiTestResult) this.els.aiTestResult.textContent = "Probando...";
    try {
      const data = await API.post("/api/ai-config/test", { provider });
      const last = data.lastTest || {};
      if (this.els.aiTestResult) this.els.aiTestResult.textContent = \`OK · \${last.model} · \${last.ms}ms\`;
      this.renderAiConfig(data);
    } catch (error) {
      if (this.els.aiTestResult) this.els.aiTestResult.textContent = "Fallo: " + error.message;
    }
  },

  async toggleAiChain(enabled) {
    try {
      const data = await API.post("/api/ai-config", { enabled: Boolean(enabled) });
      this.renderAiConfig(data);
    } catch (error) { alert(error.message); }
  },

`;

  const anchor = "  async refresh() {";
  text = replaceOnce(text, anchor, `${logic}${anchor}`, "logica config IA");

  // Register the new elements.
  const elsAnchor = 'xLoginBanner: document.getElementById("xLoginBanner")';
  if (text.includes(elsAnchor) && !text.includes("aiChainBadge:")) {
    const elsAddition = `aiChainBadge: document.getElementById("aiChainBadge"), aiChainList: document.getElementById("aiChainList"), aiChainEnabled: document.getElementById("aiChainEnabled"), aiProviderGrid: document.getElementById("aiProviderGrid"), aiTestProvider: document.getElementById("aiTestProvider"), aiTestBtn: document.getElementById("aiTestBtn"), aiTestResult: document.getElementById("aiTestResult"), aiLastTest: document.getElementById("aiLastTest"),\n    ${elsAnchor}`;
    text = replaceOnce(text, elsAnchor, elsAddition, "els config IA");
  }

  // Bind events.
  const bindAnchor = 'if (this.els.xRetryBtn) this.els.xRetryBtn.addEventListener("click", () => this.xRetryFailed());';
  if (text.includes(bindAnchor) && !text.includes("this.els.aiTestBtn")) {
    const bindAddition = `${bindAnchor}\n    if (this.els.aiTestBtn) this.els.aiTestBtn.addEventListener("click", () => this.testAiProvider());\n    if (this.els.aiChainEnabled) this.els.aiChainEnabled.addEventListener("change", () => this.toggleAiChain(this.els.aiChainEnabled.checked));`;
    text = replaceOnce(text, bindAnchor, bindAddition, "bind config IA");
  }

  // Load on refresh.
  const hook = "this.refreshXSession();";
  if (text.includes(hook) && !text.includes("this.loadAiConfig()")) {
    text = replaceOnce(text, hook, `${hook}\n      this.loadAiConfig();`, "hook config IA");
  }

  write("web/app.js", text);
  ok("web/app.js: configuracion global de IA anadida");
})();

// ---------------------------------------------------------------------------
// 8. web/style.css -- estilos de la cadena de IA
// ---------------------------------------------------------------------------
(function installAiStyles() {
  const rel = "web/style.css";
  let text = read(rel);
  if (!text) { skip("web/style.css no encontrado; la pestana usara estilos por defecto"); return; }
  if (text.includes(MARK.cssAi)) { skip("web/style.css ya tiene los estilos de IA"); return; }
  text += `
${MARK.cssAi}
.ai-chain-list { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-top: 10px; }
.ai-chain-step { font-size: 12.5px; padding: 6px 12px; border-radius: 999px; background: #1a1e24; border: 1px solid #2c323c; color: #cdd6e2; }
.ai-chain-step.free { background: #0f2b1e; border-color: #1d4a35; color: #4ade80; }
.ai-chain-arrow { color: #6b7686; font-size: 14px; }
.tag-free { font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 6px; background: #0f2b1e; color: #4ade80; letter-spacing: .3px; }
.tag-ok { font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 6px; background: #101c2e; color: #9cc3ff; letter-spacing: .3px; }
`;
  write(rel, text);
  ok("web/style.css: estilos de la cadena de IA anadidos");
})();

// ---------------------------------------------------------------------------
// 9. src/autoclone/controller.js -- heredar las claves de la config global
// ---------------------------------------------------------------------------
(function installAutocloneBridge() {
  let text = read("src/autoclone/controller.js");
  if (!text) { skip("src/autoclone/controller.js no encontrado; se omite el puente de claves"); return; }
  if (text.includes(MARK.autoclone)) { skip("autoclone/controller.js ya usa la config global de IA"); return; }

  const marker = `${MARK.autoclone}\n    try {`;
  const anchor = "    return {\n      // Free key (gemini-2.5-flash) is used first; the paid key only kicks in";
  if (!text.includes(anchor)) { skip("autoclone/controller.js: no se encontro el bloque de claves; se omite"); return; }
  const bridge = `${marker}
      const globalAi = require("../ai-config");
      await globalAi.load();
      const globalKeys = globalAi.publicConfig().providerKeys || {};
      const hasGlobal = Object.values(globalKeys).some((entry) => entry && entry.configured);
      if (hasGlobal) {
        const pick = (id) => (globalKeys[id] && globalKeys[id].configured ? globalAi.keyFor(id) : "");
        return {
          apiKey: pick("gemini-free"),
          paidApiKey: pick("gemini-paid"),
          paidModel: "gemini-3.6-flash",
          openRouterKey: pick("openrouter"),
          deepSeekKey: pick("deepseek"),
          xKiroKey: pick("xkiro"),
          model: "gemini-3.6-flash",
          visionModel: "gemini-3.6-flash",
          fromGlobalConfig: true,
        };
      }
    } catch { /* sin config global: usa las claves de siempre */ }

    return {
      // Free key (gemini-2.5-flash) is used first; the paid key only kicks in`;
  text = replaceOnce(text, anchor, bridge, "puente config global en autoclone");
  write("src/autoclone/controller.js", text);
  ok("autoclone/controller.js: ahora usa la configuracion global de IA");
})();

// ---------------------------------------------------------------------------
// Helper: leer assets embebidos
// ---------------------------------------------------------------------------
function readAsset(name) {
  const candidates = [
    path.join(__dirname, "assets", name),
    path.join(ROOT, "assets", name),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return fs.readFileSync(candidate, "utf8");
  }
  throw new Error(`No se encontro el asset ${name} (junto al instalador o en assets/).`);
}

// ---------------------------------------------------------------------------
// Resumen
// ---------------------------------------------------------------------------
console.log("\n=== AutoSocial Studio - X Autopilot Fix ===");
for (const [status, message] of results) {
  console.log(`  [${status}] ${message}`);
}
const failures = results.filter(([status]) => status === "FAIL");
console.log(`\n${results.length - failures.length - results.filter(([s]) => s === "SKIP").length} cambios aplicados, ${results.filter(([s]) => s === "SKIP").length} ya presentes, ${failures.length} errores.`);
if (failures.length) {
  console.error("\nRevisa los errores de arriba antes de arrancar el dashboard.");
  process.exitCode = 1;
} else {
  console.log("\nReinicia el dashboard (node src/dashboard-server.js) y abre la pestana X Autopilot.");
}
