# Arreglo: los dias no se aplican al programar en TikTok

Ejemplo tuyo: marcas Mie/Jue/Vie -> deberian ser 30, 1 y 2. Se quedaba en el 29.

## Que hace cada script
1) `arreglar-dias-tiktok.js`  -> arregla el CALENDARIO de TikTok
   El calendario NO tiene boton "mes siguiente". El codigo buscaba uno que estaba
   deshabilitado, por eso nunca cambiaba de mes. Ahora lee el mes/anio del titulo
   (.month-title / .year-title) y busca el dia en su celda real (.days-wrapper .day).

2) `arreglar-dias-tiktok-2.js` -> dos cosas:
   a) Baja la espera del escaneo del video a 10 SEGUNDOS (antes minimo 60s y hasta
      10 min). Ya no se queda pillado en "Checking in progress...".
   b) Refuerza el cambio de mes: prueba el desplegable del titulo Y las flechas
      del propio calendario Y el teclado, hasta que el mes cambie de verdad.

## Como usarlo (Windows / Git Bash)
1. Cierra el dashboard (Ctrl+C).
2. En la carpeta del proyecto:
   C:\Users\msi\Downloads\autosocial-studio
3. Copia los dos scripts a esa carpeta.
4. Ejecuta EN ESTE ORDEN:
   node arreglar-dias-tiktok.js
   node arreglar-dias-tiktok-2.js
5. Arranca:
   npm run dashboard

## Deshacer
   node arreglar-dias-tiktok-2.js --revert
   node arreglar-dias-tiktok.js --revert

## Seguridad
- Idempotentes: si los ejecutas dos veces, no pasa nada.
- Hacen copia .bak antes de tocar nada.
- NO tocan la interfaz.
