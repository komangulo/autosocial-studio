#!/usr/bin/env python3
"""
TCG News Radar - Recolector local
=================================
Recoge noticias de One Piece TCG y Pokemon TCG desde Reddit y X (Twitter)
sin navegador, sin API keys de Reddit/X.

- Reddit: RSS publico (https://www.reddit.com/r/<sub>/new/.rss)
- X:      HTML publico de x.com -> IDs de tweet -> API de syndication de X
          (https://cdn.syndication.twimg.com/tweet-result), sin login.

Solo requiere 'requests' (o usa urllib si no esta instalado).
"""
import json
import random
import re
import time
import html as htmllib
import urllib.request
import urllib.error
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

try:
    import requests
    HAVE_REQUESTS = True
except ImportError:
    HAVE_REQUESTS = False

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# ----------------------------- configuracion -----------------------------
# Reddit desactivado: el usuario solo quiere X (Twitter).
SUBREDDITS = []

# Cuentas de X por defecto. Las 3 primeras son "VIP": sus posts de las ultimas
# 24 h se publican siempre (ver ciclo_auto.py). El resto pasa por TypeSafe.
X_ACCOUNTS = [
    "AndyCollectz", "OPTCGAlert", "OPMerchandise",
    "ONEPIECE_tcg", "ONEPIECE_tcg_EN", "iamapokeMOM", "BN_pokemon",
    "opcgshopus", "dddict0407", "OPCGShopUK", "Meisy_TCG_News",
    "mako_pokeca", "sunrising162136",
]

# Cuentas VIP: sus posts van directos, sin filtro de relevancia.
CUENTAS_VIP = ["AndyCollectz", "OPTCGAlert", "OPMerchandise"]

MAX_PER_X_ACCOUNT = 20   # tweets a leer por cuenta (con sesion)
MAX_PER_SUBREDDIT = 20   # posts a leer por subreddit

# Con sesion iniciada (LOGIN_X.bat) X entrega muchos mas tweets, asi que
# usamos el recolector de navegador. Si no hay Playwright o falla, se cae
# automaticamente al metodo publico (5 tweets por cuenta).
USAR_NAVEGADOR = True
# -------------------------------------------------------------------------

# Se rellenan desde el perfil activo (o los valores por defecto si no hay).
FUENTES = {"subs": None, "x": None, "feed_para_ti": False}


def set_fuentes(subs=None, x=None, feed_para_ti=False):
    """Fija las fuentes del perfil activo para esta recoleccion."""
    FUENTES["subs"] = list(subs) if subs else None
    FUENTES["x"] = list(x) if x else None
    FUENTES["feed_para_ti"] = bool(feed_para_ti)


def _subs():
    return FUENTES["subs"] if FUENTES["subs"] is not None else SUBREDDITS


def _x():
    return FUENTES["x"] if FUENTES["x"] is not None else X_ACCOUNTS


def get_text(url, timeout=25, headers=None):
    h = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9",
         "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
    if headers:
        h.update(headers)
    if HAVE_REQUESTS:
        r = requests.get(url, headers=h, timeout=timeout)
        r.raise_for_status()
        return r.text
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "ignore")


def clean(t):
    t = t or ""
    # Reddit RSS trae HTML embebido y restos tipo <!-- SC_OFF -->
    t = re.sub(r"<!--.*?-->", " ", t, flags=re.S)
    t = re.sub(r"<[^>]+>", " ", t)
    t = htmllib.unescape(t)
    return re.sub(r"\s+", " ", t).strip()


# ------------------------------- Reddit ---------------------------------
# Reddit aplica un limite por IP sobre el RSS publico (HTTP 429) con una
# ventana de tiempo. Cambiar de host no sirve (old.reddit redirige). Lo que
# funciona es insistir con esperas LARGAS. Ajusta aqui si te bloquea mucho.
REDDIT_INTENTOS = 4
REDDIT_ESPERAS = [12, 25, 45]   # segundos entre intento e intento
REDDIT_PAUSA = 3.0              # pausa entre subreddits


def fetch_reddit(sub):
    url = f"https://www.reddit.com/r/{sub}/new/.rss"
    xml = None
    for intento in range(REDDIT_INTENTOS):
        try:
            xml = get_text(url)
            if xml and "<entry>" in xml:
                break
            xml = None
        except Exception as e:
            ultimo = e
        if intento < REDDIT_INTENTOS - 1:
            espera = REDDIT_ESPERAS[min(intento, len(REDDIT_ESPERAS) - 1)]
            print(f"  [reddit] r/{sub}: limitado (429); espero {espera}s "
                  f"y reintento ({intento + 2}/{REDDIT_INTENTOS})...")
            time.sleep(espera + random.uniform(0, 3))
    if not xml:
        print(f"  [reddit] r/{sub}: no pude leerlo (Reddit sigue limitando). "
              f"Vuelve a ejecutar ESCANEAR en unos minutos.")
        return []
    entries = re.findall(r"<entry>(.*?)</entry>", xml, re.S)
    out = []
    for e in entries[:MAX_PER_SUBREDDIT]:
        def tag(name):
            m = re.search(rf"<{name}[^>]*>(.*?)</{name}>", e, re.S)
            if not m:
                return ""
            return htmllib.unescape(re.sub(r"<[^>]+>", " ", m.group(1))).strip()
        link_m = re.search(r'<link[^>]*href="([^"]+)"', e)
        link = link_m.group(1) if link_m else ""
        content = tag("content") or tag("summary")
        img_m = re.search(
            r'https?://[^"\'<>\s]+\.(?:jpg|jpeg|png|gif|webp)(?:\?[^"\'<>\s]*)?',
            htmllib.unescape(content + " " + e), re.I)
        img = img_m.group(0) if img_m else None
        title = tag("title")
        if not title or not link:
            continue
        out.append({
            "id": "rd_" + (re.search(r"/comments/([a-z0-9]+)/", link).group(1)
                           if re.search(r"/comments/([a-z0-9]+)/", link) else link[-16:]),
            "source": "reddit", "sub": "r/" + sub,
            "game": "pokemon" if "pokemon" in sub.lower() else "onepiece",
            "title": title,
            "text": clean(content)[:700],
            "image": img, "url": link,
            "author": tag("name"), "date_ms": None,
            "date": tag("updated") or tag("published"),
        })
    print(f"  [reddit] r/{sub}: {len(out)} posts")
    return out


# --------------------------------- X ------------------------------------
def x_tweet_ids(handle):
    try:
        html = get_text(f"https://x.com/{handle}")
    except Exception as e:
        print(f"  [x] @{handle}: error al abrir perfil ({e})")
        return []
    ids = list(dict.fromkeys(re.findall(r"/status/(\d{15,20})", html)))
    return ids[:MAX_PER_X_ACCOUNT]


def x_tweet_detail(tid):
    url = f"https://cdn.syndication.twimg.com/tweet-result?id={tid}&token=x"
    try:
        raw = get_text(url, timeout=18, headers={"Accept": "application/json"})
        d = json.loads(raw)
    except Exception:
        return None
    media = d.get("mediaDetails") or []
    images, videos = [], []
    for m in media:
        mtype = m.get("type")
        if mtype == "photo":
            if m.get("media_url_https"):
                images.append(m["media_url_https"])
        elif mtype in ("video", "animated_gif"):
            vi = m.get("video_info") or {}
            # elegir el mejor mp4 (mayor bitrate); descartar HLS
            mp4s = [v for v in (vi.get("variants") or [])
                    if v.get("content_type") == "video/mp4" and v.get("url")]
            best = max(mp4s, key=lambda v: v.get("bitrate") or 0) if mp4s else None
            if best:
                videos.append({
                    "url": best["url"],
                    "thumbnail": m.get("media_url_https"),
                    "type": mtype,
                })
            elif m.get("media_url_https"):
                # sin mp4: usar solo la miniatura como imagen
                images.append(m["media_url_https"])
    img = images[0] if images else (videos[0]["thumbnail"] if videos else None)
    text = d.get("text") or ""
    nt = d.get("note_tweet") or {}
    # los enlaces del tweet (ej. amzn.to/xxxx) viven en entities.urls; tambien
    # puede haberlos en el note_tweet (tweets largos)
    links = _links_de_entities(d)
    if nt.get("text"):
        text = nt["text"]
        links = list(dict.fromkeys(links + _links_de_entities(nt)))
    # Si el enlace real es de Amazon, sustituimos el t.co del texto por la URL
    # real. Asi el enlace sobrevive aunque un paso intermedio descarte el
    # campo 'links'.
    text = _expandir_amazon_en_texto(text, d, nt)
    es_respuesta, es_retuit = _tipo_tweet(d, text)
    return {
        "id": str(d.get("id_str") or tid),
        "text": text,
        "date": d.get("created_at") or "",
        "image": img,
        "images": images,
        "videos": videos,
        "links": links,
        "es_respuesta": es_respuesta,
        "es_retuit": es_retuit,
        "lang": d.get("lang") or "",
        "user": (d.get("user") or {}).get("screen_name") or "",
    }


def _tipo_tweet(d, text):
    """Dice si el tweet es una respuesta o un retuit (para poder excluirlos).

    - Retuit: el texto empieza por 'RT @' o el JSON trae retweeted_status.
    - Respuesta: el JSON trae in_reply_to_* o el texto empieza por '@'.
    Devuelve (es_respuesta, es_retuit).
    """
    txt = (text or "").lstrip()
    es_retuit = txt.startswith("RT @") or bool(
        d.get("retweeted_status") or d.get("retweeted_status_result"))
    es_respuesta = bool(
        d.get("in_reply_to_screen_name")
        or d.get("in_reply_to_status_id_str")
        or d.get("in_reply_to_user_id_str")) or txt.startswith("@")
    return es_respuesta, es_retuit


def _links_de_entities(d):
    """Devuelve las URLs externas de un objeto con 'entities.urls'.

    Se descartan los enlaces a media (pic.x.com / .../photo/1), porque no son
    productos. Se prefiere expanded_url (la URL real, no el t.co).
    """
    out = []
    ents = (d or {}).get("entities") or {}
    for u in (ents.get("urls") or []):
        url = u.get("expanded_url") or u.get("url") or ""
        if not url:
            continue
        low = url.lower()
        if "pic.x.com" in low or "/photo/" in low or "/video/" in low:
            continue
        out.append(url)
    return out


def _urls_amazon_de_entities(d):
    """Pares (tco_url, expanded_url) de los enlaces de Amazon del tweet."""
    pares = []
    ents = (d or {}).get("entities") or {}
    for u in (ents.get("urls") or []):
        tco = u.get("url") or ""
        real = u.get("expanded_url") or ""
        if not real:
            continue
        low = real.lower()
        if "pic.x.com" in low or "/photo/" in low or "/video/" in low:
            continue
        if any(k in low for k in ("amzn.to", "a.co/", "amzn.eu", "amzn.asia",
                                  "amazon.")):
            pares.append((tco, real))
    return pares


def _expandir_amazon_en_texto(text, *objs):
    """Reemplaza el t.co del texto por la URL real de Amazon.

    Asi el enlace no depende del campo 'links' (que otro paso podria perder).
    """
    for obj in objs:
        for tco, real in _urls_amazon_de_entities(obj):
            if tco and tco in text:
                text = text.replace(tco, real)
    return text


def game_of(handle):
    h = handle.lower()
    if any(k in h for k in ["poke", "mako", "bn_pokemon", "iamapoke"]):
        return "pokemon"
    return "onepiece"


def _items_de_detalle(handle, d):
    """Construye el item del radar a partir del detalle de un tweet."""
    body = clean(d["text"])
    if not body:
        return None
    return {
        "id": "tw_" + d["id"],
        "source": "x", "sub": "@" + handle,
        "game": game_of(handle),
        "title": body.split("。")[0][:120] if d.get("lang") == "ja" else body[:120],
        "text": body[:2000],
        "image": d["image"], "images": d.get("images", []),
        "videos": d.get("videos", []),
        "links": d.get("links", []),
        "es_respuesta": d.get("es_respuesta", False),
        "es_retuit": d.get("es_retuit", False),
        "url": f"https://x.com/{handle}/status/{d['id']}",
        "author": "@" + handle, "date_ms": None, "date": d["date"],
    }


def _fetch_x_con_navegador(cuentas):
    """Recolecta todas las cuentas con UNA sola sesion de navegador.

    Devuelve None si Playwright no esta disponible o no hay sesion, para que
    collect() pueda caer al metodo publico.
    """
    try:
        import importlib.util
        xb = Path(__file__).resolve().parent / "x_browser.py"
        spec = importlib.util.spec_from_file_location("x_browser", xb)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    except Exception as e:
        print(f"  [x-browser] no disponible: {e}")
        return None

    try:
        print(f"  [x-browser] usando tu sesion de X ({len(cuentas)} cuentas, "
              f"{MAX_PER_X_ACCOUNT} tweets/cuenta)...")
        resultado = mod.recolectar(cuentas, max_por_cuenta=MAX_PER_X_ACCOUNT,
                                   headless=False)
    except Exception as e:
        print(f"  [x-browser] fallo, uso el metodo publico: {e}")
        return None

    if not resultado or not any(resultado.values()):
        print("  [x-browser] no recogio tweets (falta sesion?). "
              "Uso el metodo publico.")
        return None

    items = []
    for handle, ids in resultado.items():
        for tid in ids:
            d = x_tweet_detail(tid)
            if not d:
                continue
            it = _items_de_detalle(handle, d)
            if it:
                items.append(it)
            time.sleep(0.25)
        print(f"  [x] @{handle}: {sum(1 for i in items if i['sub']=='@'+handle)} tweets")
    return items


def fetch_x_account(handle):
    ids = x_tweet_ids(handle)
    out = []
    for tid in ids:
        d = x_tweet_detail(tid)
        if not d:
            continue
        it = _items_de_detalle(handle, d)
        if it:
            out.append(it)
        time.sleep(0.35)
    print(f"  [x] @{handle}: {len(out)} tweets")
    return out


# ------------------------------- main -----------------------------------
def collect(quiet=False):
    items = []
    subs = _subs()
    cuentas = _x()
    if subs:
        print("Reddit:")
        for i, sub in enumerate(subs):
            items += fetch_reddit(sub)
            if i < len(subs) - 1:
                # pausa entre subreddits para no disparar el limite de Reddit
                time.sleep(REDDIT_PAUSA)
    if cuentas:
        print("X (Twitter):")
        via_navegador = None
        if USAR_NAVEGADOR:
            via_navegador = _fetch_x_con_navegador(cuentas)
        if via_navegador is not None:
            items += via_navegador
        else:
            # metodo publico: 5 tweets por cuenta, sin login
            print("  [!] Uso el metodo publico (5 tweets/cuenta). "
                  "Para 10+ con tu sesion:")
            print("      - copia x_browser.py a pipeline/")
            print("      - ejecuta LOGIN_X.bat una vez")
            with ThreadPoolExecutor(max_workers=3) as ex:
                for res in ex.map(fetch_x_account, cuentas):
                    items += res
    # "Para ti" (opcional, usa el navegador con tu sesion)
    if FUENTES.get("feed_para_ti"):
        print("Mi feed 'Para ti' (X):")
        try:
            import importlib.util
            fp = Path(__file__).resolve().parent / "feed_parati.py"
            spec = importlib.util.spec_from_file_location("feed_parati", fp)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            posts = mod.scan(scrolls=20, headless=False, max_posts=150)
            items += mod.to_items(posts)
        except SystemExit as e:
            print(f"  [parati] no disponible (falta Playwright): instala con "
                  f"'pip install playwright' y 'playwright install chromium'")
        except ImportError as e:
            print(f"  [parati] no disponible (falta Playwright): {e}")
        except Exception as e:
            print(f"  [parati] no pude leer el feed: {e}")
    # dedupe por id
    seen, uniq = set(), []
    for it in items:
        if it["id"] in seen:
            continue
        seen.add(it["id"])
        uniq.append(it)
    print(f"\nTOTAL recolectado: {len(uniq)} noticias "
          f"({sum(1 for i in uniq if i['source']=='x')} de X, "
          f"{sum(1 for i in uniq if i['source']=='reddit')} de Reddit)")
    return uniq


if __name__ == "__main__":
    import sys
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "raw.json")
    # permite pasar el perfil activo como 2do argumento
    if len(sys.argv) > 2:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import perfiles
        pf = perfiles.cargar(sys.argv[2])
        if pf:
            set_fuentes(pf.get("subs"), pf.get("x"), pf.get("feed_para_ti"))
    data = collect()
    out.write_text(json.dumps({"items": data}, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    print(f"Guardado en {out}")
