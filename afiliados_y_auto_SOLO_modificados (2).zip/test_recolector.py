#!/usr/bin/env python3
"""Comprueba que el recolector de X nuevo esta instalado y listo.

Se puede ejecutar desde cualquier sitio: busca la carpeta 'pipeline'
que contiene collect.py.
"""
import sys
from pathlib import Path


def encontrar_pipeline():
    """Devuelve la carpeta que contiene collect.py, o None."""
    aqui = Path(__file__).resolve().parent
    candidatos = [
        aqui,                                   # ejecutado dentro de pipeline/
        aqui.parent / "pipeline",               # ejecutado en tcgnews/
        aqui.parent,                            # ejecutado en pipeline/ (otra vez)
    ]
    for c in candidatos:
        if (c / "collect.py").exists():
            return c
    # ultimo recurso: rastrear hijos
    for c in [aqui, aqui.parent, aqui.parent.parent]:
        for sub in [c, c / "pipeline"]:
            if (sub / "collect.py").exists():
                return sub
    return None


print("=" * 60)
print("  COMPROBACION DEL RECOLECTOR DE X")
print("=" * 60)

PIPE = encontrar_pipeline()
if PIPE is None:
    print("  [X] No encuentro la carpeta pipeline (con collect.py).")
    print("      Ejecuta este script desde dentro de tu carpeta tcgnews.")
    sys.exit(1)

print(f"  Carpeta pipeline: {PIPE}")
print()

ok = True

# 1) collect.py nuevo?
c = PIPE / "collect.py"
txt = c.read_text(encoding="utf-8", errors="ignore")
nuevo = "USAR_NAVEGADOR" in txt
print(f"  collect.py ....... {'NUEVO (correcto)' if nuevo else 'ANTIGUO -> ejecuta ACTUALIZAR.bat'}")
if not nuevo:
    ok = False
for l in txt.splitlines():
    if l.startswith("MAX_PER_X_ACCOUNT"):
        print(f"                     {l.strip()}")
        break

# 2) x_browser.py?
xb = PIPE / "x_browser.py"
print(f"  x_browser.py ..... {'presente' if xb.exists() else 'FALTA -> ejecuta ACTUALIZAR.bat'}")
if not xb.exists():
    ok = False
else:
    import re as _re
    m = _re.search(r"MAX_POR_CUENTA\s*=\s*(\d+)", xb.read_text(encoding="utf-8", errors="ignore"))
    if m:
        print(f"                     MAX_POR_CUENTA = {m.group(1)}")
        if m.group(1) != "20":
            print("                     (esperado 20; ejecuta ACTUALIZAR.bat)")

# 2b) recent.py (filtro 24h)?
rc = PIPE / "recent.py"
print(f"  recent.py ........ {'presente' if rc.exists() else 'FALTA -> ejecuta ACTUALIZAR.bat'}")
if not rc.exists():
    ok = False

# 2d) generate.py con hashtags fijos?
gp = PIPE / "generate.py"
if gp.exists():
    gt = gp.read_text(encoding="utf-8", errors="ignore")
    tiene = "HASHTAGS_FIJOS" in gt
    print(f"  generate.py ...... {'con hashtags fijos (correcto)' if tiene else 'SIN hashtags fijos -> ejecuta ACTUALIZAR.bat'}")
    if tiene:
        import re as _re2
        m2 = _re2.search(r'HASHTAGS_FIJOS\s*=\s*\[(.*?)\]', gt, _re2.S)
        if m2:
            print(f"                     [{m2.group(1).strip()}]")
    if not tiene:
        ok = False
else:
    print("  generate.py ...... FALTA -> ejecuta ACTUALIZAR.bat")
    ok = False

# 2c) scanner.py con filtro 24h?
sc = PIPE.parent / "scanner.py"
if sc.exists():
    st = sc.read_text(encoding="utf-8", errors="ignore")
    tiene = "HORAS_RECIENTES" in st
    print(f"  scanner.py ....... {'con filtro 24h (correcto)' if tiene else 'ANTIGUO -> ejecuta ACTUALIZAR.bat'}")
    if not tiene:
        ok = False
else:
    print("  scanner.py ....... NO ENCONTRADO (esta en la carpeta tcgnews, no en pipeline)")
    ok = False

# 2e) afiliados.py (enlaces de Amazon con tu etiqueta)?
af = PIPE / "afiliados.py"
if af.exists():
    at = af.read_text(encoding="utf-8", errors="ignore")
    tiene = "mejor_enlace_afiliado" in at
    print(f"  afiliados.py ..... {'presente (Amazon con tu etiqueta)' if tiene else 'presente pero incompleto'}")
    if not tiene:
        ok = False
else:
    print("  afiliados.py ..... FALTA -> ejecuta ACTUALIZAR.bat")
    ok = False

# 3) playwright?
try:
    import playwright  # noqa
    print("  playwright ....... instalado")
except Exception:
    print("  playwright ....... FALTA -> pip install playwright ^&^& playwright install chromium")
    ok = False

# 4) sesion de X?
prof = PIPE.parent / ".browser-profile"
if prof.exists():
    tiene = any(prof.rglob("Cookies")) or any(prof.rglob("Local State"))
    print(f"  sesion de X ...... {'presente' if tiene else 'vacia -> ejecuta LOGIN_X.bat una vez'}")
    if not tiene:
        ok = False
else:
    print("  sesion de X ...... NO EXISTE -> ejecuta LOGIN_X.bat una vez")
    ok = False

print("=" * 60)
if ok:
    print("  TODO LISTO. Ejecuta ESCANEAR.bat y busca '[x-browser]'.")
else:
    print("  FALTAN COSAS (mira las lineas marcadas arriba).")
print("=" * 60)
sys.exit(0 if ok else 1)
