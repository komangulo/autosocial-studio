@echo off
setlocal
title TCG News Radar - MODO AUTOMATICO
color 0A
cd /d "%~dp0"

echo.
echo  ============================================================
echo    TCG NEWS RADAR - MODO AUTOMATICO (una sola ventana)
echo  ============================================================
echo.
echo  Deja esta ventana ABIERTA (puedes minimizarla).
echo.
echo  Hace TODO solo, todos los dias:
echo    1. Escanea tus fuentes (Reddit + X)
echo    2. Analiza y elige las mejores noticias
echo    3. Redacta los posts y les asigna hora
echo    4. A la hora de cada post: abre Brave, publica y cierra
echo.
echo  Ajustes: abre  pipeline\ciclo_auto.py  y cambia las
echo  lineas de arriba (MAX_POSTS_DIA, RELEVANCIA_MIN...).
echo.
echo  Pulsa Ctrl+C para detenerlo.
echo  ============================================================
echo.
pause

rem --- buscar Python (py, luego python) ---
set "PY="
py --version >nul 2>&1
if not errorlevel 1 set "PY=py"
if not defined PY (
  python --version >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo.
  echo  [ERROR] No encuentro Python. Instalalo desde python.org
  echo          y marca "Add Python to PATH" durante la instalacion.
  echo.
  pause
  exit /b 1
)

rem --- comprobar que existe el motor del ciclo ---
if not exist "pipeline\ciclo_auto.py" (
  echo.
  echo  [ERROR] No encuentro  pipeline\ciclo_auto.py
  echo.
  echo  Significa que ACTUALIZAR.bat todavia no copio los archivos
  echo  nuevos a tu carpeta. Haz esto:
  echo     1. Ejecuta ACTUALIZAR.bat ^(te pedira la ruta de tu pipeline^)
  echo     2. Cuando diga ACTUALIZADO, vuelve a ejecutar AUTO.bat
  echo.
  echo  Si ACTUALIZAR.bat no incluye ciclo_auto.py, avisame.
  echo.
  pause
  exit /b 1
)

rem --- aviso si falta la sesion de X ---
if not exist ".browser-profile" (
  echo.
  echo  [AVISO] No veo la sesion de X ^(.browser-profile^).
  echo          La primera vez ejecuta LOGIN_X.bat.
  echo.
)

echo  Arrancando el ciclo automatico... (Ctrl+C para parar)
echo.
%PY% pipeline\ciclo_auto.py
set "COD=%errorlevel%"
echo.
echo  ------------------------------------------------------------
echo  El ciclo se ha detenido (codigo %COD%).
if not "%COD%"=="0" echo  Hubo un error: lee las lineas de arriba.
echo  ------------------------------------------------------------
pause
