# -*- coding: utf-8 -*-
"""Repara perfiles/<slug>/perfil.json corruptos (JSON invalido).

Uso:
    python pipeline\\reparar_perfiles.py            # repara todos
    python pipeline\\reparar_perfiles.py onepiece   # solo uno

Hace copia de seguridad .bak antes de tocar nada.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PERFILES = ROOT / "perfiles"


def _limpiar(texto):
    """Arreglos tipicos de JSON mal guardado."""
    t = texto
    t = t.lstrip("\ufeff")
    t = t.replace("\u201c", '"').replace("\u201d", '"')
    t = t.replace("\u2018", "'").replace("\u2019", "'")
    t = t.replace("\xa0", " ")
    t = "".join(ch for ch in t if ch == "\n" or ch == "\t" or ord(ch) >= 32)
    t = re.sub(r",(\s*[}\]])", r"\1", t)
    t = re.sub(r'([\]\}])(\s*\n\s*")', r"\1,\2", t)
    t = re.sub(r'(\})(\s+")', r"\1,\2", t)
    return t


def _intentar(texto):
    try:
        return json.loads(texto), None
    except Exception as e:
        return None, str(e)


def arreglar_archivo(p):
    try:
        original = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        print(f"  [ERROR] no puedo leer {p}: {e}")
        return False

    datos, err = _intentar(original)
    if datos is not None:
        print(f"  [OK] {p.name}: ya es valido, no lo toco")
        return True

    print(f"  [!] {p}: JSON invalido -> {err}")
    respaldo = p.with_suffix(".json.bak")
    respaldo.write_text(original, encoding="utf-8")
    print(f"      copia de seguridad: {respaldo.name}")

    limpio = _limpiar(original)
    datos, err2 = _intentar(limpio)
    if datos is None:
        limpio2 = "\n".join(
            re.sub(r',\s*$', '', ln) if ln.strip().endswith(",") and not ln.strip().startswith('"')
            else ln for ln in limpio.splitlines())
        datos, err2 = _intentar(limpio2)
    if datos is None:
        idx = limpio.rfind("}")
        while idx > 0:
            datos, _ = _intentar(limpio[:idx + 1])
            if datos is not None:
                break
            idx = limpio.rfind("}", 0, idx)
        if datos is None:
            print(f"      [X] no pude reparar automaticamente ({err2})")
            return False

    p.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
    print("      [OK] reparado y guardado")
    return True


def main():
    slug = sys.argv[1] if len(sys.argv) > 1 else None
    if not PERFILES.exists():
        print(f"No existe la carpeta {PERFILES}")
        return 1
    objetivos = []
    if slug and (PERFILES / slug / "perfil.json").exists():
        objetivos.append(PERFILES / slug / "perfil.json")
    else:
        objetivos = sorted(PERFILES.glob("*/perfil.json"))
    if not objetivos:
        print("No encontre ningun perfil.json")
        return 1
    print("Reparador de perfiles")
    print("=" * 40)
    ok = sum(1 for f in objetivos if arreglar_archivo(f))
    print("=" * 40)
    print(f"{ok}/{len(objetivos)} correctos")
    return 0 if ok == len(objetivos) else 1


if __name__ == "__main__":
    sys.exit(main())
