#!/usr/bin/env python3
"""
TCG News Radar - Ciclo automatico completo (una sola ventana)
=============================================================
Deja esta ventana ABIERTA y olvidate. Hace TODO el ciclo solo:

    [1] Escanea    : recoge noticias (Reddit + X) de tus fuentes
    [2] Analiza    : TypeSafe puntua relevancia y confianza
    [3] Selecciona : marca solo las noticias que merecen la pena
    [4] Prepara    : redacta en ingles + descarga medios + asigna horas
    [5] Publica    : a la hora de cada post, abre Brave, publica y cierra
    [6] Duerme     : espera a la siguiente hora o al siguiente escaneo

Nada de dashboard ni de marcar a mano. Si un post falla, se salta.
Los ya publicados nunca se repiten.

AJUSTES (arriba del todo, cambialos a tu gusto):
    MAX_POSTS_DIA      cuantos posts como mucho al dia
    RELEVANCIA_MIN     puntuacion minima (0-3) para publicar una noticia
    CONFIANZA_MIN      confianza minima (0-1) del clasificador
    CATEGORIAS         que categorias entran (vac = todas)
    HORAS_ESCANEO      horas del dia (reloj local) en que se escanea, ej. [8, 12, 17]

Uso:
    python pipeline\\ciclo_auto.py            # bucle completo
    python pipeline\\ciclo_auto.py --estado   # ver progreso y salir
    python pipeline\\ciclo_auto.py --una      # un ciclo y salir (para probar)
"""
import argparse
import json
import random
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PIPE = ROOT / "pipeline"
LOG = ROOT / "publicar.log"

# ============================ AJUSTES ============================
# Sin tope diario: se publica todo lo que cumpla las reglas.
MAX_POSTS_DIA = 0          # 0 = SIN LIMITE
RELEVANCIA_MIN = 1.5       # 0 - 3   (regla TypeSafe para el resto de cuentas)
CONFIANZA_MIN = 0.5        # 0 - 1
CATEGORIAS = []            # ej. ["new_card_or_set", "market_price"]; vacio = todas
HORAS_ESCANEO = [8, 12, 17]  # horas EXACTAS del dia en que se escanea (reloj local)
SALTAR_RUMORES = True      # no publicar rumores sin confirmar

# Cuentas VIP: TODOS sus posts de las ultimas 24 h se publican, sin filtro.
# (No se cuentan las respuestas ni los retuits, solo posts propios.)
CUENTAS_VIP = ["AndyCollectz", "OPTCGAlert", "OPMerchandise"]

# Excluir respuestas y retuits en TODAS las cuentas (son conversacion, no noticia)
EXCLUIR_RESPUESTAS = True
EXCLUIR_RETUITS = True

# --- Filtro de TEMA: solo noticias de One Piece, nada de otros TCG ---
# Si el post menciona estas cosas y NO menciona One Piece, se descarta.
PALABRAS_OTROS_TCG = [
    "pokemon", "pokémon", "pikachu", "charizard", "eevee", "scarlet & violet",
    "scarlet and violet", "mega evolution", "psa grading", "psa 10", "psa 9",
    "yugioh", "yu-gi-oh", "magic the gathering", "mtg ", "lorcana",
    "dragon ball super card", "digimon card", "gundam card",
    "first partner", "booster box price", "celebration",
]
# Un post debe mencionar AL MENOS uno de estos para considerarse de One Piece.
PALABRAS_ONEPIECE = [
    "one piece", "onepiece", "optcg", "op-", "op0", "op1", "op2", "op3",
    "op4", "op5", "op6", "op7", "op8", "op9", "st-", "st0", "st1",
    "east blue", "grand line", "paramount war", "devil fruit", "luffy",
    "zoro", "nami", "sanji", "chopper", "shanks", "blackbeard",
    "op card", "one piece card", "bandai card",
]
SOLO_ONEPIECE = True   # True = descartar Pokemon/otros TCG por el texto
# ================================================================

sys.path.insert(0, str(PIPE))
try:
    import perfiles as _perfiles
except Exception:
    _perfiles = None


# ------------------------------ utilidades ------------------------------
def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass


def slug_activo():
    """Primer perfil que publica (normalmente 'onepiece')."""
    try:
        for p in _perfiles.listar():
            if p.get("publica"):
                return p["slug"]
        return _perfiles.activo()
    except Exception:
        return "onepiece"


def perfil_dir(slug):
    if _perfiles:
        return _perfiles.perfil_dir(slug)
    return ROOT / "perfiles" / slug


def run(script, *args, quiet=False):
    cmd = [sys.executable, str(PIPE / script), *map(str, args)]
    if not quiet:
        print(f"    $ {' '.join(cmd)}")
    log(f"RUN {' '.join(cmd)}")
    r = subprocess.run(cmd)
    if r.returncode != 0:
        log(f"ERROR {script} codigo {r.returncode}")
        return False
    return True


# --------------------------- control diario ---------------------------
def _dia_path(d):
    return d / "publicados_dia.json"


def _leer_json(p, defecto):
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else defecto
    except Exception:
        return defecto


def publicados_hoy(d):
    """Cuantos posts se publicaron hoy (segun el registro diario)."""
    reg = _leer_json(_dia_path(d), {})
    hoy = datetime.now().strftime("%Y-%m-%d")
    if reg.get("fecha") != hoy:
        return 0
    return int(reg.get("n", 0))


def apuntar_publicado(d):
    hoy = datetime.now().strftime("%Y-%m-%d")
    reg = _leer_json(_dia_path(d), {})
    if reg.get("fecha") != hoy:
        reg = {"fecha": hoy, "n": 0}
    reg["n"] = int(reg.get("n", 0)) + 1
    try:
        _dia_path(d).write_text(json.dumps(reg, ensure_ascii=False, indent=1),
                                encoding="utf-8")
    except Exception:
        pass


# --------------------------- auto-seleccion ---------------------------
def _es_vip(it):
    """True si la noticia viene de una cuenta VIP (publicacion garantizada)."""
    sub = (it.get("sub") or "").lstrip("@").strip()
    return sub in CUENTAS_VIP


def _excluida(it):
    """True si es respuesta o retuit (no es un 'post' propio)."""
    if EXCLUIR_RESPUESTAS and it.get("es_respuesta"):
        return True
    if EXCLUIR_RETUITS and it.get("es_retuit"):
        return True
    return False


# Hashtags/relleno que AÑADE nuestro propio pipeline: no cuentan como tema.
_RELLENO_PROPIO = [
    "#onepiece", "#onepiececardgame", "onepiececardgame", "cardgame",
    "#tcg", "#anime", "#optcg",
]


def _texto_item(it):
    """Texto del post SIN los hashtags que anade nuestro pipeline."""
    t = ((it.get("title") or "") + " " + (it.get("text") or "")).lower()
    for k in _RELLENO_PROPIO:
        t = t.replace(k, " ")
    return t


def es_de_onepiece(it):
    """True si el texto del post trata de One Piece (o al menos no de otro TCG)."""
    t = _texto_item(it)
    if not t.strip():
        return True
    tiene_op = any(k in t for k in PALABRAS_ONEPIECE)
    tiene_otro = any(k in t for k in PALABRAS_OTROS_TCG)
    if tiene_op:
        return True          # habla de One Piece (aunque mencione otros)
    if tiene_otro:
        return False         # habla de Pokemon/MTG/etc pero no de One Piece
    return True              # ni uno ni otro: se deja pasar


def elegir_noticias(feed, ya_en_cola, cupo=0):
    """Devuelve las noticias que entran.

    Dos vias:
      - VIP (CUENTAS_VIP): TODOS sus posts de las 24 h, sin filtro de calidad.
      - Resto: solo si pasan las reglas de TypeSafe (relevancia, confianza,
        categoria, sin rumores sin confirmar).

    En ambos casos se excluyen respuestas y retuits, y las que ya estan en la
    cola o publicadas. Si 'cupo' > 0, limita a ese numero (0 = sin limite).
    """
    vip, resto = [], []
    for it in feed.get("items", []):
        if it.get("id") in ya_en_cola:
            continue
        if _excluida(it):
            continue
        if SOLO_ONEPIECE and not es_de_onepiece(it):
            continue
        if _es_vip(it):
            if not it.get("analyzed"):
                # una VIP sin analizar no esta clasificada, pero se publica
                # igual: se le pone una relevancia neutra para ordenar.
                it = dict(it)
                it.setdefault("relevance", 0)
            vip.append(it)
            continue
        # --- resto: reglas TypeSafe ---
        if not it.get("analyzed"):
            continue
        rel = it.get("relevance") or 0
        conf = it.get("confidence") if it.get("confidence") is not None else 1
        if rel < RELEVANCIA_MIN or conf < CONFIANZA_MIN:
            continue
        if CATEGORIAS and it.get("category") not in CATEGORIAS:
            continue
        if SALTAR_RUMORES and it.get("category") == "rumor_leak" \
                and (it.get("isConfirmed") or 1) < 0.5:
            continue
        resto.append(it)
    # mejor puntuacion primero; empate -> mas reciente. Las VIP van delante.
    key = lambda i: (i.get("relevance") or 0, i.get("date_ms") or 0)
    vip.sort(key=key, reverse=True)
    resto.sort(key=key, reverse=True)
    out = vip + resto
    return out[:cupo] if cupo and cupo > 0 else out


def ids_en_cola(d):
    cola = _leer_json(d / "cola.json", {"posts": []})
    ids = {p.get("id") for p in cola.get("posts", []) if p.get("id")}
    reg = _leer_json(d / "publicados.json", {"publicados": []})
    ids |= {r.get("id") for r in reg.get("publicados", []) if r.get("id")}
    return ids


def escribir_seleccion(d, noticias):
    """Escribe seleccion.json con las noticias elegidas (como el dashboard)."""
    sel_path = d / "seleccion.json"
    items = []
    for i in noticias:
        items.append({
            "id": i["id"], "url": i.get("url"), "source": i.get("source"),
            "sub": i.get("sub"), "game": i.get("game"), "title": i.get("title"),
            "text": i.get("text"), "image": i.get("image"),
            "images": i.get("images", []), "videos": i.get("videos", []),
            "links": i.get("links", []), "date": i.get("date"),
            "date_ms": i.get("date_ms"), "category": i.get("category"),
            "relevance": i.get("relevance"), "es_vip": _es_vip(i),
            "selected": True,
        })
    sel_path.write_text(json.dumps({"items": items}, ensure_ascii=False, indent=1),
                        encoding="utf-8")
    return len(items)


# ------------------------------- pasos -------------------------------
def paso_escanear(slug):
    print(f"\n  [1/3] Escaneando fuentes del perfil '{slug}'...")
    log("ciclo: escaneo")
    return run("scanner.py", "--perfil", slug)


def paso_preparar(slug, d, cupo=0):
    """Marca noticias y prepara la cola (redacta + medios + horas)."""
    feed = _leer_json(d / "feed.json", {"items": []})
    ya = ids_en_cola(d)
    elegidas = elegir_noticias(feed, ya, cupo)
    if not elegidas:
        print("  [2/3] Ninguna noticia nueva que publicar.")
        log("ciclo: sin noticias nuevas")
        return 0
    nvip = sum(1 for i in elegidas if _es_vip(i))
    n = escribir_seleccion(d, elegidas)
    print(f"  [2/3] Elegidas {n} noticias ({nvip} de cuentas VIP, "
          f"{n - nvip} por reglas TypeSafe) -> preparando la cola...")
    log(f"ciclo: seleccionadas {n} ({nvip} VIP)")
    if not run("scanner.py", "--perfil", slug, "--preparar"):
        return 0
    return n


def paso_publicar(d):
    """Publica los que ya tocan por su hora. Devuelve cuantos salio bien."""
    cola_path = d / "cola.json"
    cola = _leer_json(cola_path, None)
    if not cola:
        return 0
    antes = _leer_json(d / "publicados.json", {"publicados": []})
    n_antes = len(antes.get("publicados", []))
    print("  [3/3] Publicando los que ya tocan por su hora...")
    log("ciclo: publicar --vencidos")
    run("publish.py", cola_path, "--vencidos")
    despues = _leer_json(d / "publicados.json", {"publicados": []})
    n_despues = len(despues.get("publicados", []))
    nuevos = max(0, n_despues - n_antes)
    for _ in range(nuevos):
        apuntar_publicado(d)
    return nuevos


def proxima_hora(d):
    """Hora del proximo post pendiente, o None."""
    cola = _leer_json(d / "cola.json", None)
    if not cola:
        return None
    reg = _leer_json(d / "publicados.json", {"publicados": []})
    pub = {r.get("id") for r in reg.get("publicados", [])}
    horas = [p["scheduled_at"] for p in cola.get("posts", [])
             if p.get("post_en")
             and p.get("status") in ("listo", "programado", "publicando")
             and p.get("id") not in pub and p.get("scheduled_at")]
    return min(horas) if horas else None


def _hora_de_escaneo(ahora):
    """True si la hora/minuto actual coincide con una hora de HORAS_ESCANEO.

    Margen de 90 s para no perder la hora si el bucle se desfasa un poco.
    """
    if isinstance(HORAS_ESCANEO, (int, float)):
        return False
    for h in HORAS_ESCANEO:
        objetivo = ahora.replace(hour=h, minute=0, second=0, microsecond=0)
        if 0 <= (ahora - objetivo).total_seconds() < 90:
            return True
    return False


def proximo_escaneo(ahora=None):
    """Devuelve (datetime, segundos) del proximo escaneo segun HORAS_ESCANEO.

    HORAS_ESCANEO puede ser una lista de horas [8, 12, 17] (reloj local) o,
    por compatibilidad, un numero (cada N horas desde el arranque).
    """
    ahora = ahora or datetime.now()
    if isinstance(HORAS_ESCANEO, (int, float)) and HORAS_ESCANEO > 0:
        return None, HORAS_ESCANEO * 3600
    horas = sorted(h for h in HORAS_ESCANEO if 0 <= h <= 23)
    if not horas:
        return None, 3600
    hoy = ahora.date()
    for h in horas:
        objetivo = datetime.combine(hoy, datetime.min.time()).replace(hour=h)
        if objetivo > ahora:
            return objetivo, (objetivo - ahora).total_seconds()
    objetivo = datetime.combine(hoy + timedelta(days=1),
                                datetime.min.time()).replace(hour=horas[0])
    return objetivo, (objetivo - ahora).total_seconds()


def esperar_segundos(seg):
    """Duerme en tramos para poder responder a Ctrl+C."""
    fin = time.time() + max(0, seg)
    try:
        while time.time() < fin:
            time.sleep(min(30, max(1, fin - time.time())))
    except KeyboardInterrupt:
        print("\nInterrumpido por el usuario.")
        raise


def mostrar_estado(slug, d):
    print("=" * 60)
    print("  TCG NEWS RADAR - CICLO AUTOMATICO (estado)")
    print("=" * 60)
    print(f"  Perfil:            {slug}")
    tope = "sin limite" if not MAX_POSTS_DIA else str(MAX_POSTS_DIA)
    print(f"  Maximo posts/dia:  {tope}")
    print(f"  VIP (todo):        {', '.join(CUENTAS_VIP)}")
    print(f"  Resto (TypeSafe):  relevancia >= {RELEVANCIA_MIN}, "
          f"confianza >= {CONFIANZA_MIN}")
    print(f"  Publicados hoy:    {publicados_hoy(d)}")
    prox = proxima_hora(d)
    print(f"  Proximo post:      {prox or '(ninguno programado)'}")
    feed = _leer_json(d / "feed.json", {"items": []})
    ya = ids_en_cola(d)
    cand = elegir_noticias(feed, ya, 0)
    nvip = sum(1 for i in cand if _es_vip(i))
    print(f"  Candidatas nuevas: {len(cand)} ({nvip} VIP, {len(cand)-nvip} TypeSafe)")
    print("=" * 60)


# ------------------------------- bucle -------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--estado", action="store_true", help="ver progreso y salir")
    ap.add_argument("--una", action="store_true", help="un solo ciclo y salir")
    a = ap.parse_args()

    slug = slug_activo()
    d = perfil_dir(slug)

    if a.estado:
        mostrar_estado(slug, d)
        return 0

    print("=" * 60)
    print("  TCG NEWS RADAR - CICLO AUTOMATICO")
    print("=" * 60)
    print()
    print("  Deja esta ventana ABIERTA (puedes minimizarla).")
    print("  Escanea, elige, prepara y publica SOLO, todos los dias.")
    print(f"  VIP (todo): {', '.join(CUENTAS_VIP)}")
    print(f"  Resto: reglas TypeSafe (relev>= {RELEVANCIA_MIN}, conf>= {CONFIANZA_MIN}).")
    tope = "sin limite" if not MAX_POSTS_DIA else f"max {MAX_POSTS_DIA}/dia"
    print(f"  Posts al dia: {tope}. Pulsa Ctrl+C para salir.")
    print(f"  Escaneos al dia: {HORAS_ESCANEO}")
    print()

    ultimo_escaneo = 0.0
    while True:
        ahora = time.time()
        d.mkdir(parents=True, exist_ok=True)

        # --- 1) escanear a las horas fijas del dia ---
        if (isinstance(HORAS_ESCANEO, (int, float))
                and ahora - ultimo_escaneo >= HORAS_ESCANEO * 3600):
            paso_escanear(slug)
            ultimo_escaneo = time.time()
        elif _hora_de_escaneo(ahora):
            paso_escanear(slug)
            ultimo_escaneo = time.time()

        # --- 2) preparar (sin tope si MAX_POSTS_DIA = 0) ---
        cupo = 0 if not MAX_POSTS_DIA else MAX_POSTS_DIA - publicados_hoy(d)
        if not MAX_POSTS_DIA or cupo > 0:
            paso_preparar(slug, d, cupo)
        else:
            print(f"\n  Cupo de hoy alcanzado ({MAX_POSTS_DIA}). "
                  f"No se preparan mas hasta manana.")

        # --- 3) publicar lo que toque ---
        prox = proxima_hora(d)
        if prox:
            restante = (datetime.strptime(prox, "%Y-%m-%d %H:%M")
                        - datetime.now()).total_seconds()
            if restante <= 1:
                paso_publicar(d)
                # puede que queden mas posts vencidos: no dormimos aun
                continue
            print(f"\n[{datetime.now():%H:%M}] Proximo post: {prox} "
                  f"(faltan {int(restante//60)} min). Durmiendo...")
            log(f"ciclo: durmiendo hasta {prox}")
            try:
                esperar_segundos(restante)
            except KeyboardInterrupt:
                return 0
            continue

        # --- sin posts programados: esperar al proximo escaneo ---
        objetivo, falta = proximo_escaneo()
        falta = max(30, falta)
        cuando = objetivo.strftime("%H:%M") if objetivo else f"en {int(falta//60)} min"
        print(f"\n[{datetime.now():%H:%M}] Nada pendiente. "
              f"Proximo escaneo: {cuando} (en {int(falta//60)} min).")
        try:
            esperar_segundos(min(falta, 24 * 3600))
        except KeyboardInterrupt:
            return 0

        if a.una:
            return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nInterrumpido.")
        sys.exit(0)
