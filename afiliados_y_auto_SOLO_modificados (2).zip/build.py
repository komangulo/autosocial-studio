#!/usr/bin/env python3
"""Reconstruye index.html embebiendo TODOS los perfiles y app.js.

Embebe un objeto window.__PERFILES__:
    {
      "activo": "onepiece",
      "perfiles": [
         {"slug","nombre","categorias","publica","feed":{...}},
         ...
      ]
    }

Uso:
    python pipeline/build.py
"""
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root / "pipeline"))
import perfiles  # noqa: E402

html_p = root / "index.html"
app_p = root / "app.js"

perfiles.asegurar_onepiece()
lista = []
for pf in perfiles.listar():
    d = perfiles.perfil_dir(pf["slug"])
    feed_p = d / "feed.json"
    try:
        feed = json.loads(feed_p.read_text(encoding="utf-8")) if feed_p.exists() else {"items": []}
    except Exception:
        feed = {"items": []}
    feed["perfil"] = pf["slug"]
    feed["perfil_nombre"] = pf["nombre"]
    feed["categorias"] = pf.get("categorias", {})
    lista.append({
        "slug": pf["slug"],
        "nombre": pf["nombre"],
        "publica": bool(pf.get("publica")),
        "perfil_tipo": pf.get("perfil_tipo", "tcg"),
        "categorias": pf.get("categorias", {}),
        "categorias_desc": pf.get("categorias_desc", pf.get("categorias", {})),
        "relevance_pregunta": pf.get("relevance_pregunta", ""),
        "feed_para_ti": bool(pf.get("feed_para_ti")),
        "subs": pf.get("subs", []),
        "x": pf.get("x", []),
        "amazon_tag": pf.get("amazon_tag", ""),
        "feed": feed,
    })

data = {"activo": perfiles.activo(), "perfiles": lista}
payload = json.dumps(data, ensure_ascii=False)

app = app_p.read_text(encoding="utf-8")
html = html_p.read_text(encoding="utf-8")

embedded = ("<script>window.__PERFILES__ = " + payload + ";</script>\n<script>\n"
            + app + "\n</script>")
src_tag = '<script src="app.js"></script>'
if src_tag in html:
    html = html.replace(src_tag, embedded)
else:
    start = html.find("<script>window.__PERFILES__")
    if start == -1:
        start = html.find("<script>window.__FEED__")
    end = html.rfind("</script>")
    if start == -1 or end == -1:
        print("ERROR: no se encontró dónde insertar los datos en index.html")
        sys.exit(1)
    html = html[:start] + embedded + html[end + len("</script>"):]

html_p.write_text(html, encoding="utf-8")
total = sum(len(p["feed"].get("items", [])) for p in lista)
print(f"OK index.html actualizado ({len(html)} bytes, {len(lista)} perfiles, {total} noticias)")
