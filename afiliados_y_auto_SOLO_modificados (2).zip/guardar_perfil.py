#!/usr/bin/env python3
"""
TCG News Radar - Guarda las fuentes de un perfil
================================================
El dashboard, en Ajustes -> "Guardar fuentes del perfil", descarga
ajustes_perfil.json en tu carpeta de Descargas. Este script lo detecta,
actualiza el perfil.json correspondiente y reconstruye el dashboard.

Las fuentes (subreddits y cuentas de X) se guardan dentro del perfil y se
usan en los proximos escaneos, asi que persisten entre sesiones.

Uso:
    python pipeline/guardar_perfil.py [ruta/ajustes_perfil.json]
    python pipeline/guardar_perfil.py --mostrar [slug]
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "pipeline"))
import perfiles  # noqa: E402


def buscar_descarga():
    for carpeta in ("Downloads", "Descargas", "OneDrive/Descargas", "Escritorio",
                    "OneDrive/Escritorio", "Desktop"):
        dl = Path.home() / carpeta
        if dl.exists():
            cands = sorted(dl.glob("ajustes_perfil*.json"),
                           key=lambda p: p.stat().st_mtime, reverse=True)
            if cands:
                return cands[0]
    return None


def limpiar_subs(v):
    return [str(s).strip().lstrip("r/").strip() for s in (v or []) if str(s).strip()]


def limpiar_x(v):
    return [str(s).strip().lstrip("@").strip() for s in (v or []) if str(s).strip()]


def aplicar(data):
    slug = data.get("perfil") or data.get("slug")
    if not slug:
        print("El archivo no dice de que perfil son las fuentes.")
        return None
    pf = perfiles.cargar(slug)
    if not pf:
        print(f"No existe el perfil '{slug}'. Perfiles: "
              + ", ".join(p["slug"] for p in perfiles.listar()))
        return None

    subs = limpiar_subs(data.get("subs"))
    x = limpiar_x(data.get("x"))
    parati = bool(data.get("feed_para_ti"))
    if not subs and not x and not parati:
        print("No hay ninguna fuente. Escribe al menos un subreddit o una cuenta de X.")
        return None

    pf["subs"] = subs
    pf["x"] = x
    pf["feed_para_ti"] = parati
    # etiqueta de afiliado de Amazon (ej. tunombre-21). Vacio = desactivado.
    if "amazon_tag" in data:
        pf["amazon_tag"] = (data.get("amazon_tag") or "").strip()
    perfiles.guardar(pf)
    return pf


def main():
    if "--mostrar" in sys.argv:
        i = sys.argv.index("--mostrar")
        slug = sys.argv[i + 1] if len(sys.argv) > i + 1 else perfiles.activo()
        pf = perfiles.cargar(slug)
        if not pf:
            print(f"No existe el perfil '{slug}'")
            sys.exit(1)
        print(f"Perfil: {pf['nombre']} ({pf['slug']})")
        print(f"  Subreddits: {', '.join(pf.get('subs') or []) or '(ninguno)'}")
        print(f"  Cuentas X:  {', '.join('@' + s for s in (pf.get('x') or [])) or '(ninguna)'}")
        print(f"  Para ti:    {'si' if pf.get('feed_para_ti') else 'no'}")
        print(f"  Afiliado:   {pf.get('amazon_tag') or '(sin etiqueta de Amazon)'}")
        return

    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        ruta = Path(sys.argv[1])
    else:
        ruta = buscar_descarga()
        if not ruta:
            print()
            print("!" * 60)
            print("  No encontre ajustes_perfil.json en Descargas.")
            print("!" * 60)
            print("  1) Abre index.html y pulsa '⚙ Ajustes'")
            print("  2) En 'Fuentes de este perfil' escribe los subreddits y cuentas de X")
            print("  3) Pulsa 'Guardar fuentes del perfil' -> baja ajustes_perfil.json")
            print("  4) Vuelve a ejecutar GUARDAR_AJUSTES.bat")
            print("!" * 60)
            sys.exit(1)

    if not ruta.exists():
        print(f"No existe {ruta}")
        sys.exit(1)

    try:
        data = json.loads(ruta.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"No pude leer el archivo: {e}")
        sys.exit(1)

    pf = aplicar(data)
    if not pf:
        sys.exit(1)

    print()
    print("=" * 60)
    print(f"  FUENTES GUARDADAS EN: {pf['nombre']}  ({pf['slug']})")
    print("=" * 60)
    print(f"  Subreddits: {', '.join(pf['subs']) or '(ninguno)'}")
    print(f"  Cuentas X:  {', '.join('@' + s for s in pf['x']) or '(ninguna)'}")
    print(f"  Para ti:    {'si' if pf['feed_para_ti'] else 'no'}")
    print(f"  Afiliado:   {pf.get('amazon_tag') or '(sin etiqueta de Amazon)'}")
    print()

    import subprocess
    subprocess.run([sys.executable, str(ROOT / "pipeline" / "build.py")])
    print("\nListo. Abre index.html y veras las fuentes actualizadas.")
    try:
        ruta.unlink()
    except Exception:
        pass


if __name__ == "__main__":
    main()
