@echo off
setlocal enabledelayedexpansion
title TCG News Radar - ACTUALIZAR (20 tweets + filtro 24h)
color 0B

echo.
echo  ============================================================
echo    ACTUALIZAR TCG NEWS RADAR
echo    (20 tweets/cuenta + filtro de 24 horas)
echo  ============================================================
echo.

rem ---------------------------------------------------------------
rem  AVISO: si el .bat se ejecuta DESDE DENTRO del ZIP, Windows usa
rem  una carpeta temporal y las copias fallan. Lo detectamos.
rem ---------------------------------------------------------------
echo  Carpeta desde la que se ejecuta:
echo     %~dp0
echo.
echo %~dp0| findstr /I "\\Temp\\ \\AppData\\Local\\Temp\\" >nul
if not errorlevel 1 (
  echo  ============================================================
  echo   ATENCION: parece que estas ejecutando esto DESDE DENTRO
  echo   del archivo ZIP. Asi NO funciona.
  echo.
  echo   Haz esto:
  echo     1^) Clic derecho en el ZIP -^> Extraer todo...
  echo     2^) Elige una carpeta normal ^(ej. Escritorio^)
  echo     3^) Ejecuta ACTUALIZAR.bat DESDE ESA CARPETA
  echo  ============================================================
  echo.
  pause
  exit /b 1
)

cd /d "%~dp0"

rem ---------------------------------------------------------------
rem  1) Localizar la carpeta pipeline que contiene collect.py
rem ---------------------------------------------------------------
set "DEST="

for %%D in (
  "%USERPROFILE%\Downloads\tcgnews\pipeline"
  "%USERPROFILE%\Descargas\tcgnews\pipeline"
  "%USERPROFILE%\OneDrive\Downloads\tcgnews\pipeline"
  "%USERPROFILE%\OneDrive\Descargas\tcgnews\pipeline"
  "%USERPROFILE%\OneDrive\Documentos\tcgnews\pipeline"
  "%USERPROFILE%\OneDrive\Escritorio\tcgnews\pipeline"
  "%USERPROFILE%\Escritorio\tcgnews\pipeline"
  "%USERPROFILE%\Desktop\tcgnews\pipeline"
  "%USERPROFILE%\tcgnews\pipeline"
  "C:\tcgnews\pipeline"
  "%~dp0pipeline"
  "%~dp0..\pipeline"
  "%~dp0tcgnews\pipeline"
) do (
  if exist "%%~D\collect.py" if not defined DEST set "DEST=%%~D"
)

rem --- ultimo recurso: buscar tcgnews\pipeline un nivel mas arriba ---
if not defined DEST if exist "%~dp0..\..\tcgnews\pipeline\collect.py" set "DEST=%~dp0..\..\tcgnews\pipeline"

if not defined DEST (
  echo.
  echo  ============================================================
  echo   NO ENCONTRE LA CARPETA "tcgnews\pipeline"
  echo  ============================================================
  echo.
  echo   Busque en Descargas, Escritorio, OneDrive y junto a este archivo.
  echo.
  echo   HAZ ESTO:
  echo     1^) Abre la carpeta donde esta tu tcgnews
  echo     2^) Entra en ella y arrastra la carpeta "pipeline"
  echo        a esta ventana ^(o copia aqui su ruta completa^)
  echo     3^) Pulsa ENTER
  echo.
  echo   Ejemplo de ruta valida:
  echo     C:\Users\msi\Downloads\tcgnews\pipeline
  echo.
  echo   ^(Si pulsas ENTER sin escribir nada, se cancela.^)
  echo.
  set /p DEST="  Ruta: "
  set "DEST=!DEST:"=!"
)

if not defined DEST (
  echo.
  echo  Cancelado: no me diste ninguna ruta. No se copio nada.
  echo.
  pause
  exit /b 1
)

if not exist "%DEST%\collect.py" (
  echo.
  echo  [ERROR] En esa carpeta no hay collect.py:
  echo          %DEST%
  echo  Asegurate de que la ruta termina en  \pipeline
  echo.
  pause
  exit /b 1
)

echo  Carpeta encontrada:
echo     %DEST%
echo.
echo  ------------------------------------------------------------
echo   Copiando archivos...
echo  ------------------------------------------------------------
echo.

rem ---------------------------------------------------------------
rem  Copiado. Cada archivo se copia SOLO si viene en este paquete.
rem  Asi puedes instalar tanto el paquete completo como uno parcial
rem  (solo los archivos modificados) sin que de error.
rem ---------------------------------------------------------------

rem --- x_browser.py ---
if exist "x_browser.py" (
  copy /Y "x_browser.py" "%DEST%\x_browser.py" >nul 2>&1
  if errorlevel 1 goto :err_x_browser_py
  echo   [OK] x_browser.py
) else (
  echo   [--] x_browser.py no viene en el paquete, se deja igual
)

rem --- collect.py (con backup) ---
if exist "collect.py" (
  if not exist "%DEST%\collect_ORIGINAL_backup.py" copy /Y "%DEST%\collect.py" "%DEST%\collect_ORIGINAL_backup.py" >nul 2>&1
  copy /Y "collect.py" "%DEST%\collect.py" >nul 2>&1
  if errorlevel 1 goto :err_collect_py
  echo   [OK] collect.py
) else (
  echo   [--] collect.py no viene en el paquete, se deja igual
)

rem --- recent.py ---
if exist "recent.py" (
  copy /Y "recent.py" "%DEST%\recent.py" >nul 2>&1
  if errorlevel 1 goto :err_recent_py
  echo   [OK] recent.py
) else (
  echo   [--] recent.py no viene en el paquete, se deja igual
)

rem --- generate.py (hashtags fijos + afiliados) ---
if exist "generate.py" (
  if not exist "%DEST%\generate_ORIGINAL_backup.py" copy /Y "%DEST%\generate.py" "%DEST%\generate_ORIGINAL_backup.py" >nul 2>&1
  copy /Y "generate.py" "%DEST%\generate.py" >nul 2>&1
  if errorlevel 1 goto :err_generate_py
  echo   [OK] generate.py
) else (
  echo   [--] generate.py no viene en el paquete, se deja igual
)

rem --- test_recolector.py ---
if exist "test_recolector.py" (
  copy /Y "test_recolector.py" "%DEST%\test_recolector.py" >nul 2>&1
  echo   [OK] test_recolector.py
)

rem --- build.py (reconstruye el dashboard) ---
if exist "build.py" (
  if not exist "%DEST%\build_ORIGINAL_backup.py" copy /Y "%DEST%\build.py" "%DEST%\build_ORIGINAL_backup.py" >nul 2>&1
  copy /Y "build.py" "%DEST%\build.py" >nul 2>&1
  if errorlevel 1 goto :err_build_py
  echo   [OK] build.py
) else (
  echo   [--] build.py no viene en el paquete, se deja igual
)

rem --- guardar_perfil.py (Ajustes -> fuentes del perfil) ---
if exist "guardar_perfil.py" (
  if not exist "%DEST%\guardar_perfil_ORIGINAL_backup.py" copy /Y "%DEST%\guardar_perfil.py" "%DEST%\guardar_perfil_ORIGINAL_backup.py" >nul 2>&1
  copy /Y "guardar_perfil.py" "%DEST%\guardar_perfil.py" >nul 2>&1
  if errorlevel 1 goto :err_guardar_perfil_py
  echo   [OK] guardar_perfil.py
) else (
  echo   [--] guardar_perfil.py no viene en el paquete, se deja igual
)

rem --- publish.py (reanudacion: no repite publicados) ---
if exist "publish.py" (
  if not exist "%DEST%\publish_ORIGINAL_backup.py" copy /Y "%DEST%\publish.py" "%DEST%\publish_ORIGINAL_backup.py" >nul 2>&1
  copy /Y "publish.py" "%DEST%\publish.py" >nul 2>&1
  if errorlevel 1 goto :err_publish_py
  echo   [OK] publish.py
) else (
  echo   [--] publish.py no viene en el paquete, se deja igual
)

rem --- schedule.py (no reasigna hora a los ya publicados) ---
if exist "schedule.py" (
  if not exist "%DEST%\schedule_ORIGINAL_backup.py" copy /Y "%DEST%\schedule.py" "%DEST%\schedule_ORIGINAL_backup.py" >nul 2>&1
  copy /Y "schedule.py" "%DEST%\schedule.py" >nul 2>&1
  if errorlevel 1 goto :err_schedule_py
  echo   [OK] schedule.py
) else (
  echo   [--] schedule.py no viene en el paquete, se deja igual
)

rem --- afiliados.py (enlaces de Amazon con tu etiqueta) ---
if exist "afiliados.py" (
  copy /Y "afiliados.py" "%DEST%\afiliados.py" >nul 2>&1
  if errorlevel 1 goto :err_afiliados_py
  echo   [OK] afiliados.py
) else (
  echo   [--] afiliados.py no viene en el paquete, se deja igual
)

rem --- ciclo_auto.py (modo automatico: escanea+elige+publica) ---
if exist "ciclo_auto.py" (
  copy /Y "ciclo_auto.py" "%DEST%\ciclo_auto.py" >nul 2>&1
  if errorlevel 1 goto :err_ciclo_auto_py
  echo   [OK] ciclo_auto.py
) else (
  echo   [--] ciclo_auto.py no viene en el paquete, se deja igual
)

rem --- scanner.py, index.html, app.js y GUARDAR_AJUSTES.bat (carpeta raiz) ---
set "RAIZ=%DEST%\.."
if not exist "%RAIZ%\scanner.py" set "RAIZ=%DEST%"

if exist "scanner.py" (
  if exist "%RAIZ%\scanner.py" (
    if not exist "%RAIZ%\scanner_ORIGINAL_backup.py" copy /Y "%RAIZ%\scanner.py" "%RAIZ%\scanner_ORIGINAL_backup.py" >nul 2>&1
    copy /Y "scanner.py" "%RAIZ%\scanner.py" >nul 2>&1
    echo   [OK] scanner.py ^(en tcgnews\^)
  ) else (
    echo   [--] scanner.py: no encontre tcgnews\scanner.py, copialo a mano
  )
)

if exist "index.html" (
  if exist "%RAIZ%\index.html" (
    if not exist "%RAIZ%\index_ORIGINAL_backup.html" copy /Y "%RAIZ%\index.html" "%RAIZ%\index_ORIGINAL_backup.html" >nul 2>&1
    copy /Y "index.html" "%RAIZ%\index.html" >nul 2>&1
    echo   [OK] index.html ^(en tcgnews\^)
  ) else (
    copy /Y "index.html" "%RAIZ%\index.html" >nul 2>&1
    echo   [OK] index.html ^(creado en tcgnews\^)
  )
)
if exist "app.js" (
  copy /Y "app.js" "%RAIZ%\app.js" >nul 2>&1
  echo   [OK] app.js
)
if exist "GUARDAR_AJUSTES.bat" copy /Y "GUARDAR_AJUSTES.bat" "%RAIZ%\GUARDAR_AJUSTES.bat" >nul 2>&1


rem --- esperar_y_publicar.py (reanudacion) + ESTADO_COLA.bat ---
if exist "esperar_y_publicar.py" (
  if exist "%RAIZ%\esperar_y_publicar.py" (
    if not exist "%RAIZ%\esperar_y_publicar_ORIGINAL_backup.py" copy /Y "%RAIZ%\esperar_y_publicar.py" "%RAIZ%\esperar_y_publicar_ORIGINAL_backup.py" >nul 2>&1
    copy /Y "esperar_y_publicar.py" "%RAIZ%\esperar_y_publicar.py" >nul 2>&1
    echo   [OK] esperar_y_publicar.py ^(en tcgnews\^)
  ) else (
    copy /Y "esperar_y_publicar.py" "%RAIZ%\esperar_y_publicar.py" >nul 2>&1
    echo   [OK] esperar_y_publicar.py ^(creado en tcgnews\^)
  )
)
if exist "ESTADO_COLA.bat" (
  copy /Y "ESTADO_COLA.bat" "%RAIZ%\ESTADO_COLA.bat" >nul 2>&1
  echo   [OK] ESTADO_COLA.bat
)

if exist "AUTO.bat" (
  copy /Y "AUTO.bat" "%RAIZ%\AUTO.bat" >nul 2>&1
  echo   [OK] AUTO.bat ^(modo automatico^)
)

echo.
echo  ------------------------------------------------------------
echo   COMPROBANDO
echo  ------------------------------------------------------------
set "AVISOS=0"

if exist "%DEST%\collect.py" (
  findstr /C:"MAX_PER_X_ACCOUNT = 20" "%DEST%\collect.py" >nul 2>&1
  if errorlevel 1 (
    echo   [AVISO] collect.py no tiene el limite 20
  set "AVISOS=1"
  ) else (
    echo   [OK] collect.py con limite de 20 tweets/cuenta
  )
)
if exist "%DEST%\x_browser.py" (
  echo   [OK] x_browser.py presente
) else (
  echo   [AVISO] falta x_browser.py
  set "AVISOS=1"
)
if exist "%DEST%\recent.py" (
  echo   [OK] recent.py presente
) else (
  echo   [AVISO] falta recent.py
  set "AVISOS=1"
)

if exist "%DEST%\generate.py" (
  findstr /C:"HASHTAGS_FIJOS" "%DEST%\generate.py" >nul 2>&1
  if errorlevel 1 (
    echo   [AVISO] generate.py sin hashtags fijos
  set "AVISOS=1"
  ) else (
    echo   [OK] generate.py con hashtags fijos
  )
)
if exist "%DEST%\guardar_perfil.py" (
  echo   [OK] guardar_perfil.py presente
) else (
  echo   [AVISO] falta guardar_perfil.py
  set "AVISOS=1"
)

if exist "%DEST%\publish.py" (
  findstr /C:"_leer_registro" "%DEST%\publish.py" >nul 2>&1
  if errorlevel 1 (
    echo   [AVISO] publish.py sin reanudacion
  set "AVISOS=1"
  ) else (
    echo   [OK] publish.py reanuda sin repetir
  )
)
if exist "%RAIZ%\esperar_y_publicar.py" (
  findstr /C:"_registro" "%RAIZ%\esperar_y_publicar.py" >nul 2>&1
  if errorlevel 1 (
    echo   [AVISO] esperar_y_publicar.py sin reanudacion
  set "AVISOS=1"
  ) else (
    echo   [OK] esperar_y_publicar.py reanuda sin repetir
  )
)
if exist "%RAIZ%\index.html" (
  findstr /C:"saveFuentes" "%RAIZ%\index.html" >nul 2>&1
  if errorlevel 1 (
    echo   [AVISO] index.html sin "Fuentes de este perfil"
  set "AVISOS=1"
  ) else (
    echo   [OK] index.html con fuentes del perfil
  )
  findstr /C:"setAmazonTag" "%RAIZ%\index.html" >nul 2>&1
  if errorlevel 1 (
    echo   [AVISO] index.html sin campo de afiliado
  set "AVISOS=1"
  ) else (
    echo   [OK] index.html con campo de afiliado Amazon
  )
)
if exist "%DEST%\ciclo_auto.py" (
  echo   [OK] ciclo_auto.py ^(modo automatico^)
) else (
  echo   [AVISO] falta ciclo_auto.py
  set "AVISOS=1"
)
if exist "%RAIZ%\AUTO.bat" (
  echo   [OK] AUTO.bat en tcgnews\
) else (
  echo   [AVISO] falta AUTO.bat
  set "AVISOS=1"
)
if exist "%DEST%\afiliados.py" (
  echo   [OK] afiliados.py ^(enlaces Amazon^)
) else (
  echo   [AVISO] falta afiliados.py
  set "AVISOS=1"
)

echo.
if "%AVISOS%"=="1" (
  echo  ============================================================
  echo    ACTUALIZADO, PERO CON AVISOS
  echo  ============================================================
  echo   Mira las lineas marcadas con [AVISO] mas arriba.
  echo   Lo habitual: instalaste un paquete parcial y falta algun
  echo   archivo. Ejecuta el paquete COMPLETO si quieres todo.
) else (
  echo  ============================================================
  echo    ACTUALIZADO CORRECTAMENTE
  echo  ============================================================
)
echo.
echo   Ahora:
echo     1) LOGIN_X.bat  (solo si nunca lo hiciste)
echo     2) Abre AUTO.bat y deja la ventana abierta ^(modo automatico^)
echo        o bien ESCANEAR.bat si prefieres hacerlo a mano.
echo.
echo   Para cambiar las fuentes de un perfil (X):
echo     Abre index.html -^> Ajustes -^> "Fuentes de este perfil"
echo     y ejecuta GUARDAR_AJUSTES.bat
echo.
echo   Para ver el progreso de la cola (si te quedaste a medias):
echo     ejecuta ESTADO_COLA.bat
echo.
pause
exit /b 0

:err_x_browser_py
set "FALLO=x_browser.py"
goto :err
:err_collect_py
set "FALLO=collect.py"
goto :err
:err_recent_py
set "FALLO=recent.py"
goto :err
:err_generate_py
set "FALLO=generate.py"
goto :err
:err_build_py
set "FALLO=build.py"
goto :err
:err_guardar_perfil_py
set "FALLO=guardar_perfil.py"
goto :err
:err_publish_py
set "FALLO=publish.py"
goto :err
:err_schedule_py
set "FALLO=schedule.py"
goto :err
:err_afiliados_py
set "FALLO=afiliados.py"
goto :err
:err_ciclo_auto_py
set "FALLO=ciclo_auto.py"
goto :err

:err
echo.
echo  ============================================================
echo   HUBO UN ERROR copiando algun archivo.
if defined FALLO echo   Archivo que fallo: !FALLO!
echo  ============================================================
echo.
echo   Causas habituales:
echo   - No tienes permiso de escritura en la carpeta de tcgnews.
echo   - Cierra el dashboard y cualquier programa que use esos archivos.
echo   - Copia el archivo a mano desde la carpeta del ZIP a tcgnews.
echo.
pause
exit /b 1
