@echo off
setlocal
title TCG News Radar - DIAGNOSTICO
color 0E
cd /d "%~dp0"

echo.
echo  ============================================================
echo    DIAGNOSTICO - TCG NEWS RADAR
echo  ============================================================
echo  Esta ventana NO se cierra hasta que pulses una tecla.
echo.
echo  1) CARPETA ACTUAL
echo     %~dp0
echo.
echo  2) ARCHIVOS EN ESTA CARPETA
dir /b *.py *.bat 2>nul
echo.
echo  3) CARPETA pipeline\
if exist "pipeline" (
  dir /b "pipeline\*.py" 2>nul
) else (
  echo     [ERROR] No existe la carpeta "pipeline" aqui.
)
echo.
echo  4) PYTHON
py --version 2>nul
if errorlevel 1 (
  python --version 2>nul
  if errorlevel 1 echo     [ERROR] Python no encontrado en el PATH.
)
echo.
echo  5) PIEZAS CLAVE
if exist "pipeline\ciclo_auto.py" (echo     [OK]  pipeline\ciclo_auto.py) else (echo     [FALTA] pipeline\ciclo_auto.py)
if exist "pipeline\afiliados.py"  (echo     [OK]  pipeline\afiliados.py)  else (echo     [FALTA] pipeline\afiliados.py)
if exist "pipeline\collect.py"    (echo     [OK]  pipeline\collect.py)    else (echo     [FALTA] pipeline\collect.py)
if exist "pipeline\generate.py"   (echo     [OK]  pipeline\generate.py)   else (echo     [FALTA] pipeline\generate.py)
if exist "scanner.py"             (echo     [OK]  scanner.py)             else (echo     [FALTA] scanner.py)
if exist "index.html"             (echo     [OK]  index.html)             else (echo     [FALTA] index.html)
echo.
echo  6) SESION DE X
if exist ".browser-profile" (echo     [OK]  .browser-profile) else (echo     [AVISO] falta .browser-profile ^(ejecuta LOGIN_X.bat^))
echo.
echo  ============================================================
echo  COPIA TODO ESTO Y ENVIAMELO (o haz una captura).
echo  ============================================================
echo.
pause
