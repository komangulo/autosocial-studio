@echo off
setlocal
title TCG News Radar - REPARAR PERFILES
color 0E
cd /d "%~dp0"

echo.
echo  ============================================================
echo    REPARADOR DE PERFILES  ^(arregla perfil.json corrupto^)
echo  ============================================================
echo.

set "PY="
py --version >nul 2>&1
if not errorlevel 1 set "PY=py"
if not defined PY (
  python --version >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo  [ERROR] No encuentro Python. Revisa la instalacion.
  echo.
  pause
  exit /b 1
)

set "REP="
if exist "pipeline\reparar_perfiles.py" set "REP=pipeline\reparar_perfiles.py"
if not defined REP if exist "reparar_perfiles.py" set "REP=reparar_perfiles.py"
if not defined REP (
  echo  [ERROR] No encuentro reparar_perfiles.py
  echo.
  pause
  exit /b 1
)

%PY% "%REP%"
echo.
echo  ------------------------------------------------------------
echo  Si algun perfil salio [X], mandame el archivo .bak
echo  ------------------------------------------------------------
pause
