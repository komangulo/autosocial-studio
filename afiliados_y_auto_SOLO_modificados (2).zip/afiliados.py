#!/usr/bin/env python3
"""
TCG News Radar - Deteccion y reemplazo de enlaces de afiliado de Amazon
=======================================================================
Las cuentas que seguimos (ej. @OPMerchandise) publican ofertas con SU enlace
de afiliado de Amazon (amzn.to, a.co, amazon.*/dp/...?tag=SU_TAG).

Este modulo:
  1. Encuentra esos enlaces en el texto original del tweet.
  2. Los resuelve (sigue la redireccion) para sacar el producto (ASIN).
  3. Reconstruye el enlace apuntando a TU etiqueta de afiliado.

Asi la comision de la venta es tuya, aunque la oferta la detecte la cuenta
original.

Solo se tocan enlaces de Amazon. El resto de enlaces se ignora (se siguen
eliminando como siempre).

Configuracion por perfil: campo "amazon_tag" en perfiles/<slug>/perfil.json
(se edita en Ajustes del dashboard). Si esta vacio, NO se reemplaza nada.
"""
import re
import urllib.request
import urllib.error

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# Dominios de Amazon que tratamos (con o sin www, cualquier pais)
AMAZON_HOST_RE = re.compile(
    r"(?:^|\.)((?:www\.)?(?:amazon\.[a-z.]{2,6}|amzn\.to|a\.co|amzn\.eu|"
    r"amzn\.asia|amzn\.com))$", re.I)

# Dominios acortadores de Amazon que hay que resolver
SHORTENERS = ("amzn.to", "a.co", "amzn.eu", "amzn.asia", "amzn.com")

# ASIN: 10 caracteres, empieza por B0 o ISBN (digito)
ASIN_RE = re.compile(r"/(?:dp|gp/product|gp/aw/d|product)/([A-Z0-9]{10})", re.I)

# Enlaces en texto (incluye t.co, que tambien resolvemos si apunta a Amazon)
URL_RE = re.compile(r"https?://[^\s<>\"')]+", re.I)


def es_amazon(url):
    """True si la URL es de un dominio de Amazon (o acortador suyo)."""
    m = re.match(r"https?://([^/\s]+)", url or "", re.I)
    if not m:
        return False
    host = m.group(1).lower()
    return bool(AMAZON_HOST_RE.search(host))


def resolver(url, timeout=15):
    """Sigue las redirecciones y devuelve la URL final (o la original)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.geturl()
    except Exception:
        return url


def extraer_asin(url):
    """Saca el ASIN de una URL de Amazon. Devuelve None si no lo encuentra."""
    if not url:
        return None
    m = ASIN_RE.search(url)
    if m:
        return m.group(1).upper()
    # formato ?asin=XXXX o /ASIN/ suelto
    m = re.search(r"[?&]asin=([A-Z0-9]{10})", url, re.I)
    if m:
        return m.group(1).upper()
    return None


def dominio_amazon(url):
    """Devuelve el dominio base de Amazon (ej. amazon.com, amazon.es)."""
    m = re.match(r"https?://([^/\s]+)", url or "", re.I)
    if not m:
        return "www.amazon.com"
    host = m.group(1).lower()
    for s in SHORTENERS:
        if host.endswith(s):
            return None  # hay que resolver primero
    if host.startswith("www."):
        return host
    if "amazon." in host:
        return host
    return "www.amazon.com"


def enlace_con_tag(url, tag, timeout=15):
    """Devuelve una URL de Amazon limpia con TU etiqueta de afiliado.

    - Resuelve acortadores (amzn.to, a.co...) siguiendo la redireccion.
    - Saca el ASIN del producto.
    - Devuelve  https://<dominio>/dp/<ASIN>?tag=<tag>
    Si no consigue el ASIN, devuelve None.
    """
    if not url:
        return None
    final = url
    host_l = re.match(r"https?://([^/\s]+)", url, re.I)
    host_l = host_l.group(1).lower() if host_l else ""
    if any(s in host_l for s in SHORTENERS):
        final = resolver(url, timeout=timeout)
    asin = extraer_asin(final) or extraer_asin(url)
    if not asin:
        return None
    dom = dominio_amazon(final) or dominio_amazon(url) or "www.amazon.com"
    base = f"https://{dom}/dp/{asin}"
    return f"{base}?tag={tag}" if tag else base


def enlaces_amazon(item):
    """Lista (sin duplicados) de enlaces de Amazon hallados en un item.

    Mira tanto los enlaces ya recolectados (item['links']) como el texto.
    """
    cands = []
    for u in (item.get("links") or []):
        if es_amazon(u):
            cands.append(u)
    for u in URL_RE.findall((item.get("text") or "") + " " + (item.get("title") or "")):
        if es_amazon(u):
            cands.append(u)
    vista, out = set(), []
    for u in cands:
        if u in vista:
            continue
        vista.add(u)
        out.append(u)
    return out


# Acortadores de X (t.co) o genericos que pueden esconder un enlace de Amazon.
TCO_RE = re.compile(r"https?://(?:t\.co|bit\.ly|ow\.ly|buff\.ly)/[A-Za-z0-9]+", re.I)


def _amazon_via_acortador(item, timeout=10, max_resolver=2):
    """Ultimo recurso: si el item no trae un enlace de Amazon directo, resuelve
    los t.co del texto (pocos) por si detras hay un amzn.to/amazon.

    Se limita a max_resolver URLs para no gastar tiempo de red.
    """
    texto = (item.get("text") or "") + " " + (item.get("title") or "")
    vistos = set()
    for u in TCO_RE.findall(texto):
        if u in vistos:
            continue
        vistos.add(u)
        if len(vistos) > max_resolver:
            break
        final = resolver(u, timeout=timeout)
        if es_amazon(final):
            return final
    return None


def mejor_enlace_afiliado(item, tag, timeout=15):
    """Devuelve el mejor enlace de afiliado (con tu tag) para un item.

    Prefiere el que de verdad lleva a un producto (tiene ASIN).
    Devuelve None si el item no trae enlaces de Amazon o no hay tag.
    """
    if not tag:
        return None
    for u in enlaces_amazon(item):
        enlace = enlace_con_tag(u, tag, timeout=timeout)
        if enlace:
            return enlace
    # fallback: resolver los t.co por si el enlace de Amazon iba escondido
    final = _amazon_via_acortador(item, timeout=min(timeout, 10))
    if final:
        return enlace_con_tag(final, tag, timeout=timeout)
    return None
