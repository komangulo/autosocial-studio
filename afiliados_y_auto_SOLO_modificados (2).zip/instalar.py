#!/usr/bin/env python3
"""Instalador alternativo (sin .bat): copia los archivos a tcgnews/pipeline.

Uso normal:
    python instalar.py

Si no encuentra la carpeta, pide la ruta. Tambien acepta la ruta directa:
    python instalar.py "C:\\Users\\msi\\Downloads\\tcgnews\\pipeline"
"""
import shutil
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent

ARCHIVOS_PIPELINE = ["x_browser.py", "collect.py", "recent.py", "test_recolector.py",
                     "generate.py", "build.py", "guardar_perfil.py", "publish.py",
                     "schedule.py", "afiliados.py", "ciclo_auto.py"]
ARCHIVOS_RAIZ = ["scanner.py", "index.html", "app.js", "GUARDAR_AJUSTES.bat",
                 "esperar_y_publicar.py", "ESTADO_COLA.bat", "AUTO.bat"]
PIPELINE_CON_BACKUP = ["collect.py", "generate.py", "build.py", "guardar_perfil.py", "publish.py", "schedule.py"]


def candidatos():
    home = Path.home()
    return [
        home / "Downloads" / "tcgnews" / "pipeline",
        home / "Descargas" / "tcgnews" / "pipeline",
        home / "OneDrive" / "Downloads" / "tcgnews" / "pipeline",
        home / "OneDrive" / "Documentos" / "tcgnews" / "pipeline",
        home / "OneDrive" / "Escritorio" / "tcgnews" / "pipeline",
        home / "Escritorio" / "tcgnews" / "pipeline",
        home / "Desktop" / "tcgnews" / "pipeline",
        Path("C:/tcgnews/pipeline"),
        AQUI / "pipeline",
        AQUI.parent / "pipeline",
    ]


def encontrar_destino():
    for c in candidatos():
        try:
            if (c / "collect.py").exists():
                return c
        except Exception:
            continue
    return None


def main():
    print("=" * 60)
    print("  INSTALADOR TCG NEWS RADAR (20 tweets + filtro 24h)")
    print("=" * 60)
    print(f"  Carpeta de este instalador:\n     {AQUI}\n")

    if sys.argv[1:]:
        dest = Path(sys.argv[1].strip('"').strip())
    else:
        dest = encontrar_destino()

    if dest is None or not (dest / "collect.py").exists():
        print("  No encontre la carpeta 'pipeline' de tcgnews.")
        print()
        print("  Pega la ruta completa y pulsa ENTER.")
        print("  Ejemplo:  C:\\Users\\msi\\Downloads\\tcgnews\\pipeline")
        print()
        try:
            dest = Path(input("  Ruta: ").strip('"').strip())
        except EOFError:
            print("  (sin entrada; cancelado)")
            return 1

    if not (dest / "collect.py").exists():
        print(f"\n  [ERROR] En esta carpeta no hay collect.py:\n     {dest}")
        return 1

    print(f"  Carpeta destino:\n     {dest}\n")
    print("  Copiando...")

    # backups (solo la primera vez)
    for nombre in PIPELINE_CON_BACKUP:
        origen = dest / nombre
        backup = origen.with_name(origen.stem + "_ORIGINAL_backup.py")
        if origen.exists() and not backup.exists():
            try:
                shutil.copy2(origen, backup)
                print(f"    backup de {nombre} -> {backup.name}")
            except Exception as e:
                print(f"    (aviso: no pude hacer backup de {nombre}: {e})")
    for nombre in ("scanner.py", "esperar_y_publicar.py"):
        raiz_f = dest.parent / nombre
        bkp = raiz_f.with_name(raiz_f.stem + "_ORIGINAL_backup.py")
        if raiz_f.exists() and not bkp.exists():
            try:
                shutil.copy2(raiz_f, bkp)
                print(f"    backup de {nombre} -> {bkp.name}")
            except Exception as e:
                print(f"    (aviso: no pude hacer backup de {nombre}: {e})")

    # copiar a pipeline/
    ok = True
    for nombre in ARCHIVOS_PIPELINE:
        src = AQUI / nombre
        if not src.exists():
            print(f"    [!] falta {nombre} en esta carpeta")
            ok = False
            continue
        try:
            shutil.copy2(src, dest / nombre)
            print(f"    OK  {nombre}")
        except Exception as e:
            print(f"    [ERROR] {nombre}: {e}")
            ok = False

    # copiar a la carpeta raiz (scanner.py, dashboard, .bat)
    raiz = dest.parent
    if (raiz / "scanner.py").exists():
        for nombre in ARCHIVOS_RAIZ:
            src = AQUI / nombre
            if src.exists():
                try:
                    shutil.copy2(src, raiz / nombre)
                    print(f"    OK  {nombre} (en tcgnews/)")
                except Exception as e:
                    print(f"    [ERROR] {nombre}: {e}")
                    ok = False
    else:
        print("    (aviso: no encontre scanner.py en tcgnews/; copialo a mano)")

    print()
    print("  Comprobando...")
    txt = (dest / "collect.py").read_text(encoding="utf-8", errors="ignore")
    if "MAX_PER_X_ACCOUNT = 20" in txt:
        print("    [OK] collect.py tiene el limite de 20")
    else:
        print("    [!] collect.py NO tiene el limite 20")
        ok = False

    for f in ["x_browser.py", "recent.py", "build.py", "guardar_perfil.py", "publish.py", "schedule.py"]:
        if (dest / f).exists():
            print(f"    [OK] {f} presente")
        else:
            print(f"    [!] falta {f}")
            ok = False

    gp = dest / "guardar_perfil.py"
    if gp.exists() and "ajustes_perfil" in gp.read_text(encoding="utf-8", errors="ignore"):
        print("    [OK] guardar_perfil.py sirve para Ajustes del perfil")
    else:
        print("    [!] guardar_perfil.py no es el correcto")
        ok = False

    pub_py = dest / "publish.py"
    if pub_py.exists() and "_leer_registro" in pub_py.read_text(encoding="utf-8", errors="ignore"):
        print("    [OK] publish.py con reanudacion (no repite publicados)")
    else:
        print("    [!] publish.py no tiene la reanudacion")
        ok = False

    eyp = raiz / "esperar_y_publicar.py"
    if eyp.exists() and "_registro" in eyp.read_text(encoding="utf-8", errors="ignore"):
        print("    [OK] esperar_y_publicar.py con reanudacion")
    else:
        print("    [!] falta esperar_y_publicar.py con reanudacion")
        ok = False

    ixx = raiz / "index.html"
    if ixx.exists() and "saveFuentes" in ixx.read_text(encoding="utf-8", errors="ignore"):
        print("    [OK] index.html con 'Fuentes de este perfil'")
    else:
        print("    [!] index.html no tiene la seccion de fuentes del perfil")
        ok = False

    print()
    print("=" * 60)
    if ok:
        print("  TODO LISTO.")
        print("  Ahora: LOGIN_X.bat (si nunca)  y  ESCANEAR.bat")
        print("  Deberias ver: 20 tweets/cuenta y el filtro de 24 horas.")
        print("  Ajustes del perfil:  GUARDAR_AJUSTES.bat")
    else:
        print("  FALTAN COSAS (mira los [!] de arriba).")
    print("=" * 60)
    try:
        input("\nPulsa ENTER para cerrar...")
    except EOFError:
        pass
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
