#!/usr/bin/env python3
"""
TCG News Radar - Generador de posts en inglés
=============================================
Para cada noticia marcada produce un post listo para X:

  1. Xkiro (modelos gratis) reescribe en INGLES (mismo significado y
     estructura, palabras distintas) y lo deja en <= 280 caracteres.
  2. Jev (TypeSafe) VERIFICA: mismo significado, ingles natural, sin promo.
  3. Si falla la verificacion, se reintenta una vez; si aun asi falla, se
     guarda marcado para revision.

Modelos: se rotan en este orden hasta que uno responda:
    minimax-m3:free -> qwen3.7-flash:free -> ministral-14b -> mistral-small-2603

Hashtags: se conservan los del original EXCEPTO los de publicidad
(#Ad, #sponsored, #promo, #paid, #affiliate, #partner, #advertisement...).
Nunca se anaden enlaces.

Uso:
    python pipeline/generate.py feed.json cola.json
"""
import json
import os
import re
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

try:
    import requests
    HAVE_REQUESTS = True
except ImportError:
    HAVE_REQUESTS = False

# Deteccion/reemplazo de enlaces de afiliado de Amazon (amzn.to -> tu tag).
# Si el modulo no esta, la funcion queda desactivada y nada se rompe.
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import afiliados
except Exception:
    afiliados = None

# --- Xkiro (API compatible con OpenAI) ---
XKIRO_URL = "https://api.xkiro.com/v1/chat/completions"
XKIRO_MODELS = [
    "minimax/minimax-m3:free",
    "qwen/qwen3.7-flash:free",
    "mistralai/ministral-14b",
    "mistralai/mistral-small-2603",
]
JEV_URL = "https://api.typesafe.ai/v1/systemone"

PROMO_TAGS = re.compile(
    r"#(ad|ads|advertisement|sponsored|sponsor|promo|promotion|paid|affiliate|"
    r"partner|partnership|referral|discount|sale|coupon)\b", re.I)

# Hashtags OBLIGATORIOS en TODOS los posts. Se anaden siempre, al final, y
# nunca se recortan. Sirven para que el algoritmo y la gente los identifiquen.
HASHTAGS_FIJOS = ["#OnePiece", "#OnePieceCardGame"]

# En X los enlaces cuentan como 23 caracteres. No metemos enlaces, pero por si
# el original trae alguno en el texto, lo tratamos igual.
URL_RE = re.compile(r"https?://\S+")
URL_WEIGHT = 23


def env_or_dotenv(name):
    v = os.environ.get(name, "").strip()
    if v:
        return v
    env = Path(__file__).resolve().parent.parent / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith(name):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def post_length(text):
    """Longitud segun X: cada URL cuenta como 23 caracteres."""
    return len(URL_RE.sub("x" * URL_WEIGHT, text))


def http_json(url, body, headers, timeout=60):
    data = json.dumps(body).encode("utf-8")
    # Xkiro (Cloudflare) rechaza peticiones sin User-Agent de navegador (403).
    headers = dict(headers)
    headers.setdefault("User-Agent",
                       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36")
    if HAVE_REQUESTS:
        r = requests.post(url, data=data, headers=headers, timeout=timeout)
        if r.status_code in (429, 500, 503):
            raise RuntimeError(f"HTTP {r.status_code}")
        r.raise_for_status()
        return r.json()
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:200]
        raise RuntimeError(f"HTTP {e.code}: {detail}")


PROMPT = """You are preparing a social media post for X (Twitter) in ENGLISH.

TASK:
1. Rewrite the ORIGINAL below into English (if it is already English, rewrite it).
2. Keep the SAME meaning and the SAME structure. Change only some words \
(synonyms, small reordering) so it is NOT word-for-word identical, but reads \
exactly the same. This is important: avoid plagiarism detection.
3. The MAIN TEXT (without hashtags) must be at most {limit} characters. \
If the original is long, condense it keeping ONLY the most relevant information.
4. Keep the hashtags that appear in the original, but REMOVE any advertising \
ones: {promo}. If there are no hashtags, do not invent any.
5. ALWAYS end the post with these two hashtags, exactly as written: {fijos}. \
They are mandatory on every post. Do not translate them.
6. NEVER include links or URLs (no http, no t.co, no domains). A link may be \
added automatically AFTER your text; you must NOT write one yourself.
7. Answer ONLY with the final post text (text + hashtags), nothing else. \
No explanations, no quotes.

ORIGINAL:
{original}
"""


def xkiro_rewrite(original, limit, key, _cache={}):
    """Reescribe con Xkiro. Rota entre los 4 modelos gratis hasta que uno
    responda. Recuerda el ultimo que funciono para no repetir la ronda."""
    prompt = PROMPT.format(original=original, limit=limit,
                           promo=PROMO_TAGS.pattern,
                           fijos=" ".join(HASHTAGS_FIJOS))
    body = {
        "model": XKIRO_MODELS[0],
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7,
    }
    orden = XKIRO_MODELS
    if _cache.get("ok"):
        orden = [_cache["ok"]] + [m for m in XKIRO_MODELS
                                  if m != _cache["ok"]]
    headers = {"Content-Type": "application/json",
               "Authorization": "Bearer " + key}
    ultimo = None
    for modelo in orden:
        body["model"] = modelo
        try:
            j = http_json(XKIRO_URL, body, headers)
            txt = j["choices"][0]["message"]["content"].strip()
            if txt:
                _cache["ok"] = modelo
                return txt
            ultimo = RuntimeError("respuesta vacia")
        except Exception as e:
            ultimo = e
            continue
    raise RuntimeError(f"ningun modelo de Xkiro respondio: {ultimo}")


def jev_verify(original, published, key):
    body = {
        "state": {"original": original, "publicado": published},
        "model": "jev-latest",
        "questions": {
            "mismo_significado": {"type": "noul",
                "instructions": "¿El texto publicado mantiene el mismo significado que el original?"},
            "ingles_natural": {"type": "noul",
                "instructions": "¿El texto publicado es inglés correcto y natural?"},
            "sin_promo": {"type": "noul",
                "instructions": "¿El texto publicado está libre de hashtags publicitarios (#Ad, #sponsored, #promo, etc.)?"},
            "parece_copia": {"type": "noul",
                "instructions": "¿El texto publicado es una copia CASI IDÉNTICA palabra por palabra del original?",
                "criteria": {"true": "Prácticamente idéntico", "false": "Suficientemente distinto"}},
        },
    }
    headers = {"Content-Type": "application/json", "Authorization": "Bearer " + key}
    j = http_json(JEV_URL, body, headers)
    a = j.get("answers", {})
    return {
        "significado": a.get("mismo_significado", {}).get("noul", 0),
        "ingles": a.get("ingles_natural", {}).get("noul", 0),
        "sin_promo": a.get("sin_promo", {}).get("noul", 0),
        "copia": a.get("parece_copia", {}).get("noul", 1),
    }


def strip_promo_tags(text):
    out = PROMO_TAGS.sub("", text)
    return re.sub(r"\s{2,}", " ", out).strip()


def merge_hashtags(text, original):
    """Asegura que esten los hashtags del original (sin promo) Y los fijos.

    Los hashtags FIJOS (#OnePiece, #OnePieceCardGame) se anaden siempre,
    con independencia de lo que traiga el original. Nunca se eliminan.
    """
    # limpiamos tambien aqui la promo, por robustez
    text = strip_promo_tags(text)
    have = {t.lower() for t in re.findall(r"#\w+", text)}
    # 1) primero los obligatorios, para que vayan delante de los del original
    finales = [t for t in HASHTAGS_FIJOS if t.lower() not in have]
    have.update(t.lower() for t in finales)
    # 2) luego los del original (sin promo) que falten
    orig_tags = [t for t in re.findall(r"#\w+", original) if not PROMO_TAGS.match(t)]
    for t in orig_tags:
        if t.lower() in have:
            continue
        if t in HASHTAGS_FIJOS:
            continue
        have.add(t.lower())
        finales.append(t)
    return (text + " " + " ".join(finales)).strip() if finales else text


def garantizar_fijos(text):
    """Ultimo seguro: comprueba que los hashtags obligatorios estan presentes.

    Si xkiro los borro o el recorte los corto, los vuelve a anadir.
    """
    have = {t.lower() for t in re.findall(r"#\w+", text)}
    faltan = [t for t in HASHTAGS_FIJOS if t.lower() not in have]
    return (text + " " + " ".join(faltan)).strip() if faltan else text


def process(item, xkey, tkey, hashtags_max=280, amazon_tag="", mostrar_enlace=True):
    original = ((item.get("title") or "") + ". " + (item.get("text") or "")).strip()
    if len(original) > 1200:
        original = original[:1200]

    # --- Enlace de afiliado propio (solo Amazon) ---
    # Si la noticia trae un enlace de Amazon (amzn.to, a.co, amazon...), lo
    # resolvemos y lo rehacemos con TU etiqueta. El enlace se anade DESPUES
    # del texto, al final, para no gastar caracteres del cuerpo.
    enlace = None
    if amazon_tag and afiliados and mostrar_enlace:
        try:
            enlace = afiliados.mejor_enlace_afiliado(item, amazon_tag)
        except Exception:
            enlace = None

    # Reservamos sitio: el enlace + salto + etiqueta "Buy here" cuentan.
    cola_fijos = " ".join(HASHTAGS_FIJOS)
    reserva = len(cola_fijos) + 40
    extra_enlace = 0
    if enlace:
        # "🛒 " (2) + URL (23 en X) + salto (1) aprox.
        extra_enlace = post_length("🛒 " + enlace) + 1
    text = None
    verify = {}
    for attempt in range(2):
        try:
            text = xkiro_rewrite(original, hashtags_max - reserva - extra_enlace,
                                 xkey)
        except Exception as e:
            return {"error": f"xkiro: {e}", "post_en": None}
        text = strip_promo_tags(text)
        text = merge_hashtags(text, original)
        # recorta el CUERPO si se pasa, pero conserva los hashtags fijos:
        # quitamos los fijos, recortamos, y los volvemos a poner al final.
        cuerpo = text
        # OJO: hay que quitar los hashtags fijos como TOKEN completo y el mas
        # largo primero. Si no, al quitar "#OnePiece" de "#OnePieceCardGame"
        # quedaria "CardGame" suelto en el texto.
        for t in sorted(HASHTAGS_FIJOS, key=len, reverse=True):
            cuerpo = re.sub(re.escape(t) + r"(?![0-9A-Za-z_])", "", cuerpo,
                            flags=re.I)
        cuerpo = re.sub(r"#[ \t]+", "", cuerpo)     # '#' huerfano seguido de espacio
        cuerpo = re.sub(r"#\s*$", "", cuerpo).strip()
        cuerpo = re.sub(r"\s{2,}", " ", cuerpo).strip()
        limite_cuerpo = hashtags_max - extra_enlace
        while post_length(cuerpo + " " + cola_fijos) > limite_cuerpo and len(cuerpo) > 40:
            recortado = cuerpo[: int(len(cuerpo) * 0.92)].rsplit(" ", 1)[0]
            if recortado == cuerpo:  # sin espacios: cortamos en seco
                sobra = post_length(cuerpo + " " + cola_fijos) - limite_cuerpo
                recortado = cuerpo[: max(0, len(cuerpo) - sobra - 1)].rstrip()
            cuerpo = recortado
        # ultimo recurso: si aun se pasa, recorte exacto para no perder nunca los fijos
        if post_length(cuerpo + " " + cola_fijos) > limite_cuerpo:
            sobra = post_length(cuerpo + " " + cola_fijos) - limite_cuerpo
            cuerpo = cuerpo[: max(0, len(cuerpo) - sobra)].rstrip()
        # re-montamos: cuerpo + resto de hashtags originales + fijos al final
        resto = [t for t in re.findall(r"#\w+", text)
                 if t.lower() not in {f.lower() for f in HASHTAGS_FIJOS}]
        partes = [cuerpo] + resto + HASHTAGS_FIJOS
        text = " ".join(x for x in partes if x).strip()
        text = garantizar_fijos(text)
        if enlace:
            text = text + "\n\n🛒 " + enlace
        try:
            verify = jev_verify(original, text, tkey)
        except Exception as e:
            verify = {"error": str(e)}
        ok = (verify.get("significado", 0) >= 0.6 and
              verify.get("ingles", 0) >= 0.6 and
              verify.get("copia", 1) <= 0.5)
        if ok:
            break
    return {"post_en": text, "verify": verify,
            "length": post_length(text) if text else 0,
            "enlace_afiliado": enlace}


def main():
    if len(sys.argv) < 3:
        print("Uso: python pipeline/generate.py feed.json cola.json")
        sys.exit(1)
    xkey = env_or_dotenv("XKIRO_API_KEY")
    tkey = env_or_dotenv("TYPESAFE_API_KEY")
    if not xkey:
        print("ERROR: falta XKIRO_API_KEY (crea .env, ver CONFIGURAR_API_KEY.txt)")
        sys.exit(1)
    if not tkey:
        print("ERROR: falta TYPESAFE_API_KEY (crea .env, ver CONFIGURAR_API_KEY.txt)")
        sys.exit(1)

    feed = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    cola_path = Path(sys.argv[2])

    # --- etiqueta de afiliado de Amazon del perfil activo ---
    # Uso: generate.py feed.json cola.json [slug]
    # Se lee de perfiles/<slug>/perfil.json (campo "amazon_tag"). Si no hay
    # slug o no hay etiqueta, no se reemplaza ningun enlace.
    slug = sys.argv[3] if len(sys.argv) > 3 else ""
    amazon_tag = ""
    if slug:
        try:
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            import perfiles
            pf = perfiles.cargar(slug)
            if pf:
                amazon_tag = (pf.get("amazon_tag") or "").strip()
        except Exception as e:
            print(f"  (aviso: no pude leer la etiqueta de afiliado: {e})")
    if amazon_tag:
        print(f"  Enlaces de Amazon -> etiqueta propia: {amazon_tag}")
    else:
        print("  (sin etiqueta de afiliado: los enlaces se siguen quitando)")

    # conservar los posts ya generados/publicados de la cola anterior
    previos = {}
    if cola_path.exists():
        try:
            prev = json.loads(cola_path.read_text(encoding="utf-8"))
            for p in prev.get("posts", []):
                if p.get("post_en"):
                    previos[p["id"]] = p
        except Exception:
            pass

    # registro append-only de publicados: aunque la cola se corrompiera o un
    # corte dejara un post como 'listo', aqui consta que YA salio en X.
    registro = set()
    reg_path = cola_path.with_name("publicados.json")
    if reg_path.exists():
        try:
            for reg in json.loads(reg_path.read_text(encoding="utf-8")).get("publicados", []):
                if reg.get("id"):
                    registro.add(reg["id"])
        except Exception:
            pass
    for pid in registro:
        if pid in previos:
            previos[pid]["status"] = "publicado"
            previos[pid]["publish_msg"] = "publicado (segun registro)"

    marked = [i for i in feed["items"] if i.get("selected")]
    if not marked:
        print("No has marcado ninguna noticia en el dashboard.")
        sys.exit(0)

    # los ya publicados no se vuelven a generar (no se republican)
    ya_pub = {i for i, p in previos.items()
              if p.get("status") == "publicado" or i in registro}
    pendientes = [i for i in marked if i["id"] not in ya_pub]
    omitidos = len(marked) - len(pendientes)
    if omitidos:
        print(f"({omitidos} noticias ya publicadas se omiten)")

    print(f"Generando {len(pendientes)} posts en inglés...")
    out = list(previos.values()) if previos else []
    # quitar de out los que ya no estan marcados (excepto los publicados)
    marcados_ids = {i["id"] for i in pendientes}
    out = [p for p in out
           if p["id"] in marcados_ids or p.get("status") == "publicado"]

    for idx, it in enumerate(pendientes, 1):
        if it["id"] in previos:
            continue          # ya estaba generado, se reutiliza
        res = process(it, xkey, tkey, amazon_tag=amazon_tag)
        post = {
            "id": it["id"], "url": it.get("url"), "sub": it.get("sub"),
            "game": it.get("game"), "date": it.get("date"),
            "image": it.get("image"), "images": it.get("images", []),
            "videos": it.get("videos", []),
            "links": it.get("links", []),
            "enlace_afiliado": res.get("enlace_afiliado"),
            "original": (it.get("title_es") or it.get("title") or "")[:200],
            "post_en": res.get("post_en"),
            "length": res.get("length", 0),
            "verify": res.get("verify", {}),
            "status": "listo" if res.get("post_en") else "error",
        }
        flag = "OK" if post["status"] == "listo" else "ERROR"
        afil = " +enlace💰" if post.get("enlace_afiliado") else ""
        print(f"  [{idx}/{len(pendientes)}] {flag} ({post['length']} chars)"
              f"{afil} {(post['post_en'] or res.get('error') or '')[:60]}")
        out.append(post)
        time.sleep(0.4)

    # escritura atomica: si se corta la luz justo aqui, la cola anterior sigue intacta
    tmp = cola_path.with_suffix(".tmp")
    tmp.write_text(
        json.dumps({"generated": int(time.time() * 1000), "posts": out},
                   ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, cola_path)
    ok = sum(1 for p in out if p.get("post_en")
             and p.get("status") in ("listo", "publicado"))
    print(f"\n{ok}/{len(out)} posts listos -> {cola_path}")


if __name__ == "__main__":
    main()
