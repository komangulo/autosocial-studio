/* TCG News Radar — client app (multi-perfil)
   Muestra una pestaña por perfil. Cada perfil tiene su feed, sus fuentes,
   sus categorias y su cola de publicacion. Las API keys se comparten. */
(function () {
"use strict";
if (window.__TCG_TEARDOWN__) { try { window.__TCG_TEARDOWN__(); } catch (e) {} }

const JEV = "https://api.typesafe.ai/v1/systemone";

/* ---------- datos embebidos por build.py ---------- */
function datosEmbebidos() {
  if (globalThis.__PERFILES__ && globalThis.__PERFILES__.perfiles) {
    return globalThis.__PERFILES__;
  }
  // compatibilidad con el formato antiguo (un solo feed)
  if (globalThis.__FEED__) {
    return { activo: "onepiece", perfiles: [{
      slug: "onepiece", nombre: "One Piece TCG", publica: true, perfil_tipo: "tcg",
      categorias: {}, feed: globalThis.__FEED__,
    }] };
  }
  return { activo: null, perfiles: [] };
}

const DATA = datosEmbebidos();
let perfilIdx = 0;
if (DATA.activo) {
  const i = DATA.perfiles.findIndex((p) => p.slug === DATA.activo);
  if (i >= 0) perfilIdx = i;
}
function perfilActual() { return DATA.perfiles[perfilIdx] || { slug: "vacio", nombre: "Sin perfiles", categorias: {}, feed: { items: [] } }; }
function CATS_DE(p) {
  const src = p.categorias || {};
  const out = {};
  Object.keys(src).forEach((k) => { out[k] = { label: src[k], cls: claseCat(k) }; });
  if (!Object.keys(out).length) {
    out.other = { label: "Otro", cls: "b-gameplay" };
  }
  return out;
}
// clase visual segun el nombre de categoria (estable por hash sencillo)
const CLASES = ["b-newcard","b-tournament","b-market","b-rumor","b-art","b-gameplay"];
function claseCat(k) {
  let h = 0; for (let i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) >>> 0;
  if (k === "rumor" || k === "rumor_leak" || k === "viral") return "b-rumor";
  return CLASES[h % CLASES.length];
}

/* ---------- persistencia (por perfil) ---------- */
const DEFAULTS = { apiKey: "", minConf: 0 };
let cfg;
function load() {
  try { cfg = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem("tcg_cfg") || "{}")); }
  catch { cfg = { ...DEFAULTS }; }
}
function save() { localStorage.setItem("tcg_cfg", JSON.stringify(cfg)); }

/* ---------- estado ---------- */
let items = [];                 // noticias del perfil actual
let filter = { game: "all", src: "all", acct: "all", cat: "all", img: "all", q: "", rel: 0, sort: "rel" };
let running = false;

/* ---------- utilidades ---------- */
const $ = (id) => document.getElementById(id);
const esc = (s) => (s || "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const LANGS = { en: "inglés", ja: "japonés", ko: "coreano", ru: "ruso", zh: "chino", es: "español" };
const langName = (c) => LANGS[c] || c || "otro";
const ago = (d) => {
  if (!d) return "";
  const t = typeof d === "number" ? d : Date.parse(d);
  if (!t) return "";
  const s = (Date.now() - t) / 1000;
  if (s < 3600) return Math.max(1, Math.round(s / 60)) + "m";
  if (s < 86400) return Math.round(s / 3600) + "h";
  return Math.round(s / 86400) + "d";
};
function toast(msg, err) {
  const t = $("toast");
  t.textContent = msg; t.className = "toast on" + (err ? " err" : "");
  clearTimeout(t._h); t._h = setTimeout(() => (t.className = "toast"), 3200);
}

/* ---------- preguntas Jev por perfil ---------- */
function questions() {
  const p = perfilActual();
  const cats = {};
  const desc = p.categorias_desc || p.categorias || {};
  Object.entries(p.categorias || {}).forEach(([k, v]) => { cats[k] = desc[k] || v; });
  return {
    category: {
      type: "choice",
      instructions: "¿De qué trata principalmente esta noticia? Clasifícala en una de estas categorías.",
      criteria: cats,
    },
    relevance: {
      type: "score",
      instructions: p.relevance_pregunta || "¿Qué relevancia tiene esto para el tema de este perfil?",
      criteria: ["Baja - trivial o fuera de tema","Notable - vale la pena saberlo","Importante - afecta o interesa de verdad","Mayor - gran noticia, actuar"],
    },
    is_confirmed: {
      type: "noul",
      instructions: "¿Es información oficial o confirmada, en lugar de un rumor o especulación?",
      criteria: { true: "Fuente oficial o confirmada", false: "Rumor, especulación o sin confirmar" },
    },
  };
}

/* ---------- análisis con Jev (para noticias sin analizar) ---------- */
async function analyze(item) {
  const state = { titulo: item.title, texto: item.text, fuente: item.sub, plataforma: item.source, juego: item.game };
  const r = await fetch(JEV, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.apiKey },
    body: JSON.stringify({ state, model: "jev-latest", questions: questions() }),
  });
  if (!r.ok) throw new Error("Jev " + r.status);
  const j = await r.json(); const a = j.answers || {};
  const rel = a.relevance ? a.relevance.score : 0;
  const conf = Math.min(a.category?.confidence ?? 1, a.relevance?.confidence ?? 1);
  return {
    category: a.category?.choice || "other",
    probabilities: a.category?.probabilities || {},
    relevance: rel,
    isConfirmed: a.is_confirmed ? a.is_confirmed.noul : 0.5,
    confidence: conf,
  };
}

async function run() {
  if (running) return;
  if (!cfg.apiKey) { openSettings(); toast("Falta la API key de TypeSafe", true); return; }
  const queue = items.filter((it) => !it.analyzed);
  if (!queue.length) { toast("Todo este perfil ya esta analizado"); return; }
  running = true; $("btnRun").disabled = true; $("loadbar").className = "loadbar on";
  let done = 0, failed = 0; const total = queue.length;
  const workers = Array.from({ length: 5 }, async () => {
    while (queue.length) {
      const it = queue.shift();
      try { Object.assign(it, await analyze(it), { analyzed: true }); }
      catch (e) { it.analyzed = true; it.error = true; failed++; }
      done++;
      const pct = Math.round((done / total) * 100);
      $("loadbar").innerHTML = `<i style="width:${pct}%;background:var(--acc);animation:none"></i>`;
      render();
    }
  });
  await Promise.all(workers);
  $("loadbar").className = "loadbar"; $("loadbar").innerHTML = "<i></i>";
  running = false; $("btnRun").disabled = false; render();
  toast(`${done - failed}/${done} analizadas${failed ? ` · ${failed} fallos` : ""}`);
}

/* ---------- filtros y render ---------- */
function visible() {
  let v = items.slice();
  const p = perfilActual();
  const esTCG = p.perfil_tipo === "tcg";
  if (esTCG && filter.game !== "all") v = v.filter((i) => i.game === filter.game);
  if (filter.src !== "all") v = v.filter((i) => i.source === filter.src);
  if (filter.acct && filter.acct !== "all") v = v.filter((i) => i.sub === filter.acct);
  if (filter.cat !== "all") v = v.filter((i) => i.analyzed && i.category === filter.cat);
  if (filter.img === "yes") v = v.filter((i) => !!i.image);
  if (filter.img === "no") v = v.filter((i) => !i.image);
  if (filter.rel > 0) v = v.filter((i) => (i.relevance || 0) >= filter.rel);
  if (cfg.minConf > 0) v = v.filter((i) => (i.confidence ?? 1) >= cfg.minConf);
  if (filter.q) { const q = filter.q.toLowerCase(); v = v.filter((i) => ((i.title_es||i.title||"") + " " + (i.text_es||i.text||"")).toLowerCase().includes(q)); }
  const fecha = (i) => { const t = typeof i.date === "number" ? i.date : Date.parse(i.date); return t || 0; };
  if (filter.sort === "rel") v.sort((a, b) => (b.relevance || 0) - (a.relevance || 0) || fecha(b) - fecha(a));
  else if (filter.sort === "date") v.sort((a, b) => fecha(b) - fecha(a));
  else v.sort((a, b) => (b.confidence || 0) - (a.confidence || 0));
  return v;
}

function renderStats() {
  const done = items.filter((i) => i.analyzed && !i.error);
  const hot = done.filter((i) => (i.relevance || 0) >= 2).length;
  const rumors = done.filter(isRumor).length;
  const avg = done.length ? (done.reduce((s, i) => s + (i.relevance || 0), 0) / done.length).toFixed(2) : "—";
  const cards = [
    ["Noticias", items.length, ""],
    ["Analizadas", done.length, ""],
    ["Destacadas (rel ≥ 2)", hot, "hot"],
    ["Posibles rumores", rumors, ""],
    ["Relevancia media", avg, ""],
  ];
  $("stats").innerHTML = cards.map(([l, n, c]) => `<div class="stat ${c}"><div class="n">${n}</div><div class="l">${l}</div></div>`).join("");
}

function renderChips() {
  const p = perfilActual();
  const CATS = CATS_DE(p);
  const esTCG = p.perfil_tipo === "tcg";
  const gameBox = $("gameChips");
  if (esTCG) {
    const gc = [["all", "Todos los juegos"], ["onepiece", "One Piece"], ["pokemon", "Pokémon"]];
    gameBox.style.display = "";
    gameBox.innerHTML = gc.map(([v, l]) => `<div class="chip ${filter.game === v ? "on" : ""}" data-game="${v}">${l}</div>`).join("");
    gameBox.querySelectorAll("[data-game]").forEach((c) => c.onclick = () => { filter.game = c.dataset.game; renderChips(); render(); });
  } else {
    gameBox.style.display = "none"; gameBox.innerHTML = "";
  }
  const sc = [["all", "Todo"], ["reddit", "Reddit"], ["x", "X"]];
  $("srcChips").innerHTML = sc.map(([v, l]) => `<div class="chip ${filter.src === v ? "on" : ""}" data-src="${v}">${l}</div>`).join("");
  const ic = [["all", "Con y sin"], ["yes", "🖼 Con imagen"], ["no", "Solo texto"]];
  $("imgChips").innerHTML = ic.map(([v, l]) => `<div class="chip ${filter.img === v ? "on" : ""}" data-img="${v}">${l}</div>`).join("");
  $("imgChips").querySelectorAll("[data-img]").forEach((c) => c.onclick = () => { filter.img = c.dataset.img; renderChips(); render(); });
  const cc = [["all", "Todas"]].concat(Object.entries(CATS).map(([k, v]) => [k, v.label]));
  $("catChips").innerHTML = cc.map(([v, l]) => `<div class="chip ${filter.cat === v ? "on" : ""}" data-cat="${v}">${l}</div>`).join("");
  $("srcChips").querySelectorAll("[data-src]").forEach((c) => c.onclick = () => { filter.src = c.dataset.src; renderChips(); render(); });
  $("catChips").querySelectorAll("[data-cat]").forEach((c) => c.onclick = () => { filter.cat = c.dataset.cat; renderChips(); render(); });
}

function isRumor(i) {
  return i.category === "rumor_leak" && (i.isConfirmed ?? 1) < 0.5;
}
const RUMOR_WORD = /rumor|leak|filtra|speculat|especula|unconfirmed|sin confirmar|maybe|podr[ií]a|not sure|possibly|allegedly/i;

function relBadge(r) {
  const n = Math.round(r || 0);
  const dots = [0, 1, 2, 3].map((i) => `<span class="dot ${i < n ? "on" : ""}"></span>`).join("");
  const pct = Math.round(((r || 0) / 3) * 100);
  return `<div class="rel" title="Relevancia para el tema de este perfil (0-100%)"><span class="dots">${dots}</span> ${pct}%</div>`;
}

function selectedCount() { return items.filter((i) => i.selected).length; }
function selKey() { return "tcg_selected_" + perfilActual().slug; }
function restoreSelection() {
  try {
    const ids = new Set(JSON.parse(localStorage.getItem(selKey()) || "[]"));
    items.forEach((i) => (i.selected = ids.has(i.id)));
  } catch (e) {}
}
function saveSelection() {
  const ids = items.filter((i) => i.selected).map((i) => i.id);
  try { localStorage.setItem(selKey(), JSON.stringify(ids)); } catch (e) {}
  const pill = $("selCount");
  if (pill) pill.textContent = ids.length;
}

function renderQueue() {
  const sel = items.filter((i) => i.selected);
  const n = sel.length;
  const pill = $("selCount");
  if (pill) pill.textContent = n;
  $("queueEmpty").style.display = n === 0 ? "block" : "none";
  $("queueList").innerHTML = sel.map((i) => {
    const cat = i.analyzed ? (CATS_DE(perfilActual())[i.category] || { label: "Otro", cls: "b-gameplay" }) : { label: "Sin clasificar", cls: "b-other" };
    const img = i.image ? `<img src="${esc(i.image)}" referrerpolicy="no-referrer" onerror="this.style.display='none'">` : "";
    return `<div class="qitem">
      <div class="qthumb">${img}</div>
      <div class="qbody">
        <div class="qtitle">${esc(i.title_es || i.title)}</div>
        <div class="qmeta">
          <span class="badge ${cat.cls}">${cat.label}</span>
          <span class="badge b-${i.source === "reddit" ? "rd" : "x"}">${i.source === "reddit" ? "Reddit" : "X"}</span>
          <span style="color:var(--dim)">${esc(i.sub)}</span>
          <span style="color:var(--dim);margin-left:auto">${langName(i.lang || "es")} → EN</span>
        </div>
        <div class="qen">Texto en inglés: se generará al pulsar <b>Generar posts</b></div>
      </div>
      <button class="iconbtn qrm" data-pick="${esc(i.id)}" title="Quitar">✕</button>
    </div>`;
  }).join("");
}

function renderAccounts() {
  const sel = $("acct");
  const accounts = [...new Set(items.map((i) => i.sub))].sort();
  const cur = filter.acct || "all";
  sel.innerHTML = `<option value="all">Todas las fuentes</option>` +
    accounts.map((a) => `<option value="${esc(a)}" ${cur === a ? "selected" : ""}>${esc(a)}</option>`).join("");
}

function render() {
  renderStats(); renderChips(); renderAccounts();
  const p = perfilActual();
  const CATS = CATS_DE(p);
  const v = visible();
  $("empty").style.display = v.length === 0 ? "block" : "none";
  $("grid").innerHTML = v.map((i) => {
    const c = i.analyzed ? (CATS[i.category] || { label: "Otro", cls: "b-gameplay" }) : { label: "Sin clasificar", cls: "b-other" };
    const conf = Math.round((i.confidence ?? 0) * 100);
    const rumor = isRumor(i) || (RUMOR_WORD.test(i.title || "") && (i.isConfirmed ?? 1) < 0.5);
    const pend = !i.analyzed ? `<span class="spin"></span> analizando…` : "";
    const thumb = i.image
      ? `<a class="thumb" href="${esc(i.url)}" target="_blank" rel="noopener"><img src="${esc(i.image)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.closest('.thumb').style.display='none'"></a>`
      : "";
    const hasOriginal = i.lang && i.lang !== "es" && (i.title_es || i.text_es);
    const titleEs = i.title_es || i.title;
    const textEs = i.text_es || i.text;
    const sel = i.selected ? " on" : "";
    const gameBadge = p.perfil_tipo === "tcg"
      ? `<span class="badge b-${i.game === "pokemon" ? "pk" : "op"}">${i.game === "pokemon" ? "Pokémon" : "One Piece"}</span>` : "";
    const srcBadge = i.source === "reddit" ? "Reddit" : (i.feed ? "Para ti" : "X");
    const pickLabel = p.publica ? `<span class="box">${i.selected ? "✓" : ""}</span><span class="lbl">Republicar</span>` : "";
    return `<div class="card ${i.analyzed ? "" : "pending"} ${i.selected ? "selected" : ""}">
      <div class="top">
        <div class="badges">
          ${gameBadge}
          <span class="badge b-${i.source === "reddit" ? "rd" : "x"}">${srcBadge}</span>
          ${i.analyzed ? `<span class="badge ${c.cls}">${c.label}</span>` : ""}
          ${hasOriginal ? `<span class="badge lang" title="Traducido del ${langName(i.lang)}">${(i.lang || "").toUpperCase()}→ES</span>` : ""}
        </div>
        ${p.publica ? `<button class="pick${sel}" data-pick="${esc(i.id)}" title="Marcar para republicar en X">${pickLabel}</button>` : ""}
      </div>
      ${thumb}
      <h3><a href="${esc(i.url)}" target="_blank" rel="noopener">${esc(titleEs)}</a></h3>
      <div class="excerpt">${esc(textEs)}</div>
      ${hasOriginal ? `<div class="orig" data-orig hidden><b>Original (${esc(langName(i.lang))}):</b><br>${esc(i.title)}<br>${esc(i.text)}</div>
      <button class="linkbtn" data-toggle data-lang="${esc(langName(i.lang))}">Ver original en ${esc(langName(i.lang))}</button>` : ""}
      <div class="meta">
        ${i.analyzed ? relBadge(i.relevance) : pend}
        ${i.analyzed && rumor ? `<span class="badge b-rumor" style="font-size:9.5px">¿rumor?</span>` : ""}
        ${i.analyzed ? `<div class="conf" title="Confianza de la IA en su clasificación (no es la relevancia)"><span class="mini"><i style="width:${conf}%"></i></span> ${conf}% IA</div>` : ""}
      </div>
      <div class="meta" style="border:0;padding-top:2px;margin-top:0">
        <span>${esc(i.sub)}</span><span>·</span><span>${ago(i.date)}</span>
      </div>
    </div>`;
  }).join("");
}

/* ---------- pestañas de perfil ---------- */
function renderPerfilTabs() {
  const tabs = $("perfilTabs");
  if (!tabs) return;
  tabs.innerHTML = DATA.perfiles.map((p, i) => {
    const n = (p.feed && p.feed.items ? p.feed.items.length : 0);
    return `<button class="ptab ${i === perfilIdx ? "on" : ""}" data-p="${i}">
      ${esc(p.nombre)} <span class="pcount">${n}</span></button>`;
  }).join("") + `<button class="ptab pnew" id="btnNewPerfil">+ Nuevo perfil</button>`;
  tabs.querySelectorAll("[data-p]").forEach((b) => b.onclick = () => {
    perfilIdx = +b.dataset.p;
    cargarPerfil();
  });
  const nb = $("btnNewPerfil");
  if (nb) nb.onclick = openNewPerfil;
}

function cargarPerfil() {
  const p = perfilActual();
  items = (p.feed && p.feed.items ? p.feed.items : []).map((it) => ({ ...it }));
  filter = { game: "all", src: "all", acct: "all", cat: "all", img: "all", q: "", rel: 0, sort: "rel" };
  const q = $("search"); if (q) q.value = "";
  restoreSelection();
  renderPerfilTabs();
  const esTCG = p.perfil_tipo === "tcg";
  const tq = $("tabQueue"); if (tq) tq.style.display = p.publica ? "" : "none";
  const bn = $("btnRun");
  if (bn) { bn.textContent = p.publica ? "▶ Analizar ahora" : "▶ Analizar ahora"; }
  const title = $("perfilNombre");
  if (title) title.textContent = p.nombre;
  render();
  showTab("news");
  if (!items.length) {
    $("empty").innerHTML = `<b>Este perfil todavía no tiene noticias.</b><br>
      Ejecuta <b>ESCANEAR.bat</b> para recogerlas de sus fuentes.`;
  } else {
    $("empty").innerHTML = `<b>No hay noticias con estos filtros.</b>`;
  }
}

/* ---------- crear perfil ---------- */
function openNewPerfil() {
  $("npName").value = "";
  $("npSubs").value = "";
  $("npX").value = "";
  $("npCats").value = "";
  $("npParati").checked = false;
  $("npTipo").value = "general";
  $("npPublica").checked = false;
  $("ovNew").classList.add("on");
  setTimeout(() => $("npName").focus(), 50);
}

function crearPerfil() {
  const nombre = $("npName").value.trim();
  if (!nombre) { toast("Ponle un nombre al perfil", true); return; }
  const subs = $("npSubs").value.split(",").map((s) => s.trim().replace(/^r\//, "")).filter(Boolean);
  const x = $("npX").value.split(",").map((s) => s.trim().replace(/^@/, "")).filter(Boolean);
  const catsRaw = $("npCats").value.split(",").map((s) => s.trim()).filter(Boolean);
  const tipo = $("npTipo").value;
  const publica = $("npPublica").checked;
  const parati = $("npParati").checked;
  if (!subs.length && !x.length && !parati) {
    toast("Añade al menos una fuente (subreddit, cuenta X o 'Para ti')", true);
    return;
  }
  // se entrega un archivo que el usuario guarda; el escáner lo detecta.
  const perfil = {
    nombre, subs, x, feed_para_ti: parati, tipo, publica,
    categorias: catsRaw,
    _accion: "crear_perfil",
  };
  const blob = new Blob([JSON.stringify(perfil, null, 1)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "nuevo_perfil.json";
  document.body.appendChild(a); a.click(); a.remove();
  $("ovNew").classList.remove("on");
  toast("Perfil descargado. Ejecuta CREAR_PERFIL.bat para activarlo");
}

/* ---------- ajustes ---------- */
function openSettings() {
  $("apiKey").value = cfg.apiKey || "";
  $("minConf").value = cfg.minConf;
  // fuentes del perfil actual: precargadas y editables
  const p = perfilActual();
  $("cfgPerfilTitulo").textContent = "Fuentes de « " + (p.nombre || p.slug) + " »";
  $("setSubs").value = (p.subs || []).join(", ");
  $("setX").value = (p.x || []).join(", ");
  $("setParati").checked = !!p.feed_para_ti;
  $("setAmazonTag").value = p.amazon_tag || "";
  $("ov").classList.add("on");
}
function updateKeyStatus() {
  const el = $("keyStatus");
  if (cfg.apiKey) { el.className = "badge b-newcard"; el.textContent = "API key ✓"; }
  else { el.className = "badge b-rumor"; el.textContent = "sin API key"; }
}

/* guarda las fuentes del perfil actual: descarga un JSON que aplica
   GUARDAR_AJUSTES.bat (asi el dashboard no necesita escribir en disco). */
function guardarFuentesPerfil() {
  const p = perfilActual();
  if (!p || !p.slug) { toast("No hay perfil activo", true); return; }
  const subs = $("setSubs").value.split(",").map((s) => s.trim().replace(/^r\//, "")).filter(Boolean);
  const x = $("setX").value.split(",").map((s) => s.trim().replace(/^@/, "")).filter(Boolean);
  const parati = $("setParati").checked;
  const amazonTag = $("setAmazonTag").value.trim();
  if (!subs.length && !x.length && !parati) {
    toast("Añade al menos una fuente (subreddit, cuenta X o 'Para ti')", true);
    return;
  }
  const data = {
    _accion: "guardar_fuentes",
    perfil: p.slug,
    subs, x, feed_para_ti: parati,
    amazon_tag: amazonTag,
  };
  const blob = new Blob([JSON.stringify(data, null, 1)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "ajustes_perfil.json";
  document.body.appendChild(a); a.click(); a.remove();
  toast("Fuentes descargadas. Ejecuta GUARDAR_AJUSTES.bat para aplicarlas");
}

/* ---------- eventos ---------- */
$("btnRun").onclick = () => run();
$("btnSettings").onclick = openSettings;
$("saveSettings").onclick = () => {
  cfg.apiKey = $("apiKey").value.trim();
  cfg.minConf = parseFloat($("minConf").value) || 0;
  save(); updateKeyStatus(); $("ov").classList.remove("on"); render();
  toast("Ajustes guardados");
};
$("ov").onclick = (e) => { if (e.target === $("ov")) $("ov").classList.remove("on"); };
$("saveFuentes").onclick = guardarFuentesPerfil;
$("ovNew").onclick = (e) => { if (e.target === $("ovNew")) $("ovNew").classList.remove("on"); };
$("createPerfil").onclick = crearPerfil;
$("search").oninput = (e) => { filter.q = e.target.value; render(); };
$("rel").oninput = (e) => { filter.rel = +e.target.value; $("relVal").textContent = Math.round((+e.target.value / 3) * 100) + "%"; render(); };
$("sort").onchange = (e) => { filter.sort = e.target.value; render(); };
$("acct").onchange = (e) => { filter.acct = e.target.value; render(); };
$("grid").addEventListener("click", (e) => {
  const pick = e.target.closest("[data-pick]");
  if (pick) {
    const id = pick.dataset.pick;
    const it = items.find((x) => x.id === id);
    if (it) { it.selected = !it.selected; saveSelection(); render(); renderQueue(); }
    return;
  }
  const b = e.target.closest("[data-toggle]");
  if (!b) return;
  const card = b.closest(".card");
  const orig = card && card.querySelector(".orig");
  if (!orig) return;
  orig.hidden = !orig.hidden;
  b.textContent = orig.hidden ? `Ver original en ${b.dataset.lang || "idioma original"}` : "Ocultar original";
});

/* ---------- pestañas de vista ---------- */
function showTab(which) {
  const news = which === "news";
  $("tabNews").classList.toggle("on", news);
  $("tabQueue").classList.toggle("on", !news);
  const newsBar = document.getElementById("newsBar");
  if (newsBar) newsBar.style.display = news ? "" : "none";
  $("stats").style.display = news ? "" : "none";
  $("loadbar").style.display = news ? "" : "none";
  $("grid").style.display = news ? "" : "none";
  $("empty").style.display = (news && visible().length === 0) ? "block" : "none";
  $("viewQueue").style.display = news ? "none" : "";
  if (!news) renderQueue();
}
$("tabNews").onclick = () => showTab("news");
$("tabQueue").onclick = () => showTab("queue");
$("btnClearSel").onclick = () => {
  items.forEach((i) => (i.selected = false));
  saveSelection(); render(); renderQueue();
};
$("btnMakePosts").onclick = () => {
  const n = selectedCount();
  if (!n) { toast("No has marcado ninguna noticia", true); return; }
  downloadCola(n);
};
function downloadCola(n) {
  const sel = items.filter((i) => i.selected).map((i) => ({
    id: i.id, source: i.source, sub: i.sub, game: i.game, date: i.date,
    title: i.title, title_es: i.title_es, text: i.text, text_es: i.text_es,
    lang: i.lang, image: i.image, images: i.images || [], videos: i.videos || [],
    url: i.url, category: i.category, relevance: i.relevance, selected: true,
  }));
  const blob = new Blob([JSON.stringify({ items: sel }, null, 1)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "seleccion.json";
  document.body.appendChild(a); a.click(); a.remove();
  toast(`Descargadas ${n} noticias. Ahora ejecuta PUBLICAR.bat`);
}

/* ---------- init ---------- */
load(); updateKeyStatus();
if (DATA.perfiles.length) {
  cargarPerfil();
} else {
  renderPerfilTabs();
  $("empty").innerHTML = "<b>No hay perfiles todavía.</b><br>Pulsa <b>+ Nuevo perfil</b> para crear el primero.";
}

window.__TCG_TEARDOWN__ = () => {
  const g = document.getElementById("grid");
  if (g) g.innerHTML = "";
  running = false;
  const b = document.getElementById("btnRun");
  if (b) b.disabled = false;
};

})();
