# Boton "Eliminar cuenta" en el panel de cuentas

## Que hace
Anade un boton rojo "Eliminar" a cada cuenta de la tabla de cuentas gestionadas
(la de mas abajo, en "Cuentas", junto a "Select" y "Open signup").

Ejemplo: puedes borrar "Erick - TechWired".

Al pulsarlo, pide confirmacion y borra:
  - la cuenta del listado,
  - su cola de videos (queue/<id>),
  - sus perfiles de navegador, es decir sus sesiones (.profiles/<id>).

La cuenta "Default" NO se puede borrar (su boton sale desactivado).

## Como usarlo (Windows / Git Bash)
1. Cierra el dashboard (Ctrl+C).
2. En la carpeta del proyecto:
   C:\Users\msi\Downloads\autosocial-studio
3. Copia `anadir-boton-eliminar-cuenta.js` a esa carpeta.
4. Ejecuta:
   node anadir-boton-eliminar-cuenta.js
5. Arranca:
   npm run dashboard
6. En el navegador, recarga con Ctrl+F5 (para que cargue el nuevo app.js).

## Deshacer
   node anadir-boton-eliminar-cuenta.js --revert

## Notas
- Idempotente: si lo ejecutas dos veces, no pasa nada.
- Hace copia .bak de los dos archivos antes de tocarlos.
- Solo anade ese boton; no cambia nada mas de la interfaz.

## Aviso importante
Eliminar la cuenta borra TAMBIEN su sesion de TikTok guardada. Si algun dia
quieres volver a usar ese perfil, tendras que iniciar sesion otra vez.
