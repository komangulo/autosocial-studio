# AutoSocial Studio — Configuración global de IA + X Autopilot

Este paquete hace dos cosas:

1. **Configuración de IA global**: guardas tus claves **una sola vez** y **toda la app**
   las usa en este orden automático:

   ```
   xKiro (gratis)  →  Gemini gratis  →  DeepSeek (pago)  →  Gemini de pago  →  OpenRouter
   ```

2. **X Autopilot arreglado + publicación automática en X** con login por usuario o cookies.

Si un proveedor falla o se agota su cuota, la app **pasa sola al siguiente**. No hay que
tocar nada.

---

## 1. Configuración de IA (nuevo)

Aparece una pestaña nueva en el menú lateral: **Configuración IA**.

- Una caja por proveedor con su campo de clave y su desplegable de modelos.
- Los **gratuitos van primero** y llevan la etiqueta `gratis`.
- Botón **Probar** para verificar una clave con una llamada real (muestra el modelo y los ms).
- Interruptor **Usar la cadena automática en toda la app**.

### Los modelos de xKiro (gratis) ya vienen cargados

Tomados de tu propia API de xKiro, en este orden:

| # | Modelo | Nota |
|---|---|---|
| 1 | `minimax/minimax-m3:free` | el que más aguanta |
| 2 | `qwen/qwen3.7-flash:free` | respaldo sólido |
| 3 | `mistralai/ministral-14b` | el más rápido |
| 4 | `mistralai/mistral-small-2603` | con visión |

xKiro usa `https://api.xkiro.com/v1` (compatible OpenAI) y su clave empieza por `sk-xt-`.

### Dónde se guardan las claves

En `settings.json`, en la raíz del proyecto. **Nunca se devuelven al navegador**: la
interfaz solo muestra la versión enmascarada (`sk-xt-9******224c`).

### Quién más usa esta configuración

- **X Autopilot** — genera con la cadena automática.
- **AutoClone** — si la config global tiene claves, las usa automáticamente (Gemini gratis
  y de pago, DeepSeek, OpenRouter).
- **Competencia / Modelado** — sigue usando su propia caja de Gemini para el análisis.

---

## 2. X Autopilot

### Arreglado

| # | Problema | Estado |
|---|---|---|
| 1 | El worker del cron **nunca arrancaba** (la casilla de generación diaria no hacía nada) | Arreglado |
| 2 | **Zona horaria rota**: `09:00` se guardaba como `09:00 UTC` (publicaba a las 11:00 en España) | Arreglado con `luxon` y `Europe/Madrid` |
| 3 | Sin API key generaba **texto de relleno** y lo encolaba como post real | Arreglado: bloquea y avisa |
| 4 | Sin timeout ni reintentos; un 429/500 abortaba el lote | Timeout 45s + reintentos |
| 5 | La cola **se duplicaba** al pulsar dos veces "Generar ahora" | Arreglado |
| 6 | Sin reintento de fallidos; pendientes antiguos se publicaban en cadena | Botón **Reintentar fallidos**; expiran a los 3 días |
| 7 | Límite de caracteres (280/4000) no se validaba | Arreglado |
| 8 | `x-autopilot-state.json` con claves no estaba en `.gitignore` | Añadido |
| 9 | Una sola IA sin respaldo | **Cadena global con respaldo automático** |

### Añadido

- **Login de X por navegador**: *Iniciar sesión* abre Chromium con un perfil propio
  (`.profiles/<cuenta>/x`); entras una vez, pulsas *Guardar sesión* y listo.
- **Login de X por cookies**: pega `auth_token=...; ct0=...` (o el JSON exportado) y pulsa
  *Importar cookies*. Se guardan con permisos `0600`.
- **Publicación real**: los posts de la cola se escriben y envían solos desde el compositor
  de X.

### Arreglos de login (2ª ronda)

| # | Problema | Estado |
|---|---|---|
| 10 | El estado de sesión leía el estado del **worker**, no el de la sesión de X (badge en «Comprobando…») | Arreglado: la ruta devuelve la sesión real |
| 11 | *Iniciar sesión* **bloqueaba** esperando a que X cargara del todo; parecía muerto | Arreglado: la ventana abre y responde al instante; X carga detrás |
| 12 | Perfil con candado de un Chromium cerrado a la fuerza («otra sesión», cuelgue) | Arreglado: se limpia el candado solo; si hay otra ventana viva, avisa claro |
| 13 | Si faltaba el navegador, el error quedaba oculto | Arreglado: mensaje explícito y registro en la consola del servidor |

---

## 3. Análisis de cuenta (nuevo)

Pestaña nueva en el menú: **Análisis de cuenta**. Metes cualquier `@` de X y la herramienta
estudia cómo se comunica esa cuenta (temas, tono, sentimiento, ganchos, CTAs, ritmo y formato)
y genera un **Manual de ADN** que usa la IA como molde para escribir.

- **La sesión de X se gestiona aquí mismo**, sin cambiar de pestaña: arriba verás el estado
  (*Sesión guardada* o *Sin sesión*) y los botones **Iniciar sesión**, **Guardar sesión** y
  **Cerrar**. Es la misma sesión que usa X Autopilot para publicar.
- **Mientras no haya sesión, Analizar queda bloqueado** y sale un aviso claro; X solo devuelve
  10-14 publicaciones sin sesión.
- **Cantidad**: 50 / 100 / 150 / 200 / 300 publicaciones (por defecto 150).
- **Progreso visible**: verás la fase y el contador (*Recogiendo publicaciones — 63 de 150*).
- **Usar esta cuenta como referencia** aplica ese estilo a la publicación diaria de X Autopilot.

---

## Instalación (Windows)

1. Copia el contenido del zip (con `instalar-x-autopilot-fix.js` y la carpeta `assets`)
   dentro de la raíz del proyecto, junto a `package.json`.
2. Ejecuta:

   ```bat
   node instalar-x-autopilot-fix.js
   ```

3. Reinicia el dashboard:

   ```bat
   node src/dashboard-server.js
   ```

4. Abre **Configuración IA**, pega tu clave de xKiro (`sk-xt-...`) y pulsa **Guardar**.
   Pulsa **Probar** para confirmar. Opcionalmente añade Gemini, DeepSeek y OpenRouter.

El instalador es **idempotente**: puedes repetirlo sin romper nada. Guarda copias de los
archivos que toca como `*.xap-backup`.

> **Si ya ejecutaste una versión anterior** y todo salía `[SKIP]`, esta versión **sí actualiza**
> el bloque de *Análisis de cuenta*: verás `[OK] bloque antiguo retirado para actualizarlo`.
> Si sigue todo en `[SKIP]`, es que ya tienes la versión buena.
>
> **Arreglos de login (2ª ronda):** si tenías el login atascado, esta ejecución mostrará
> `[OK] src/x-auth.js actualizado`, `[OK] src/account-analyzer.js actualizado` y
> `[OK] ... ruta de sesion corregida`. Reinicia el dashboard después.

## Cómo dejarlo publicando solo

1. **Configuración IA** → guarda al menos la clave de xKiro (gratis) y pulsa Probar.
2. **X Autopilot** → **Sesión de X** → *Iniciar sesión* → entra en X → *Guardar sesión*.
   (O pega tus cookies y pulsa *Importar cookies*.)
   La misma sesión te sirve para **Análisis de cuenta**, que tiene sus propios botones de sesión.
3. **Modo de publicación**: **API oficial de X**. En esta versión el modo `live` publica
   usando la sesión de X guardada, sin necesidad de tokens de API.
4. Rellena **Usuario X**, **Posts diarios** y **Horarios** (tu hora local).
5. Marca **Activar generación diaria autónoma** y pulsa **Guardar**.

## Seguridad

- Las claves y cookies nunca se devuelven al navegador.
- Las cookies se guardan en formato Netscape con permisos `0600`.
- **Si pegaste claves en un chat, revócalas y genera nuevas.** Guárdalas solo en la app.
