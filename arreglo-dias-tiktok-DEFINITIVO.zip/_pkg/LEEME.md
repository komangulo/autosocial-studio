# Arreglo DEFINITIVO del calendario de TikTok

## Orden de instalacion (Git Bash, dashboard CERRADO)
1. Copia los dos scripts a la carpeta del proyecto:
   C:\Users\msi\Downloads\autosocial-studio

2. Ejecuta PRIMERO el calendario:
   node arreglar-dias-tiktok-3.js

3. Ejecuta DESPUES el de la espera + refuerzo:
   node arreglar-dias-tiktok-2.js

4. Arranca:
   npm run dashboard

## Que arregla cada uno

### arreglar-dias-tiktok-3.js  (EL IMPORTANTE)
El calendario de TikTok cambia de mes con DOS FLECHAS que son <span class="arrow">
(no son botones). El codigo anterior no las reconocia -> nunca cambiaba de mes
y la fecha se quedaba clavada en hoy (29).

Ademas, los numeros de dia se repiten entre meses (un "30" de agosto y otro de
septiembre). Ahora se elige el del MES ACTUAL, que es el que lleva la clase
"valid" / "selected".

Con esto, si marcas Mie/Jue/Vie -> programa el 30, el 1 y el 2 correctamente.

### arreglar-dias-tiktok-2.js
a) Baja la espera del escaneo del video a 10 SEGUNDOS (antes hasta 10 minutos).
   Ya no se queda pillado en "Checking in progress...".
   (Nota: si antes aplicaste el v1, el v3 lo sustituye; el v2 solo anade la espera.)

## Deshacer
   node arreglar-dias-tiktok-2.js --revert
   node arreglar-dias-tiktok-3.js --revert

## Seguridad
- Idempotentes. Hacen copia .bak antes de tocar nada. NO tocan la interfaz.
