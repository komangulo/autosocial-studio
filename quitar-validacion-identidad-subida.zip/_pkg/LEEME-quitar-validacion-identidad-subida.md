# Quitar la validacion que rompia la subida/programacion en TikTok

## Que arregla
Los dias y la fecha que configuras en el dashboard ya no se aplicaban en TikTok
(el video se publicaba "ahora" en vez de programarse). Tambien puede fallar/vaciarse
la subida.

## Por que pasaba
Un parche de identidad anterior insertaba, ANTES de subir el video, una comprobacion
que abria la pagina principal de TikTok (navegaba FUERA del editor de subida).
Eso dejaba el flujo en la pagina equivocada, asi que la fecha/dias no se aplicaban.

Este script ELIMINA solo esa comprobacion del flujo de subida. NO toca la interfaz
(por eso el dashboard sigue bien) ni las funciones de detectar/resetear sesion.

## Como usarlo (Windows / Git Bash)
1. Cierra el dashboard (Ctrl+C).
2. Abre Git Bash en la carpeta del proyecto:
   C:\\Users\\msi\\Downloads\\autosocial-studio
3. Copia `quitar-validacion-identidad-subida.js` a esa carpeta.
4. Ejecuta:
   node quitar-validacion-identidad-subida.js
5. Vuelve a iniciar:
   npm run dashboard

Debe decir: "quitada la validacion previa de la subida".

## Deshacer
   node quitar-validacion-identidad-subida.js --revert

## Seguridad
- Idempotente: si lo ejecutas dos veces, no pasa nada.
- Hace copia de seguridad .bak antes de tocar nada.
