CORRECCION DE LA RUTA DE yt-dlp

Este ZIP es un paquete de reemplazo para AutoSocial Studio. No es el proyecto
completo: contiene los archivos corregidos que debes copiar sobre tu proyecto.

CAMBIO REALIZADO

La aplicacion ya no depende de la carpeta desde la que se inicia Node. Si
YTDLP_PATH en .env es relativo, se interpreta desde la raiz del proyecto.
Ademas, autodownload/watcher.js usa el mismo resolvedor de rutas.
Los errores reales de descarga se guardan en error-ytdlp.txt y se muestran en
el estado del trabajo. Los videos fallidos ya no se marcan como descargados.
Tambien se importa correctamente infoJsonPathFor, que faltaba en el
controlador de AutoClone y hacia fallar todos los videos despues de descargarlos.

COMO INSTALARLO

1. Cierra AutoSocial Studio.
2. Extrae este ZIP dentro de:
   C:\Users\msi\Downloads\autosocial-studio
3. Acepta reemplazar los archivos existentes y conserva las carpetas src,
   autodownload y web.
4. Comprueba que exista:
   C:\Users\msi\Downloads\autosocial-studio\autodownload\yt-dlp.exe
5. Inicia la herramienta normalmente.

Si una ejecucion anterior marco videos fallidos como descargados, selecciona
el modo de inicio "Reiniciar" en la herramienta para volver a intentarlo.

CONFIGURACION RECOMENDADA

Puedes eliminar YTDLP_PATH del archivo .env para usar automaticamente
autodownload/yt-dlp.exe. Si prefieres conservarlo, usa esta ruta relativa:

YTDLP_PATH=autodownload/yt-dlp.exe

No incluyas tiktok-cookies.txt, .env ni credenciales en un ZIP que vayas a
compartir.
