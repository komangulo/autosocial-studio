# AutoSocial Studio — Paquete completo de correcciones

Todo lo trabajado en esta sesión, en un solo sitio. Cada instalador se ejecuta
**desde la raíz del proyecto** (`C:\Users\msi\Downloads\autosocial-studio`).

## Orden de instalación (importante)

Ejecuta en este orden exacto. Algunos instaladores reescriben `web/app.js`, y correr
uno grande después de los de idioma puede romper los anclajes.

```
1) node instalar-x-autopilot-fix.js
2) node instalar-idioma.js
3) node instalar-idioma-radar.js
4) node instalar-radar-scan.js
```

> El paso 1 es el instalador grande (radar + X Autopilot + sesión X). Debe ir PRIMERO.

Después, para TypeSafe (opcional, cuando tengas la clave):

```
5) node instalar-typesafe.js --key ts_tu_clave
```

## Qué arregla cada cosa

| Instalador | Arreglo |
|---|---|
| `instalar-x-autopilot-fix.js` | Motor de X Autopilot, rutas del radar en el servidor, panel del radar, sesión X reutilizable. Incluye `assets/`. |
| `instalar-idioma.js` | Idioma del X Autopilot (por defecto **inglés**, `en`), selector `#xLanguage`. |
| `instalar-idioma-radar.js` | Idioma del Radar y de Publicación diaria (inglés por defecto), selectores `#radarLang` / `#acctPubLang`. |
| `instalar-radar-scan.js` | **El Radar escanea de verdad**: espera los tweets, hace scroll, detecta muro de login, y publica con la sesión de X ya guardada. Rediseño v4: funciona **sin necesidad de analizar una cuenta** (perfil fijo `radar`). |
| `instalar-typesafe.js` | Cliente TypeSafe (System One / Jev) para decisiones tipadas. La clave se guarda en `.env`, **solo servidor**. |

## Assets (por si prefieres copiarlos a mano)

La carpeta `assets/` contiene los archivos ya corregidos por si quieres reemplazarlos
manualmente en `assets/` del proyecto:

- `x-autopilot.js` — motor X Autopilot (`XAP-ENGINE-v3`, campo `language`).
- `x-auth.js` — sesión X (`XAP-AUTH-v3`).
- `acct-radar.js` — motor del radar (`ACCT-RADAR-v4`).
- `acct-radar-ui.js` — panel del radar (`ACCT-RADAR-UI-v4`).
- `acct-publisher.js` — publicación diaria por cuenta.
- `ai-config.js`, `account-analyzer.js`, `radar-patch.js` — soporte.

## TypeSafe

- Cliente: `typesafe-studio/src/typesafe.js` (se instala en `src/typesafe.js`).
- La clave vive en `.env` como `TYPESAFE_API_KEY=...`. `.env` ya está en `.gitignore`.
- Docs: https://docs.typesafe.ai/llms.txt

## Verificación rápida

```
node --check src/dashboard-server.js
```

Si compila sin error, el servidor arranca.

## Seguridad

- **Rota las claves que pegaste en el chat** (Vyce, Kiro, DeepSeek, TypeSafe).
- Ponlas solo en la caja de claves de la app o en `.env`, nunca en el navegador.

## Nota sobre la sesión X y yt-dlp

La app guarda la sesión de X en un perfil persistente de Playwright
(`.profiles/<cuenta>/...`). yt-dlp **no puede** leer ese perfil: solo
`androidclone/phases.js` le pasa las cookies. Cualquier otro descargador es anónimo
y choca con el muro de login de TikTok.
