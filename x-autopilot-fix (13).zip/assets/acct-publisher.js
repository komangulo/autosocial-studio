// Motor de publicacion diaria basada en el ADN de una cuenta analizada.
//
// MARKER: ACCT-PUB-v1
//
// Idea: en "Analisis de cuenta" eliges una cuenta estudiada. Su Manual de ADN
// se usa como molde de ESTILO; los "temas" que escribas son el CONTENIDO. Todos
// los dias, a las horas indicadas, la IA escribe N posts originales sobre esos
// temas imitando ese estilo y se publican en la cuenta de X con sesion activa.
//
// Reglas heredadas del analisis: nunca se mete en el prompt el @ de nadie, ni
// usuarios, ni enlaces, ni correos, ni hashtags. Y la salida se limpia igual.

const fs = require("fs/promises");
const path = require("path");
const { config } = require("./config");

const STATE_FILE = path.resolve(config.projectRoot, ".runtime", "acct-publisher.json");

const DEFAULTS = {
  enabled: false,
  referenceHandle: "",
  postsPerDay: 3,
  topics: [],
  startTime: "09:00",
  spreadMinutes: 240,
  maxChars: 280,
};

let state = { profiles: {} };
let loaded = false;
let worker = null;

function nowIso() { return new Date().toISOString(); }

function clone(value) { return JSON.parse(JSON.stringify(value)); }

function safeHandle(handle) {
  return String(handle || "").toLowerCase().replace(/[^a-z0-9_.-]/g, "").replace(/^\.+/, "").slice(0, 40);
}

function profileState(handle) {
  const key = safeHandle(handle);
  if (!key) throw new Error("Falta el @ de la cuenta de referencia.");
  if (!state.profiles[key]) {
    state.profiles[key] = {
      handle: key,
      config: clone(DEFAULTS),
      lastRunDate: "",
      history: [],
      errors: [],
      lastProvider: "",
    };
  }
  if (!Array.isArray(state.profiles[key].history)) state.profiles[key].history = [];
  if (!Array.isArray(state.profiles[key].errors)) state.profiles[key].errors = [];
  return state.profiles[key];
}

async function load() {
  if (loaded) return state;
  try {
    const raw = await fs.readFile(STATE_FILE, "utf8");
    const parsed = JSON.parse(raw);
    if (parsed && parsed.profiles) state = parsed;
  } catch {
    state = { profiles: {} };
  }
  loaded = true;
  return state;
}

async function save() {
  await fs.mkdir(path.dirname(STATE_FILE), { recursive: true });
  const tmp = `${STATE_FILE}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(state, null, 2), "utf8");
  await fs.rename(tmp, STATE_FILE);
}

// --- Saneado (mismo espiritu que el resto de la app) -----------------------

function sanitizeOutput(text) {
  return String(text || "")
    .replace(/https?:\/\/\S+/gi, "")
    .replace(/\bwww\.\S+/gi, "")
    .replace(/\b[\w.+-]+@[\w-]+\.[\w.]+\b/g, "")
    .replace(/(^|\s)@[A-Za-z0-9_]{1,15}\b/g, "$1")
    .replace(/(^|\s)#([\p{L}\p{N}_]+)/gu, "$1$2")
    .replace(/\[(usuario|enlace|correo)\]/gi, "")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function hasForbidden(text) {
  return /(^|\s)@[A-Za-z0-9_]{1,15}\b|https?:\/\/|\bwww\.|\b[\w.+-]+@[\w-]+\.[\w.]+\b/i.test(String(text || ""));
}

function parseTopics(value) {
  const list = Array.isArray(value)
    ? value
    : String(value || "").split(/[\n,;]+/);
  return list
    .map((t) => String(t || "").trim())
    .filter(Boolean)
    .slice(0, 40);
}

// --- Horarios ---------------------------------------------------------------

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Horas de publicacion de hoy para N posts, repartidos desde startTime con
 * spreadMinutes entre uno y otro. Si la hora de inicio ya paso, el primer slot
 * es "ahora" (recuperacion) para no perder el lote del dia. Devuelve Date.
 */
function slotTimes(configProfile, count, reference) {
  const [h, m] = String(configProfile.startTime || "09:00").split(":").map(Number);
  const spread = Math.max(5, Number(configProfile.spreadMinutes) || 240);
  const base = new Date(reference);
  base.setHours(Number.isFinite(h) ? h : 9, Number.isFinite(m) ? m : 0, 0, 0);
  const start = base.getTime() < reference.getTime() ? new Date(reference) : base;
  const times = [];
  for (let i = 0; i < count; i += 1) {
    times.push(new Date(start.getTime() + i * spread * 60 * 1000));
  }
  return times;
}

// --- Generacion -------------------------------------------------------------

async function buildStyleBlock(handle) {
  const analyzer = require("./account-analyzer");
  const data = await analyzer.get(handle);
  if (!data) {
    throw new Error(`La cuenta @${handle} no esta analizada. Analizala primero en "Analisis de cuenta".`);
  }
  // El manual ya va saneado y sin identidad. Se recorta para no inflar el prompt.
  const manual = String(data.manual || "").slice(0, 6000);
  return manual;
}

function topicForSlot(topics, index, queue) {
  if (!topics.length) return "";
  // Rotacion estable: evita repetir tema hasta agotar la lista.
  return topics[index % topics.length];
}

async function generateOne(profile, topic, attempt) {
  const aiConfig = require("./ai-config");
  const manual = await buildStyleBlock(profile.handle);
  const max = Math.max(80, Math.min(4000, Number(profile.config.maxChars) || 280));

  const prompt = [
    "Eres el autor de una cuenta de X. Vas a escribir UN post original, nuevo, listo para publicar.",
    "",
    "A continuacion tienes el MANUAL DE ESTILO de una cuenta de referencia. Describe COMO escribe (tono, longitud, estructura, ritmo), no QUE dice. No menciones esa cuenta ni copies sus posts.",
    "--- MANUAL DE ESTILO ---",
    manual,
    "--- FIN DEL MANUAL ---",
    "",
    topic ? `Tema del post: ${topic}` : "Tema: elige uno coherente con el estilo.",
    attempt > 0 ? `Intento ${attempt + 1}: evita repetir ideas de intentos anteriores; cambia el enfoque.` : "",
    "",
    `Escribe UN solo post en espanol, de ${Math.round(max * 0.55)} a ${max} caracteres.`,
    "REGLAS OBLIGATORIAS:",
    "- Devuelve SOLO el texto del post, sin comillas ni comentarios.",
    "- PROHIBIDO: @usuarios, enlaces/URLs, correos, hashtags y nombres de cuentas o marcas reales.",
    "- No menciones el manual ni que te basas en otra cuenta.",
    "- No inventes datos, cifras ni noticias que no puedas afirmar.",
    attempt > 0 ? "- Este intento debe ser claramente distinto a los anteriores." : "",
  ].filter(Boolean).join("\n");

  const result = await aiConfig.generate(prompt, {
    system: "Escribes posts breves para X. Cumples las reglas al pie de la letra y nunca incluyes usuarios, enlaces ni hashtags.",
  });

  let text = String(result.text || "").trim().replace(/^["']|["']$/g, "").trim();
  text = sanitizeOutput(text);
  if (!text) throw new Error("La IA devolvio un texto vacio.");
  if (hasForbidden(text)) throw new Error("La IA incluyo un usuario o enlace; se descarta el texto.");
  if (text.length > max) throw new Error(`El texto supera ${max} caracteres (${text.length}).`);
  return { text, provider: result.provider, model: result.model };
}

/**
 * Genera `count` posts variados para el perfil y los publica en la cuenta con
 * sesion activa. Devuelve un resumen.
 */
async function publishNow(handle, count, { topics, dryRun = false } = {}) {
  await load();
  const profile = profileState(handle);
  const total = Math.max(1, Math.min(20, Number(count) || profile.config.postsPerDay || 3));
  const list = parseTopics(topics || profile.config.topics);
  const xAuth = require("./x-auth");

  const done = [];
  const failed = [];
  for (let i = 0; i < total; i += 1) {
    const topic = topicForSlot(list, i + profile.history.length, profile.history);
    let generated = null;
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        generated = await generateOne(profile, topic, attempt);
        break;
      } catch (error) {
        lastError = error;
      }
    }
    if (!generated) {
      failed.push({ topic, error: lastError ? lastError.message : "sin texto" });
      continue;
    }
    const entry = {
      at: nowIso(),
      text: generated.text,
      topic,
      provider: generated.provider,
      model: generated.model,
      status: dryRun ? "generated" : "pending",
      remoteId: "",
      error: "",
    };
    if (!dryRun) {
      try {
        const result = await xAuth.postTweet(generated.text);
        entry.status = "published";
        entry.remoteId = result && result.accountId ? String(result.accountId) : "";
      } catch (error) {
        entry.status = "failed";
        entry.error = error.message;
        failed.push({ topic, error: error.message });
      }
    }
    profile.history.unshift(entry);
    profile.lastProvider = `${generated.provider}/${generated.model}`;
  }

  profile.history = profile.history.slice(0, 200);
  if (failed.length) {
    for (const f of failed) profile.errors.unshift({ at: nowIso(), ...f });
    profile.errors = profile.errors.slice(0, 50);
  }
  await save();
  return {
    ok: failed.length === 0,
    published: profile.history.filter((h) => h.status === "published").length,
    generated: total - failed.length,
    failed,
  };
}

/**
 * Tick programado: si esta activo y hoy aun no se ha lanzado, espera a la hora
 * de inicio y publica el lote del dia.
 */
async function tick() {
  await load();
  const now = new Date();
  for (const key of Object.keys(state.profiles)) {
    const profile = state.profiles[key];
    if (!profile.config.enabled) continue;
    if (profile.lastRunDate === todayKey()) continue;
    const slots = slotTimes(profile.config, Number(profile.config.postsPerDay) || 3, now);
    const first = slots[0];
    if (!first || first.getTime() > now.getTime()) continue;
    try {
      const result = await publishNow(key, profile.config.postsPerDay, {});
      profile.lastRunDate = todayKey();
      profile.lastResult = result;
      console.log(`[acct-publisher] @${key}: publicados ${result.published}, fallos ${result.failed.length}`);
    } catch (error) {
      profile.errors.unshift({ at: nowIso(), topic: "", error: error.message });
      profile.errors = profile.errors.slice(0, 50);
      console.error(`[acct-publisher] @${key}: ${error.message}`);
    }
    await save();
  }
}

function startWorker() {
  if (worker) return;
  const cron = require("node-cron");
  worker = cron.schedule("* * * * *", () => tick().catch((error) => console.error("[acct-publisher]", error)));
  console.log("[acct-publisher] worker arrancado (revisa cada minuto)");
}

function publicProfile(handle) {
  const profile = profileState(handle);
  return {
    handle: profile.handle,
    config: clone(profile.config),
    lastRunDate: profile.lastRunDate,
    lastResult: profile.lastResult || null,
    lastProvider: profile.lastProvider || "",
    history: profile.history.slice(0, 30),
    errors: profile.errors.slice(0, 10),
  };
}

async function configure(handle, patch = {}) {
  await load();
  const profile = profileState(handle);
  const c = profile.config;
  if (typeof patch.enabled === "boolean") c.enabled = patch.enabled;
  if (patch.postsPerDay != null) c.postsPerDay = Math.max(1, Math.min(20, Number(patch.postsPerDay) || 3));
  if (patch.topics != null) c.topics = parseTopics(patch.topics);
  if (patch.startTime != null) {
    const m = String(patch.startTime).match(/^(\d{1,2}):(\d{2})$/);
    if (m) c.startTime = `${String(Math.min(23, Number(m[1]))).padStart(2, "0")}:${m[2]}`;
  }
  if (patch.spreadMinutes != null) c.spreadMinutes = Math.max(5, Math.min(1440, Number(patch.spreadMinutes) || 240));
  if (patch.maxChars != null) c.maxChars = Math.max(80, Math.min(4000, Number(patch.maxChars) || 280));
  await save();
  return publicProfile(handle);
}

function clearHistory(handle) {
  const profile = profileState(handle);
  profile.history = [];
  profile.errors = [];
  profile.lastRunDate = "";
  return save().then(() => publicProfile(handle));
}

module.exports = {
  DEFAULTS,
  STATE_FILE,
  load,
  save,
  startWorker,
  tick,
  configure,
  publicProfile,
  publishNow,
  clearHistory,
  parseTopics,
  sanitizeOutput,
  slotTimes,
  safeHandle,
};
